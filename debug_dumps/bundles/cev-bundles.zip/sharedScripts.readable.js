function callPost(n,t,i,r){
$.ajax({
url:n,type:"Post",cache:!1,contentType:"application/json",dataType:"json",data:JSON.stringify(t),success:i,error:r}
)}
function getAvailableTimeSlotsForPublic(n,t,i){
callPost("/Home/AvailableTimeSlots",n,t,i)}
function FilterOutDuplicates(n){
const t={
}
,i=[],r=n.length;
var u=0;
for(let f=0;
f<r;
f++){
const r=n[f];
t[r]!==1&&(t[r]=1,i[u++]=r)}
return i}
function resetValidation(){
$(this).each(function(n,t){
$(t).trigger("reset.unobtrusiveValidation");
$(t).next().is("span")&&$(t).next().empty()}
)}
function showModal(n,t,i){
return getModal(n,t,i)}
function showModalToSendCancelLink(n,t,i,r){
const u=n.data("id");
if(u){
var f=getModal(t,i,r);
$(".btnConfirm",f).off().click(()=>{
f.modal("hide"),SharedAjaxService.appointmentCancelRequest(ajaxUrl,{
uniqueToken:u,cultureCode:lang}
,
function(t){
if(t.succeeded){
const i=n.children("#cancelFeedback"),r=n.children(".fa-close");
$(i).html(t.message);
$(i).show();
n.addClass("disabled");
$(n).prop("disabled",!0);
isDisabled=!0;
$(r).remove()}
}
,
function(){
window.location.reload()}
)}
)}
}
function getModal(n,t,i){
var r=$("#confirmationModal");
return $(".modal-title",r).html(n),setModalBody(r,t),toggleModalMenu(r,i),r.modal("show"),r}
function setModalBody(n,t,i){
var r=i?$('<div class="alert">').addClass(i).html(t):t;
$(".modal-body",n).html(r)}
function toggleModalMenu(n,t){
$(".menuDefault",n).toggle(!t);
$(".menuConfirm",n).toggle(t)}
function convertLocalTimeToUTC(){
const n=new Date;
return new Date(n.getTime()+n.getTimezoneOffset()*6e4)}
function getValidUntilMilliseconds(n){
const t=convertLocalTimeToUTC(),i=new Date(n);
return i.getTime()-t.getTime()}
function setupSessionTimeout(n,t){
const i=getValidUntilMilliseconds(n);
setTimeout(function(){
location.href=t?t:location.href}
,i)}
function successfullCaptcha(n){
const t=document.querySelector("#captchaText"),i=document.querySelector("#captchaDiv");
t.style.display="none";
i.style.display="none";
const r=document.querySelector("#loader"),u=document.querySelector("#loaderText");
r.style.display="block";
u.style.display="block";
SharedAjaxService.setCaptchaToken(ajaxUrl,{
captcha:n}
,
function(n){
setupSessionTimeout(n.validUntil,n.redirectUrl);
location.href=n.redirectUrl}
)}
var foolproof,ValidationConfiguration,SharedAjaxService,JQueryHelper,StringHelper;
if(!function(n,t){
"object"==typeof module&&"object"==typeof module.exports?module.exports=n.document?t(n,!0):function(n){
if(!n.document)throw new Error("jQuery requires a window with a document");
return t(n)}
:t(n)}
("undefined"!=typeof window?window:this,
function(n,t){
function ii(n){
var t=!!n&&"length"in n&&n.length,r=i.type(n);
return"function"===r||i.isWindow(n)?!1:"array"===r||0===t||"number"==typeof t&&t>0&&t-1 in n}
function ri(n,t,r){
if(i.isFunction(t))return i.grep(n,
function(n,i){
return!!t.call(n,i,n)!==r}
);
if(t.nodeType)return i.grep(n,
function(n){
return n===t!==r}
);
if("string"==typeof t){
if(bf.test(t))return i.filter(t,n,r);
t=i.filter(t,n)}
return i.grep(n,
function(n){
return lt.call(t,n)>-1!==r}
)}
function hr(n,t){
while((n=n[t])&&1!==n.nodeType);
return n}
function kf(n){
var t={
}
;
return i.each(n.match(h)||[],
function(n,i){
t[i]=!0}
),t}
function yt(){
u.removeEventListener("DOMContentLoaded",yt);
n.removeEventListener("load",yt);
i.ready()}
function et(){
this.expando=i.expando+et.uid++}
function lr(n,t,r){
var u;
if(void 0===r&&1===n.nodeType)if(u="data-"+t.replace(cr,"-$&").toLowerCase(),r=n.getAttribute(u),"string"==typeof r){
try{
r="true"===r?!0:"false"===r?!1:"null"===r?null:+r+""===r?+r:df.test(r)?i.parseJSON(r):r}
catch(f){
}
e.set(n,t,r)}
else r=void 0;
return r}
function vr(n,t,r,u){
var h,e=1,l=20,c=u?function(){
return u.cur()}
:function(){
return i.css(n,t,"")}
,s=c(),o=r&&r[3]||(i.cssNumber[t]?"":"px"),f=(i.cssNumber[t]||"px"!==o&&+s)&&ot.exec(i.css(n,t));
if(f&&f[3]!==o){
o=o||f[3];
r=r||[];
f=+s||1;
do e=e||".5",f/=e,i.style(n,t,f+o);
while(e!==(e=c()/s)&&1!==e&&--l)}
return r&&(f=+f||+s||0,h=r[1]?f+(r[1]+1)*r[2]:+r[2],u&&(u.unit=o,u.start=f,u.end=h)),h}
function o(n,t){
var r="undefined"!=typeof n.getElementsByTagName?n.getElementsByTagName(t||"*"):"undefined"!=typeof n.querySelectorAll?n.querySelectorAll(t||"*"):[];
return void 0===t||t&&i.nodeName(n,t)?i.merge([n],r):r}
function ui(n,t){
for(var i=0,u=n.length;
u>i;
i++)r.set(n[i],"globalEval",!t||r.get(t[i],"globalEval"))}
function kr(n,t,r,u,f){
for(var e,s,p,a,w,v,h=t.createDocumentFragment(),y=[],l=0,b=n.length;
b>l;
l++)if(e=n[l],e||0===e)if("object"===i.type(e))i.merge(y,e.nodeType?[e]:e);
else if(br.test(e)){
for(s=s||h.appendChild(t.createElement("div")),p=(pr.exec(e)||["",""])[1].toLowerCase(),a=c[p]||c._default,s.innerHTML=a[1]+i.htmlPrefilter(e)+a[2],v=a[0];
v--;
)s=s.lastChild;
i.merge(y,s.childNodes);
s=h.firstChild;
s.textContent=""}
else y.push(t.createTextNode(e));
for(h.textContent="",l=0;
e=y[l++];
)if(u&&i.inArray(e,u)>-1)f&&f.push(e);
else if(w=i.contains(e.ownerDocument,e),s=o(h.appendChild(e),"script"),w&&ui(s),r)for(v=0;
e=s[v++];
)wr.test(e.type||"")&&r.push(e);
return h}
function pt(){
return!0}
function nt(){
return!1}
function gr(){
try{
return u.activeElement}
catch(n){
}
}
function fi(n,t,r,u,f,e){
var o,s;
if("object"==typeof t){
"string"!=typeof r&&(u=u||r,r=void 0);
for(s in t)fi(n,s,r,u,t[s],e);
return n}
if(null==u&&null==f?(f=r,u=r=void 0):null==f&&("string"==typeof r?(f=u,u=void 0):(f=u,u=r,r=void 0)),f===!1)f=nt;
else if(!f)return n;
return 1===e&&(o=f,f=function(n){
return i().off(n),o.apply(this,arguments)}
,f.guid=o.guid||(o.guid=i.guid++)),n.each(function(){
i.event.add(this,t,f,u,r)}
)}
function nu(n,t){
return i.nodeName(n,"table")&&i.nodeName(11!==t.nodeType?t:t.firstChild,"tr")?n.getElementsByTagName("tbody")[0]||n.appendChild(n.ownerDocument.createElement("tbody")):n}
function ee(n){
return n.type=(null!==n.getAttribute("type"))+"/"+n.type,n}
function oe(n){
var t=ue.exec(n.type);
return t?n.type=t[1]:n.removeAttribute("type"),n}
function tu(n,t){
var u,c,f,s,h,l,a,o;
if(1===t.nodeType){
if(r.hasData(n)&&(s=r.access(n),h=r.set(t,s),o=s.events)){
delete h.handle;
h.events={
}
;
for(f in o)for(u=0,c=o[f].length;
c>u;
u++)i.event.add(t,f,o[f][u])}
e.hasData(n)&&(l=e.access(n),a=i.extend({
}
,l),e.set(t,a))}
}
function se(n,t){
var i=t.nodeName.toLowerCase();
"input"===i&&yr.test(n.type)?t.checked=n.checked:"input"!==i&&"textarea"!==i||(t.defaultValue=n.defaultValue)}
function b(n,t,u,e){
t=gi.apply([],t);
var l,p,c,a,s,w,h=0,v=n.length,d=v-1,y=t[0],k=i.isFunction(y);
if(k||v>1&&"string"==typeof y&&!f.checkClone&&re.test(y))return n.each(function(i){
var r=n.eq(i);
k&&(t[0]=y.call(this,i,r.html()));
b(r,t,u,e)}
);
if(v&&(l=kr(t,n[0].ownerDocument,!1,n,e),p=l.firstChild,1===l.childNodes.length&&(l=p),p||e)){
for(c=i.map(o(l,"script"),ee),a=c.length;
v>h;
h++)s=l,h!==d&&(s=i.clone(s,!0,!0),a&&i.merge(c,o(s,"script"))),u.call(n[h],s,h);
if(a)for(w=c[c.length-1].ownerDocument,i.map(c,oe),h=0;
a>h;
h++)s=c[h],wr.test(s.type||"")&&!r.access(s,"globalEval")&&i.contains(w,s)&&(s.src?i._evalUrl&&i._evalUrl(s.src):i.globalEval(s.textContent.replace(fe,"")))}
return n}
function iu(n,t,r){
for(var u,e=t?i.filter(t,n):n,f=0;
null!=(u=e[f]);
f++)r||1!==u.nodeType||i.cleanData(o(u)),u.parentNode&&(r&&i.contains(u.ownerDocument,u)&&ui(o(u,"script")),u.parentNode.removeChild(u));
return n}
function ru(n,t){
var r=i(t.createElement(n)).appendTo(t.body),u=i.css(r[0],"display");
return r.detach(),u}
function oi(n){
var r=u,t=ei[n];
return t||(t=ru(n,r),"none"!==t&&t||(wt=(wt||i("<iframe frameborder='0' width='0' height='0'/>")).appendTo(r.documentElement),r=wt[0].contentDocument,r.write(),r.close(),t=ru(n,r),wt.detach()),ei[n]=t),t}
function tt(n,t,r){
var o,s,h,u,e=n.style;
return r=r||bt(n),u=r?r.getPropertyValue(t)||r[t]:void 0,""!==u&&void 0!==u||i.contains(n.ownerDocument,n)||(u=i.style(n,t)),r&&!f.pixelMarginRight()&&si.test(u)&&uu.test(t)&&(o=e.width,s=e.minWidth,h=e.maxWidth,e.minWidth=e.maxWidth=e.width=u,u=r.width,e.width=o,e.minWidth=s,e.maxWidth=h),void 0!==u?u+"":u}
function ci(n,t){
return{
get:function(){
return n()?void delete this.get:(this.get=t).apply(this,arguments)}
}
}
function su(n){
if(n in ou)return n;
for(var i=n[0].toUpperCase()+n.slice(1),t=eu.length;
t--;
)if(n=eu[t]+i,n in ou)return n}
function hu(n,t,i){
var r=ot.exec(t);
return r?Math.max(0,r[2]-(i||0))+(r[3]||"px"):t}
function cu(n,t,r,u,f){
for(var e=r===(u?"border":"content")?4:"width"===t?1:0,o=0;
4>e;
e+=2)"margin"===r&&(o+=i.css(n,r+w[e],!0,f)),u?("content"===r&&(o-=i.css(n,"padding"+w[e],!0,f)),"margin"!==r&&(o-=i.css(n,"border"+w[e]+"Width",!0,f))):(o+=i.css(n,"padding"+w[e],!0,f),"padding"!==r&&(o+=i.css(n,"border"+w[e]+"Width",!0,f)));
return o}
function lu(t,r,e){
var h=!0,o="width"===r?t.offsetWidth:t.offsetHeight,s=bt(t),c="border-box"===i.css(t,"boxSizing",!1,s);
if(u.msFullscreenElement&&n.top!==n&&t.getClientRects().length&&(o=Math.round(100*t.getBoundingClientRect()[r])),0>=o||null==o){
if(o=tt(t,r,s),(0>o||null==o)&&(o=t.style[r]),si.test(o))return o;
h=c&&(f.boxSizingReliable()||o===t.style[r]);
o=parseFloat(o)||0}
return o+cu(t,r,e||(c?"border":"content"),h,s)+"px"}
function au(n,t){
for(var e,u,s,o=[],f=0,h=n.length;
h>f;
f++)u=n[f],u.style&&(o[f]=r.get(u,"olddisplay"),e=u.style.display,t?(o[f]||"none"!==e||(u.style.display=""),""===u.style.display&&st(u)&&(o[f]=r.access(u,"olddisplay",oi(u.nodeName)))):(s=st(u),"none"===e&&s||r.set(u,"olddisplay",s?e:i.css(u,"display"))));
for(f=0;
h>f;
f++)u=n[f],u.style&&(t&&"none"!==u.style.display&&""!==u.style.display||(u.style.display=t?o[f]||"":"none"));
return n}
function s(n,t,i,r,u){
return new s.prototype.init(n,t,i,r,u)}
function pu(){
return n.setTimeout(function(){
it=void 0}
),it=i.now()}
function dt(n,t){
var r,u=0,i={
height:n}
;
for(t=t?1:0;
4>u;
u+=2-t)r=w[u],i["margin"+r]=i["padding"+r]=n;
return t&&(i.opacity=i.width=n),i}
function wu(n,t,i){
for(var u,f=(l.tweeners[t]||[]).concat(l.tweeners["*"]),r=0,e=f.length;
e>r;
r++)if(u=f[r].call(i,t,n))return u}
function le(n,t,u){
var f,a,p,v,o,w,h,b,l=this,y={
}
,s=n.style,c=n.nodeType&&st(n),e=r.get(n,"fxshow");
u.queue||(o=i._queueHooks(n,"fx"),null==o.unqueued&&(o.unqueued=0,w=o.empty.fire,o.empty.fire=function(){
o.unqueued||w()}
),o.unqueued++,l.always(function(){
l.always(function(){
o.unqueued--;
i.queue(n,"fx").length||o.empty.fire()}
)}
));
1===n.nodeType&&("height"in t||"width"in t)&&(u.overflow=[s.overflow,s.overflowX,s.overflowY],h=i.css(n,"display"),b="none"===h?r.get(n,"olddisplay")||oi(n.nodeName):h,"inline"===b&&"none"===i.css(n,"float")&&(s.display="inline-block"));
u.overflow&&(s.overflow="hidden",l.always(function(){
s.overflow=u.overflow[0];
s.overflowX=u.overflow[1];
s.overflowY=u.overflow[2]}
));
for(f in t)if(a=t[f],vu.exec(a)){
if(delete t[f],p=p||"toggle"===a,a===(c?"hide":"show")){
if("show"!==a||!e||void 0===e[f])continue;
c=!0}
y[f]=e&&e[f]||i.style(n,f)}
else h=void 0;
if(i.isEmptyObject(y))"inline"===("none"===h?oi(n.nodeName):h)&&(s.display=h);
else{
e?"hidden"in e&&(c=e.hidden):e=r.access(n,"fxshow",{
}
);
p&&(e.hidden=!c);
c?i(n).show():l.done(function(){
i(n).hide()}
);
l.done(function(){
var t;
r.remove(n,"fxshow");
for(t in y)i.style(n,t,y[t])}
);
for(f in y)v=wu(c?e[f]:0,f,l),f in e||(e[f]=v.start,c&&(v.end=v.start,v.start="width"===f||"height"===f?1:0))}
}
function ae(n,t){
var r,f,e,u,o;
for(r in n)if(f=i.camelCase(r),e=t[f],u=n[r],i.isArray(u)&&(e=u[1],u=n[r]=u[0]),r!==f&&(n[f]=u,delete n[r]),o=i.cssHooks[f],o&&"expand"in o){
u=o.expand(u);
delete n[f];
for(r in u)r in n||(n[r]=u[r],t[r]=e)}
else t[f]=e}
function l(n,t,r){
var e,o,s=0,a=l.prefilters.length,f=i.Deferred().always(function(){
delete c.elem}
),c=function(){
if(o)return!1;
for(var s=it||pu(),t=Math.max(0,u.startTime+u.duration-s),h=t/u.duration||0,i=1-h,r=0,e=u.tweens.length;
e>r;
r++)u.tweens[r].run(i);
return f.notifyWith(n,[u,i,t]),1>i&&e?t:(f.resolveWith(n,[u]),!1)}
,u=f.promise({
elem:n,props:i.extend({
}
,t),opts:i.extend(!0,{
specialEasing:{
}
,easing:i.easing._default}
,r),originalProperties:t,originalOptions:r,startTime:it||pu(),duration:r.duration,tweens:[],createTween:function(t,r){
var f=i.Tween(n,u.opts,t,r,u.opts.specialEasing[t]||u.opts.easing);
return u.tweens.push(f),f}
,stop:function(t){
var i=0,r=t?u.tweens.length:0;
if(o)return this;
for(o=!0;
r>i;
i++)u.tweens[i].run(1);
return t?(f.notifyWith(n,[u,1,0]),f.resolveWith(n,[u,t])):f.rejectWith(n,[u,t]),this}
}
),h=u.props;
for(ae(h,u.opts.specialEasing);
a>s;
s++)if(e=l.prefilters[s].call(u,n,h,u.opts))return i.isFunction(e.stop)&&(i._queueHooks(u.elem,u.opts.queue).stop=i.proxy(e.stop,e)),e;
return i.map(h,wu,u),i.isFunction(u.opts.start)&&u.opts.start.call(n,u),i.fx.timer(i.extend(c,{
elem:n,anim:u,queue:u.opts.queue}
)),u.progress(u.opts.progress).done(u.opts.done,u.opts.complete).fail(u.opts.fail).always(u.opts.always)}
function k(n){
return n.getAttribute&&n.getAttribute("class")||""}
function ff(n){
return function(t,r){
"string"!=typeof t&&(r=t,t="*");
var u,f=0,e=t.toLowerCase().match(h)||[];
if(i.isFunction(r))while(u=e[f++])"+"===u[0]?(u=u.slice(1)||"*",(n[u]=n[u]||[]).unshift(r)):(n[u]=n[u]||[]).push(r)}
}
function ef(n,t,r,u){
function e(s){
var h;
return f[s]=!0,i.each(n[s]||[],
function(n,i){
var s=i(t,r,u);
return"string"!=typeof s||o||f[s]?o?!(h=s):void 0:(t.dataTypes.unshift(s),e(s),!1)}
),h}
var f={
}
,o=n===yi;
return e(t.dataTypes[0])||!f["*"]&&e("*")}
function wi(n,t){
var r,u,f=i.ajaxSettings.flatOptions||{
}
;
for(r in t)void 0!==t[r]&&((f[r]?n:u||(u={
}
))[r]=t[r]);
return u&&i.extend(!0,n,u),n}
function be(n,t,i){
for(var e,u,f,o,s=n.contents,r=n.dataTypes;
"*"===r[0];
)r.shift(),void 0===e&&(e=n.mimeType||t.getResponseHeader("Content-Type"));
if(e)for(u in s)if(s[u]&&s[u].test(e)){
r.unshift(u);
break}
if(r[0]in i)f=r[0];
else{
for(u in i){
if(!r[0]||n.converters[u+" "+r[0]]){
f=u;
break}
o||(o=u)}
f=f||o}
if(f)return(f!==r[0]&&r.unshift(f),i[f])}
function ke(n,t,i,r){
var h,u,f,s,e,o={
}
,c=n.dataTypes.slice();
if(c[1])for(f in n.converters)o[f.toLowerCase()]=n.converters[f];
for(u=c.shift();
u;
)if(n.responseFields[u]&&(i[n.responseFields[u]]=t),!e&&r&&n.dataFilter&&(t=n.dataFilter(t,n.dataType)),e=u,u=c.shift())if("*"===u)u=e;
else if("*"!==e&&e!==u){
if(f=o[e+" "+u]||o["* "+u],!f)for(h in o)if(s=h.split(" "),s[1]===u&&(f=o[e+" "+s[0]]||o["* "+s[0]])){
f===!0?f=o[h]:o[h]!==!0&&(u=s[0],c.unshift(s[1]));
break}
if(f!==!0)if(f&&n.throws)t=f(t);
else try{
t=f(t)}
catch(l){
return{
state:"parsererror",error:f?l:"No conversion from "+e+" to "+u}
}
}
return{
state:"success",data:t}
}
function bi(n,t,r,u){
var f;
if(i.isArray(t))i.each(t,
function(t,i){
r||ge.test(n)?u(n,i):bi(n+"["+("object"==typeof i&&null!=i?t:"")+"]",i,r,u)}
);
else if(r||"object"!==i.type(t))u(n,t);
else for(f in t)bi(n+"["+f+"]",t[f],r,u)}
function hf(n){
return i.isWindow(n)?n:9===n.nodeType&&n.defaultView}
var y=[],u=n.document,v=y.slice,gi=y.concat,ti=y.push,lt=y.indexOf,at={
}
,af=at.toString,ft=at.hasOwnProperty,f={
}
,nr="2.2.3",i=function(n,t){
return new i.fn.init(n,t)}
,vf=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,yf=/^-ms-/,pf=/-([\da-z])/gi,wf=function(n,t){
return t.toUpperCase()}
,p,ur,fr,er,or,sr,h,vt,a,g,br,wt,ei,it,kt,vu,yu,bu,rt,ku,du,gt,gu,nf,li,sf,ut,ki,ni,di,cf,lf;
i.fn=i.prototype={
jquery:nr,constructor:i,selector:"",length:0,toArray:function(){
return v.call(this)}
,get:function(n){
return null!=n?0>n?this[n+this.length]:this[n]:v.call(this)}
,pushStack:function(n){
var t=i.merge(this.constructor(),n);
return t.prevObject=this,t.context=this.context,t}
,each:function(n){
return i.each(this,n)}
,map:function(n){
return this.pushStack(i.map(this,
function(t,i){
return n.call(t,i,t)}
))}
,slice:function(){
return this.pushStack(v.apply(this,arguments))}
,first:function(){
return this.eq(0)}
,last:function(){
return this.eq(-1)}
,eq:function(n){
var i=this.length,t=+n+(0>n?i:0);
return this.pushStack(t>=0&&i>t?[this[t]]:[])}
,end:function(){
return this.prevObject||this.constructor()}
,push:ti,sort:y.sort,splice:y.splice}
;
i.extend=i.fn.extend=function(){
var e,f,r,t,o,s,n=arguments[0]||{
}
,u=1,c=arguments.length,h=!1;
for("boolean"==typeof n&&(h=n,n=arguments[u]||{
}
,u++),"object"==typeof n||i.isFunction(n)||(n={
}
),u===c&&(n=this,u--);
c>u;
u++)if(null!=(e=arguments[u]))for(f in e)r=n[f],t=e[f],n!==t&&(h&&t&&(i.isPlainObject(t)||(o=i.isArray(t)))?(o?(o=!1,s=r&&i.isArray(r)?r:[]):s=r&&i.isPlainObject(r)?r:{
}
,n[f]=i.extend(h,s,t)):void 0!==t&&(n[f]=t));
return n}
;
i.extend({
expando:"jQuery"+(nr+Math.random()).replace(/\D/g,""),isReady:!0,error:function(n){
throw new Error(n);
}
,noop:function(){
}
,isFunction:function(n){
return"function"===i.type(n)}
,isArray:Array.isArray,isWindow:function(n){
return null!=n&&n===n.window}
,isNumeric:function(n){
var t=n&&n.toString();
return!i.isArray(n)&&t-parseFloat(t)+1>=0}
,isPlainObject:function(n){
var t;
if("object"!==i.type(n)||n.nodeType||i.isWindow(n)||n.constructor&&!ft.call(n,"constructor")&&!ft.call(n.constructor.prototype||{
}
,"isPrototypeOf"))return!1;
for(t in n);
return void 0===t||ft.call(n,t)}
,isEmptyObject:function(n){
for(var t in n)return!1;
return!0}
,type:function(n){
return null==n?n+"":"object"==typeof n||"function"==typeof n?at[af.call(n)]||"object":typeof n}
,globalEval:function(n){
var t,r=eval;
n=i.trim(n);
n&&(1===n.indexOf("use strict")?(t=u.createElement("script"),t.text=n,u.head.appendChild(t).parentNode.removeChild(t)):r(n))}
,camelCase:function(n){
return n.replace(yf,"ms-").replace(pf,wf)}
,nodeName:function(n,t){
return n.nodeName&&n.nodeName.toLowerCase()===t.toLowerCase()}
,each:function(n,t){
var r,i=0;
if(ii(n)){
for(r=n.length;
r>i;
i++)if(t.call(n[i],i,n[i])===!1)break}
else for(i in n)if(t.call(n[i],i,n[i])===!1)break;
return n}
,trim:function(n){
return null==n?"":(n+"").replace(vf,"")}
,makeArray:function(n,t){
var r=t||[];
return null!=n&&(ii(Object(n))?i.merge(r,"string"==typeof n?[n]:n):ti.call(r,n)),r}
,inArray:function(n,t,i){
return null==t?-1:lt.call(t,n,i)}
,merge:function(n,t){
for(var u=+t.length,i=0,r=n.length;
u>i;
i++)n[r++]=t[i];
return n.length=r,n}
,grep:function(n,t,i){
for(var u,f=[],r=0,e=n.length,o=!i;
e>r;
r++)u=!t(n[r],r),u!==o&&f.push(n[r]);
return f}
,map:function(n,t,i){
var e,u,r=0,f=[];
if(ii(n))for(e=n.length;
e>r;
r++)u=t(n[r],r,i),null!=u&&f.push(u);
else for(r in n)u=t(n[r],r,i),null!=u&&f.push(u);
return gi.apply([],f)}
,guid:1,proxy:function(n,t){
var u,f,r;
return"string"==typeof t&&(u=n[t],t=n,n=u),i.isFunction(n)?(f=v.call(arguments,2),r=function(){
return n.apply(t||this,f.concat(v.call(arguments)))}
,r.guid=n.guid=n.guid||i.guid++,r):void 0}
,now:Date.now,support:f}
);
"function"==typeof Symbol&&(i.fn[Symbol.iterator]=y[Symbol.iterator]);
i.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "),
function(n,t){
at["[object "+t+"]"]=t.toLowerCase()}
);
p=function(n){
function u(n,t,r,u){
var l,w,a,s,nt,d,y,g,p=t&&t.ownerDocument,v=t?t.nodeType:9;
if(r=r||[],"string"!=typeof n||!n||1!==v&&9!==v&&11!==v)return r;
if(!u&&((t?t.ownerDocument||t:c)!==i&&b(t),t=t||i,h)){
if(11!==v&&(d=sr.exec(n)))if(l=d[1]){
if(9===v){
if(!(a=t.getElementById(l)))return r;
if(a.id===l)return r.push(a),r}
else if(p&&(a=p.getElementById(l))&&et(t,a)&&a.id===l)return r.push(a),r}
else{
if(d[2])return k.apply(r,t.getElementsByTagName(n)),r;
if((l=d[3])&&f.getElementsByClassName&&t.getElementsByClassName)return k.apply(r,t.getElementsByClassName(l)),r}
if(f.qsa&&!lt[n+" "]&&(!o||!o.test(n))){
if(1!==v)p=t,g=n;
else if("object"!==t.nodeName.toLowerCase()){
for((s=t.getAttribute("id"))?s=s.replace(hr,"\\$&"):t.setAttribute("id",s=e),y=ft(n),w=y.length,nt=yi.test(s)?"#"+s:"[id='"+s+"']";
w--;
)y[w]=nt+" "+yt(y[w]);
g=y.join(",");
p=gt.test(n)&&ii(t.parentNode)||t}
if(g)try{
return k.apply(r,p.querySelectorAll(g)),r}
catch(tt){
}
finally{
s===e&&t.removeAttribute("id")}
}
}
return si(n.replace(at,"$1"),t,r,u)}
function ni(){
function n(r,u){
return i.push(r+" ")>t.cacheLength&&delete n[i.shift()],n[r+" "]=u}
var i=[];
return n}
function l(n){
return n[e]=!0,n}
function a(n){
var t=i.createElement("div");
try{
return!!n(t)}
catch(r){
return!1}
finally{
t.parentNode&&t.parentNode.removeChild(t);
t=null}
}
function ti(n,i){
for(var r=n.split("|"),u=r.length;
u--;
)t.attrHandle[r[u]]=i}
function wi(n,t){
var i=t&&n,r=i&&1===n.nodeType&&1===t.nodeType&&(~t.sourceIndex||li)-(~n.sourceIndex||li);
if(r)return r;
if(i)while(i=i.nextSibling)if(i===t)return-1;
return n?1:-1}
function cr(n){
return function(t){
var i=t.nodeName.toLowerCase();
return"input"===i&&t.type===n}
}
function lr(n){
return function(t){
var i=t.nodeName.toLowerCase();
return("input"===i||"button"===i)&&t.type===n}
}
function it(n){
return l(function(t){
return t=+t,l(function(i,r){
for(var u,f=n([],i.length,t),e=f.length;
e--;
)i[u=f[e]]&&(i[u]=!(r[u]=i[u]))}
)}
)}
function ii(n){
return n&&"undefined"!=typeof n.getElementsByTagName&&n}
function bi(){
}
function yt(n){
for(var t=0,r=n.length,i="";
r>t;
t++)i+=n[t].value;
return i}
function ri(n,t,i){
var r=t.dir,u=i&&"parentNode"===r,f=ki++;
return t.first?function(t,i,f){
while(t=t[r])if(1===t.nodeType||u)return n(t,i,f)}
:function(t,i,o){
var s,h,c,l=[v,f];
if(o){
while(t=t[r])if((1===t.nodeType||u)&&n(t,i,o))return!0}
else while(t=t[r])if(1===t.nodeType||u){
if(c=t[e]||(t[e]={
}
),h=c[t.uniqueID]||(c[t.uniqueID]={
}
),(s=h[r])&&s[0]===v&&s[1]===f)return l[2]=s[2];
if(h[r]=l,l[2]=n(t,i,o))return!0}
}
}
function ui(n){
return n.length>1?function(t,i,r){
for(var u=n.length;
u--;
)if(!n[u](t,i,r))return!1;
return!0}
:n[0]}
function ar(n,t,i){
for(var r=0,f=t.length;
f>r;
r++)u(n,t[r],i);
return i}
function pt(n,t,i,r,u){
for(var e,o=[],f=0,s=n.length,h=null!=t;
s>f;
f++)(e=n[f])&&(i&&!i(e,r,u)||(o.push(e),h&&t.push(f)));
return o}
function fi(n,t,i,r,u,f){
return r&&!r[e]&&(r=fi(r)),u&&!u[e]&&(u=fi(u,f)),l(function(f,e,o,s){
var l,c,a,p=[],y=[],w=e.length,b=f||ar(t||"*",o.nodeType?[o]:o,[]),v=!n||!f&&t?b:pt(b,p,n,o,s),h=i?u||(f?n:w||r)?[]:e:v;
if(i&&i(v,h,o,s),r)for(l=pt(h,y),r(l,[],o,s),c=l.length;
c--;
)(a=l[c])&&(h[y[c]]=!(v[y[c]]=a));
if(f){
if(u||n){
if(u){
for(l=[],c=h.length;
c--;
)(a=h[c])&&l.push(v[c]=a);
u(null,h=[],l,s)}
for(c=h.length;
c--;
)(a=h[c])&&(l=u?nt(f,a):p[c])>-1&&(f[l]=!(e[l]=a))}
}
else h=pt(h===e?h.splice(w,h.length):h),u?u(null,e,h,s):k.apply(e,h)}
)}
function ei(n){
for(var o,u,r,s=n.length,h=t.relative[n[0].type],c=h||t.relative[" "],i=h?1:0,l=ri(function(n){
return n===o}
,c,!0),a=ri(function(n){
return nt(o,n)>-1}
,c,!0),f=[function(n,t,i){
var r=!h&&(i||t!==ht)||((o=t).nodeType?l(n,t,i):a(n,t,i));
return o=null,r}
];
s>i;
i++)if(u=t.relative[n[i].type])f=[ri(ui(f),u)];
else{
if(u=t.filter[n[i].type].apply(null,n[i].matches),u[e]){
for(r=++i;
s>r;
r++)if(t.relative[n[r].type])break;
return fi(i>1&&ui(f),i>1&&yt(n.slice(0,i-1).concat({
value:" "===n[i-2].type?"*":""}
)).replace(at,"$1"),u,r>i&&ei(n.slice(i,r)),s>r&&ei(n=n.slice(r)),s>r&&yt(n))}
f.push(u)}
return ui(f)}
function vr(n,r){
var f=r.length>0,e=n.length>0,o=function(o,s,c,l,a){
var y,nt,d,g=0,p="0",tt=o&&[],w=[],it=ht,rt=o||e&&t.find.TAG("*",a),ut=v+=null==it?1:Math.random()||.1,ft=rt.length;
for(a&&(ht=s===i||s||a);
p!==ft&&null!=(y=rt[p]);
p++){
if(e&&y){
for(nt=0,s||y.ownerDocument===i||(b(y),c=!h);
d=n[nt++];
)if(d(y,s||i,c)){
l.push(y);
break}
a&&(v=ut)}
f&&((y=!d&&y)&&g--,o&&tt.push(y))}
if(g+=p,f&&p!==g){
for(nt=0;
d=r[nt++];
)d(tt,w,s,c);
if(o){
if(g>0)while(p--)tt[p]||w[p]||(w[p]=gi.call(l));
w=pt(w)}
k.apply(l,w);
a&&!o&&w.length>0&&g+r.length>1&&u.uniqueSort(l)}
return a&&(v=ut,ht=it),tt}
;
return f?l(o):o}
var rt,f,t,st,oi,ft,wt,si,ht,w,ut,b,i,s,h,o,d,ct,et,e="sizzle"+1*new Date,c=n.document,v=0,ki=0,hi=ni(),ci=ni(),lt=ni(),bt=function(n,t){
return n===t&&(ut=!0),0}
,li=-2147483648,di={
}
.hasOwnProperty,g=[],gi=g.pop,nr=g.push,k=g.push,ai=g.slice,nt=function(n,t){
for(var i=0,r=n.length;
r>i;
i++)if(n[i]===t)return i;
return-1}
,kt="checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",r="[\\x20\\t\\r\\n\\f]",tt="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",vi="\\["+r+"*("+tt+")(?:"+r+"*([*^$|!~]?=)"+r+"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|("+tt+"))|)"+r+"*\\]",dt=":("+tt+")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|"+vi+")*)|.*)\\)|)",tr=new RegExp(r+"+","g"),at=new RegExp("^"+r+"+|((?:^|[^\\\\])(?:\\\\.)*)"+r+"+$","g"),ir=new RegExp("^"+r+"*,"+r+"*"),rr=new RegExp("^"+r+"*([>+~]|"+r+")"+r+"*"),ur=new RegExp("="+r+"*([^\\]'\"]*?)"+r+"*\\]","g"),fr=new RegExp(dt),yi=new RegExp("^"+tt+"$"),vt={
ID:new RegExp("^#("+tt+")"),CLASS:new RegExp("^\\.("+tt+")"),TAG:new RegExp("^("+tt+"|[*])"),ATTR:new RegExp("^"+vi),PSEUDO:new RegExp("^"+dt),CHILD:new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+r+"*(even|odd|(([+-]|)(\\d*)n|)"+r+"*(?:([+-]|)"+r+"*(\\d+)|))"+r+"*\\)|)","i"),bool:new RegExp("^(?:"+kt+")$","i"),needsContext:new RegExp("^"+r+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+r+"*((?:-\\d)?\\d*)"+r+"*\\)|)(?=[^-]|$)","i")}
,er=/^(?:input|select|textarea|button)$/i,or=/^h\d$/i,ot=/^[^{
]+\{
\s*\[native \w/,sr=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,gt=/[+~]/,hr=/'|\\/g,y=new RegExp("\\\\([\\da-f]{
1,6}
"+r+"?|("+r+")|.)","ig"),p=function(n,t,i){
var r="0x"+t-65536;
return r!==r||i?t:0>r?String.fromCharCode(r+65536):String.fromCharCode(r>>10|55296,1023&r|56320)}
,pi=function(){
b()}
;
try{
k.apply(g=ai.call(c.childNodes),c.childNodes);
g[c.childNodes.length].nodeType}
catch(yr){
k={
apply:g.length?function(n,t){
nr.apply(n,ai.call(t))}
:function(n,t){
for(var i=n.length,r=0;
n[i++]=t[r++];
);
n.length=i-1}
}
}
f=u.support={
}
;
oi=u.isXML=function(n){
var t=n&&(n.ownerDocument||n).documentElement;
return t?"HTML"!==t.nodeName:!1}
;
b=u.setDocument=function(n){
var v,u,l=n?n.ownerDocument||n:c;
return l!==i&&9===l.nodeType&&l.documentElement?(i=l,s=i.documentElement,h=!oi(i),(u=i.defaultView)&&u.top!==u&&(u.addEventListener?u.addEventListener("unload",pi,!1):u.attachEvent&&u.attachEvent("onunload",pi)),f.attributes=a(function(n){
return n.className="i",!n.getAttribute("className")}
),f.getElementsByTagName=a(function(n){
return n.appendChild(i.createComment("")),!n.getElementsByTagName("*").length}
),f.getElementsByClassName=ot.test(i.getElementsByClassName),f.getById=a(function(n){
return s.appendChild(n).id=e,!i.getElementsByName||!i.getElementsByName(e).length}
),f.getById?(t.find.ID=function(n,t){
if("undefined"!=typeof t.getElementById&&h){
var i=t.getElementById(n);
return i?[i]:[]}
}
,t.filter.ID=function(n){
var t=n.replace(y,p);
return function(n){
return n.getAttribute("id")===t}
}
):(delete t.find.ID,t.filter.ID=function(n){
var t=n.replace(y,p);
return function(n){
var i="undefined"!=typeof n.getAttributeNode&&n.getAttributeNode("id");
return i&&i.value===t}
}
),t.find.TAG=f.getElementsByTagName?function(n,t){
return"undefined"!=typeof t.getElementsByTagName?t.getElementsByTagName(n):f.qsa?t.querySelectorAll(n):void 0}
:function(n,t){
var i,r=[],f=0,u=t.getElementsByTagName(n);
if("*"===n){
while(i=u[f++])1===i.nodeType&&r.push(i);
return r}
return u}
,t.find.CLASS=f.getElementsByClassName&&function(n,t){
if("undefined"!=typeof t.getElementsByClassName&&h)return t.getElementsByClassName(n)}
,d=[],o=[],(f.qsa=ot.test(i.querySelectorAll))&&(a(function(n){
s.appendChild(n).innerHTML="<a id='"+e+"'><\/a><select id='"+e+"-\r\\' msallowcapture=''><option selected=''><\/option><\/select>";
n.querySelectorAll("[msallowcapture^='']").length&&o.push("[*^$]="+r+"*(?:''|\"\")");
n.querySelectorAll("[selected]").length||o.push("\\["+r+"*(?:value|"+kt+")");
n.querySelectorAll("[id~="+e+"-]").length||o.push("~=");
n.querySelectorAll(":checked").length||o.push(":checked");
n.querySelectorAll("a#"+e+"+*").length||o.push(".#.+[+~]")}
),a(function(n){
var t=i.createElement("input");
t.setAttribute("type","hidden");
n.appendChild(t).setAttribute("name","D");
n.querySelectorAll("[name=d]").length&&o.push("name"+r+"*[*^$|!~]?=");
n.querySelectorAll(":enabled").length||o.push(":enabled",":disabled");
n.querySelectorAll("*,:x");
o.push(",.*:")}
)),(f.matchesSelector=ot.test(ct=s.matches||s.webkitMatchesSelector||s.mozMatchesSelector||s.oMatchesSelector||s.msMatchesSelector))&&a(function(n){
f.disconnectedMatch=ct.call(n,"div");
ct.call(n,"[s!='']:x");
d.push("!=",dt)}
),o=o.length&&new RegExp(o.join("|")),d=d.length&&new RegExp(d.join("|")),v=ot.test(s.compareDocumentPosition),et=v||ot.test(s.contains)?function(n,t){
var r=9===n.nodeType?n.documentElement:n,i=t&&t.parentNode;
return n===i||!(!i||1!==i.nodeType||!(r.contains?r.contains(i):n.compareDocumentPosition&&16&n.compareDocumentPosition(i)))}
:function(n,t){
if(t)while(t=t.parentNode)if(t===n)return!0;
return!1}
,bt=v?function(n,t){
if(n===t)return ut=!0,0;
var r=!n.compareDocumentPosition-!t.compareDocumentPosition;
return r?r:(r=(n.ownerDocument||n)===(t.ownerDocument||t)?n.compareDocumentPosition(t):1,1&r||!f.sortDetached&&t.compareDocumentPosition(n)===r?n===i||n.ownerDocument===c&&et(c,n)?-1:t===i||t.ownerDocument===c&&et(c,t)?1:w?nt(w,n)-nt(w,t):0:4&r?-1:1)}
:function(n,t){
if(n===t)return ut=!0,0;
var r,u=0,o=n.parentNode,s=t.parentNode,f=[n],e=[t];
if(!o||!s)return n===i?-1:t===i?1:o?-1:s?1:w?nt(w,n)-nt(w,t):0;
if(o===s)return wi(n,t);
for(r=n;
r=r.parentNode;
)f.unshift(r);
for(r=t;
r=r.parentNode;
)e.unshift(r);
while(f[u]===e[u])u++;
return u?wi(f[u],e[u]):f[u]===c?-1:e[u]===c?1:0}
,i):i}
;
u.matches=function(n,t){
return u(n,null,null,t)}
;
u.matchesSelector=function(n,t){
if((n.ownerDocument||n)!==i&&b(n),t=t.replace(ur,"='$1']"),f.matchesSelector&&h&&!lt[t+" "]&&(!d||!d.test(t))&&(!o||!o.test(t)))try{
var r=ct.call(n,t);
if(r||f.disconnectedMatch||n.document&&11!==n.document.nodeType)return r}
catch(e){
}
return u(t,i,null,[n]).length>0}
;
u.contains=function(n,t){
return(n.ownerDocument||n)!==i&&b(n),et(n,t)}
;
u.attr=function(n,r){
(n.ownerDocument||n)!==i&&b(n);
var e=t.attrHandle[r.toLowerCase()],u=e&&di.call(t.attrHandle,r.toLowerCase())?e(n,r,!h):void 0;
return void 0!==u?u:f.attributes||!h?n.getAttribute(r):(u=n.getAttributeNode(r))&&u.specified?u.value:null}
;
u.error=function(n){
throw new Error("Syntax error, unrecognized expression: "+n);
}
;
u.uniqueSort=function(n){
var r,u=[],t=0,i=0;
if(ut=!f.detectDuplicates,w=!f.sortStable&&n.slice(0),n.sort(bt),ut){
while(r=n[i++])r===n[i]&&(t=u.push(i));
while(t--)n.splice(u[t],1)}
return w=null,n}
;
st=u.getText=function(n){
var r,i="",u=0,t=n.nodeType;
if(t){
if(1===t||9===t||11===t){
if("string"==typeof n.textContent)return n.textContent;
for(n=n.firstChild;
n;
n=n.nextSibling)i+=st(n)}
else if(3===t||4===t)return n.nodeValue}
else while(r=n[u++])i+=st(r);
return i}
;
t=u.selectors={
cacheLength:50,createPseudo:l,match:vt,attrHandle:{
}
,find:{
}
,relative:{
">":{
dir:"parentNode",first:!0}
," ":{
dir:"parentNode"}
,"+":{
dir:"previousSibling",first:!0}
,"~":{
dir:"previousSibling"}
}
,preFilter:{
ATTR:function(n){
return n[1]=n[1].replace(y,p),n[3]=(n[3]||n[4]||n[5]||"").replace(y,p),"~="===n[2]&&(n[3]=" "+n[3]+" "),n.slice(0,4)}
,CHILD:function(n){
return n[1]=n[1].toLowerCase(),"nth"===n[1].slice(0,3)?(n[3]||u.error(n[0]),n[4]=+(n[4]?n[5]+(n[6]||1):2*("even"===n[3]||"odd"===n[3])),n[5]=+(n[7]+n[8]||"odd"===n[3])):n[3]&&u.error(n[0]),n}
,PSEUDO:function(n){
var i,t=!n[6]&&n[2];
return vt.CHILD.test(n[0])?null:(n[3]?n[2]=n[4]||n[5]||"":t&&fr.test(t)&&(i=ft(t,!0))&&(i=t.indexOf(")",t.length-i)-t.length)&&(n[0]=n[0].slice(0,i),n[2]=t.slice(0,i)),n.slice(0,3))}
}
,filter:{
TAG:function(n){
var t=n.replace(y,p).toLowerCase();
return"*"===n?function(){
return!0}
:function(n){
return n.nodeName&&n.nodeName.toLowerCase()===t}
}
,CLASS:function(n){
var t=hi[n+" "];
return t||(t=new RegExp("(^|"+r+")"+n+"("+r+"|$)"))&&hi(n,
function(n){
return t.test("string"==typeof n.className&&n.className||"undefined"!=typeof n.getAttribute&&n.getAttribute("class")||"")}
)}
,ATTR:function(n,t,i){
return function(r){
var f=u.attr(r,n);
return null==f?"!="===t:t?(f+="","="===t?f===i:"!="===t?f!==i:"^="===t?i&&0===f.indexOf(i):"*="===t?i&&f.indexOf(i)>-1:"$="===t?i&&f.slice(-i.length)===i:"~="===t?(" "+f.replace(tr," ")+" ").indexOf(i)>-1:"|="===t?f===i||f.slice(0,i.length+1)===i+"-":!1):!0}
}
,CHILD:function(n,t,i,r,u){
var s="nth"!==n.slice(0,3),o="last"!==n.slice(-4),f="of-type"===t;
return 1===r&&0===u?function(n){
return!!n.parentNode}
:function(t,i,h){
var p,w,y,c,a,b,k=s!==o?"nextSibling":"previousSibling",d=t.parentNode,nt=f&&t.nodeName.toLowerCase(),g=!h&&!f,l=!1;
if(d){
if(s){
while(k){
for(c=t;
c=c[k];
)if(f?c.nodeName.toLowerCase()===nt:1===c.nodeType)return!1;
b=k="only"===n&&!b&&"nextSibling"}
return!0}
if(b=[o?d.firstChild:d.lastChild],o&&g){
for(c=d,y=c[e]||(c[e]={
}
),w=y[c.uniqueID]||(y[c.uniqueID]={
}
),p=w[n]||[],a=p[0]===v&&p[1],l=a&&p[2],c=a&&d.childNodes[a];
c=++a&&c&&c[k]||(l=a=0)||b.pop();
)if(1===c.nodeType&&++l&&c===t){
w[n]=[v,a,l];
break}
}
else if(g&&(c=t,y=c[e]||(c[e]={
}
),w=y[c.uniqueID]||(y[c.uniqueID]={
}
),p=w[n]||[],a=p[0]===v&&p[1],l=a),l===!1)while(c=++a&&c&&c[k]||(l=a=0)||b.pop())if((f?c.nodeName.toLowerCase()===nt:1===c.nodeType)&&++l&&(g&&(y=c[e]||(c[e]={
}
),w=y[c.uniqueID]||(y[c.uniqueID]={
}
),w[n]=[v,l]),c===t))break;
return l-=u,l===r||l%r==0&&l/r>=0}
}
}
,PSEUDO:function(n,i){
var f,r=t.pseudos[n]||t.setFilters[n.toLowerCase()]||u.error("unsupported pseudo: "+n);
return r[e]?r(i):r.length>1?(f=[n,n,"",i],t.setFilters.hasOwnProperty(n.toLowerCase())?l(function(n,t){
for(var u,f=r(n,i),e=f.length;
e--;
)u=nt(n,f[e]),n[u]=!(t[u]=f[e])}
):function(n){
return r(n,0,f)}
):r}
}
,pseudos:{
not:l(function(n){
var t=[],r=[],i=wt(n.replace(at,"$1"));
return i[e]?l(function(n,t,r,u){
for(var e,o=i(n,null,u,[]),f=n.length;
f--;
)(e=o[f])&&(n[f]=!(t[f]=e))}
):function(n,u,f){
return t[0]=n,i(t,null,f,r),t[0]=null,!r.pop()}
}
),has:l(function(n){
return function(t){
return u(n,t).length>0}
}
),contains:l(function(n){
return n=n.replace(y,p),
function(t){
return(t.textContent||t.innerText||st(t)).indexOf(n)>-1}
}
),lang:l(function(n){
return yi.test(n||"")||u.error("unsupported lang: "+n),n=n.replace(y,p).toLowerCase(),
function(t){
var i;
do if(i=h?t.lang:t.getAttribute("xml:lang")||t.getAttribute("lang"))return i=i.toLowerCase(),i===n||0===i.indexOf(n+"-");
while((t=t.parentNode)&&1===t.nodeType);
return!1}
}
),target:function(t){
var i=n.location&&n.location.hash;
return i&&i.slice(1)===t.id}
,root:function(n){
return n===s}
,focus:function(n){
return n===i.activeElement&&(!i.hasFocus||i.hasFocus())&&!!(n.type||n.href||~n.tabIndex)}
,enabled:function(n){
return n.disabled===!1}
,disabled:function(n){
return n.disabled===!0}
,checked:function(n){
var t=n.nodeName.toLowerCase();
return"input"===t&&!!n.checked||"option"===t&&!!n.selected}
,selected:function(n){
return n.parentNode&&n.parentNode.selectedIndex,n.selected===!0}
,empty:function(n){
for(n=n.firstChild;
n;
n=n.nextSibling)if(n.nodeType<6)return!1;
return!0}
,parent:function(n){
return!t.pseudos.empty(n)}
,header:function(n){
return or.test(n.nodeName)}
,input:function(n){
return er.test(n.nodeName)}
,button:function(n){
var t=n.nodeName.toLowerCase();
return"input"===t&&"button"===n.type||"button"===t}
,text:function(n){
var t;
return"input"===n.nodeName.toLowerCase()&&"text"===n.type&&(null==(t=n.getAttribute("type"))||"text"===t.toLowerCase())}
,first:it(function(){
return[0]}
),last:it(function(n,t){
return[t-1]}
),eq:it(function(n,t,i){
return[0>i?i+t:i]}
),even:it(function(n,t){
for(var i=0;
t>i;
i+=2)n.push(i);
return n}
),odd:it(function(n,t){
for(var i=1;
t>i;
i+=2)n.push(i);
return n}
),lt:it(function(n,t,i){
for(var r=0>i?i+t:i;
--r>=0;
)n.push(r);
return n}
),gt:it(function(n,t,i){
for(var r=0>i?i+t:i;
++r<t;
)n.push(r);
return n}
)}
}
;
t.pseudos.nth=t.pseudos.eq;
for(rt in{
radio:!0,checkbox:!0,file:!0,password:!0,image:!0}
)t.pseudos[rt]=cr(rt);
for(rt in{
submit:!0,reset:!0}
)t.pseudos[rt]=lr(rt);
return bi.prototype=t.filters=t.pseudos,t.setFilters=new bi,ft=u.tokenize=function(n,i){
var e,f,s,o,r,h,c,l=ci[n+" "];
if(l)return i?0:l.slice(0);
for(r=n,h=[],c=t.preFilter;
r;
){
(!e||(f=ir.exec(r)))&&(f&&(r=r.slice(f[0].length)||r),h.push(s=[]));
e=!1;
(f=rr.exec(r))&&(e=f.shift(),s.push({
value:e,type:f[0].replace(at," ")}
),r=r.slice(e.length));
for(o in t.filter)(f=vt[o].exec(r))&&(!c[o]||(f=c[o](f)))&&(e=f.shift(),s.push({
value:e,type:o,matches:f}
),r=r.slice(e.length));
if(!e)break}
return i?r.length:r?u.error(n):ci(n,h).slice(0)}
,wt=u.compile=function(n,t){
var r,u=[],f=[],i=lt[n+" "];
if(!i){
for(t||(t=ft(n)),r=t.length;
r--;
)i=ei(t[r]),i[e]?u.push(i):f.push(i);
i=lt(n,vr(f,u));
i.selector=n}
return i}
,si=u.select=function(n,i,r,u){
var s,e,o,a,v,l="function"==typeof n&&n,c=!u&&ft(n=l.selector||n);
if(r=r||[],1===c.length){
if(e=c[0]=c[0].slice(0),e.length>2&&"ID"===(o=e[0]).type&&f.getById&&9===i.nodeType&&h&&t.relative[e[1].type]){
if(i=(t.find.ID(o.matches[0].replace(y,p),i)||[])[0],!i)return r;
l&&(i=i.parentNode);
n=n.slice(e.shift().value.length)}
for(s=vt.needsContext.test(n)?0:e.length;
s--;
){
if(o=e[s],t.relative[a=o.type])break;
if((v=t.find[a])&&(u=v(o.matches[0].replace(y,p),gt.test(e[0].type)&&ii(i.parentNode)||i))){
if(e.splice(s,1),n=u.length&&yt(e),!n)return k.apply(r,u),r;
break}
}
}
return(l||wt(n,c))(u,i,!h,r,!i||gt.test(n)&&ii(i.parentNode)||i),r}
,f.sortStable=e.split("").sort(bt).join("")===e,f.detectDuplicates=!!ut,b(),f.sortDetached=a(function(n){
return 1&n.compareDocumentPosition(i.createElement("div"))}
),a(function(n){
return n.innerHTML="<a href='#'><\/a>","#"===n.firstChild.getAttribute("href")}
)||ti("type|href|height|width",
function(n,t,i){
if(!i)return n.getAttribute(t,"type"===t.toLowerCase()?1:2)}
),f.attributes&&a(function(n){
return n.innerHTML="<input/>",n.firstChild.setAttribute("value",""),""===n.firstChild.getAttribute("value")}
)||ti("value",
function(n,t,i){
if(!i&&"input"===n.nodeName.toLowerCase())return n.defaultValue}
),a(function(n){
return null==n.getAttribute("disabled")}
)||ti(kt,
function(n,t,i){
var r;
if(!i)return n[t]===!0?t.toLowerCase():(r=n.getAttributeNode(t))&&r.specified?r.value:null}
),u}
(n);
i.find=p;
i.expr=p.selectors;
i.expr[":"]=i.expr.pseudos;
i.uniqueSort=i.unique=p.uniqueSort;
i.text=p.getText;
i.isXMLDoc=p.isXML;
i.contains=p.contains;
var d=function(n,t,r){
for(var u=[],f=void 0!==r;
(n=n[t])&&9!==n.nodeType;
)if(1===n.nodeType){
if(f&&i(n).is(r))break;
u.push(n)}
return u}
,tr=function(n,t){
for(var i=[];
n;
n=n.nextSibling)1===n.nodeType&&n!==t&&i.push(n);
return i}
,ir=i.expr.match.needsContext,rr=/^<([\w-]+)\s*\/?>(?:<\/\1>|)$/,bf=/^.[^:#\[\.,]*$/;
i.filter=function(n,t,r){
var u=t[0];
return r&&(n=":not("+n+")"),1===t.length&&1===u.nodeType?i.find.matchesSelector(u,n)?[u]:[]:i.find.matches(n,i.grep(t,
function(n){
return 1===n.nodeType}
))}
;
i.fn.extend({
find:function(n){
var t,u=this.length,r=[],f=this;
if("string"!=typeof n)return this.pushStack(i(n).filter(function(){
for(t=0;
u>t;
t++)if(i.contains(f[t],this))return!0}
));
for(t=0;
u>t;
t++)i.find(n,f[t],r);
return r=this.pushStack(u>1?i.unique(r):r),r.selector=this.selector?this.selector+" "+n:n,r}
,filter:function(n){
return this.pushStack(ri(this,n||[],!1))}
,not:function(n){
return this.pushStack(ri(this,n||[],!0))}
,is:function(n){
return!!ri(this,"string"==typeof n&&ir.test(n)?i(n):n||[],!1).length}
}
);
fr=/^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/;
er=i.fn.init=function(n,t,r){
var f,e;
if(!n)return this;
if(r=r||ur,"string"==typeof n){
if(f="<"===n[0]&&">"===n[n.length-1]&&n.length>=3?[null,n,null]:fr.exec(n),!f||!f[1]&&t)return!t||t.jquery?(t||r).find(n):this.constructor(t).find(n);
if(f[1]){
if(t=t instanceof i?t[0]:t,i.merge(this,i.parseHTML(f[1],t&&t.nodeType?t.ownerDocument||t:u,!0)),rr.test(f[1])&&i.isPlainObject(t))for(f in t)i.isFunction(this[f])?this[f](t[f]):this.attr(f,t[f]);
return this}
return e=u.getElementById(f[2]),e&&e.parentNode&&(this.length=1,this[0]=e),this.context=u,this.selector=n,this}
return n.nodeType?(this.context=this[0]=n,this.length=1,this):i.isFunction(n)?void 0!==r.ready?r.ready(n):n(i):(void 0!==n.selector&&(this.selector=n.selector,this.context=n.context),i.makeArray(n,this))}
;
er.prototype=i.fn;
ur=i(u);
or=/^(?:parents|prev(?:Until|All))/;
sr={
children:!0,contents:!0,next:!0,prev:!0}
;
i.fn.extend({
has:function(n){
var t=i(n,this),r=t.length;
return this.filter(function(){
for(var n=0;
r>n;
n++)if(i.contains(this,t[n]))return!0}
)}
,closest:function(n,t){
for(var r,f=0,o=this.length,u=[],e=ir.test(n)||"string"!=typeof n?i(n,t||this.context):0;
o>f;
f++)for(r=this[f];
r&&r!==t;
r=r.parentNode)if(r.nodeType<11&&(e?e.index(r)>-1:1===r.nodeType&&i.find.matchesSelector(r,n))){
u.push(r);
break}
return this.pushStack(u.length>1?i.uniqueSort(u):u)}
,index:function(n){
return n?"string"==typeof n?lt.call(i(n),this[0]):lt.call(this,n.jquery?n[0]:n):this[0]&&this[0].parentNode?this.first().prevAll().length:-1}
,add:function(n,t){
return this.pushStack(i.uniqueSort(i.merge(this.get(),i(n,t))))}
,addBack:function(n){
return this.add(null==n?this.prevObject:this.prevObject.filter(n))}
}
);
i.each({
parent:function(n){
var t=n.parentNode;
return t&&11!==t.nodeType?t:null}
,parents:function(n){
return d(n,"parentNode")}
,parentsUntil:function(n,t,i){
return d(n,"parentNode",i)}
,next:function(n){
return hr(n,"nextSibling")}
,prev:function(n){
return hr(n,"previousSibling")}
,nextAll:function(n){
return d(n,"nextSibling")}
,prevAll:function(n){
return d(n,"previousSibling")}
,nextUntil:function(n,t,i){
return d(n,"nextSibling",i)}
,prevUntil:function(n,t,i){
return d(n,"previousSibling",i)}
,siblings:function(n){
return tr((n.parentNode||{
}
).firstChild,n)}
,children:function(n){
return tr(n.firstChild)}
,contents:function(n){
return n.contentDocument||i.merge([],n.childNodes)}
}
,
function(n,t){
i.fn[n]=function(r,u){
var f=i.map(this,t,r);
return"Until"!==n.slice(-5)&&(u=r),u&&"string"==typeof u&&(f=i.filter(u,f)),this.length>1&&(sr[n]||i.uniqueSort(f),or.test(n)&&f.reverse()),this.pushStack(f)}
}
);
h=/\S+/g;
i.Callbacks=function(n){
n="string"==typeof n?kf(n):i.extend({
}
,n);
var o,r,h,f,t=[],e=[],u=-1,c=function(){
for(f=n.once,h=o=!0;
e.length;
u=-1)for(r=e.shift();
++u<t.length;
)t[u].apply(r[0],r[1])===!1&&n.stopOnFalse&&(u=t.length,r=!1);
n.memory||(r=!1);
o=!1;
f&&(t=r?[]:"")}
,s={
add:function(){
return t&&(r&&!o&&(u=t.length-1,e.push(r)),
function f(r){
i.each(r,
function(r,u){
i.isFunction(u)?n.unique&&s.has(u)||t.push(u):u&&u.length&&"string"!==i.type(u)&&f(u)}
)}
(arguments),r&&!o&&c()),this}
,remove:function(){
return i.each(arguments,
function(n,r){
for(var f;
(f=i.inArray(r,t,f))>-1;
)t.splice(f,1),u>=f&&u--}
),this}
,has:function(n){
return n?i.inArray(n,t)>-1:t.length>0}
,empty:function(){
return t&&(t=[]),this}
,disable:function(){
return f=e=[],t=r="",this}
,disabled:function(){
return!t}
,lock:function(){
return f=e=[],r||(t=r=""),this}
,locked:function(){
return!!f}
,fireWith:function(n,t){
return f||(t=t||[],t=[n,t.slice?t.slice():t],e.push(t),o||c()),this}
,fire:function(){
return s.fireWith(this,arguments),this}
,fired:function(){
return!!h}
}
;
return s}
;
i.extend({
Deferred:function(n){
var u=[["resolve","done",i.Callbacks("once memory"),"resolved"],["reject","fail",i.Callbacks("once memory"),"rejected"],["notify","progress",i.Callbacks("memory")]],f="pending",r={
state:function(){
return f}
,always:function(){
return t.done(arguments).fail(arguments),this}
,then:function(){
var n=arguments;
return i.Deferred(function(f){
i.each(u,
function(u,e){
var o=i.isFunction(n[u])&&n[u];
t[e[1]](function(){
var n=o&&o.apply(this,arguments);
n&&i.isFunction(n.promise)?n.promise().progress(f.notify).done(f.resolve).fail(f.reject):f[e[0]+"With"](this===r?f.promise():this,o?[n]:arguments)}
)}
);
n=null}
).promise()}
,promise:function(n){
return null!=n?i.extend(n,r):r}
}
,t={
}
;
return r.pipe=r.then,i.each(u,
function(n,i){
var e=i[2],o=i[3];
r[i[1]]=e.add;
o&&e.add(function(){
f=o}
,u[1^n][2].disable,u[2][2].lock);
t[i[0]]=function(){
return t[i[0]+"With"](this===t?r:this,arguments),this}
;
t[i[0]+"With"]=e.fireWith}
),r.promise(t),n&&n.call(t,t),t}
,when:function(n){
var t=0,u=v.call(arguments),r=u.length,e=1!==r||n&&i.isFunction(n.promise)?r:0,f=1===e?n:i.Deferred(),h=function(n,t,i){
return function(r){
t[n]=this;
i[n]=arguments.length>1?v.call(arguments):r;
i===o?f.notifyWith(t,i):--e||f.resolveWith(t,i)}
}
,o,c,s;
if(r>1)for(o=new Array(r),c=new Array(r),s=new Array(r);
r>t;
t++)u[t]&&i.isFunction(u[t].promise)?u[t].promise().progress(h(t,c,o)).done(h(t,s,u)).fail(f.reject):--e;
return e||f.resolveWith(s,u),f.promise()}
}
);
i.fn.ready=function(n){
return i.ready.promise().done(n),this}
;
i.extend({
isReady:!1,readyWait:1,holdReady:function(n){
n?i.readyWait++:i.ready(!0)}
,ready:function(n){
(n===!0?--i.readyWait:i.isReady)||(i.isReady=!0,n!==!0&&--i.readyWait>0||(vt.resolveWith(u,[i]),i.fn.triggerHandler&&(i(u).triggerHandler("ready"),i(u).off("ready"))))}
}
);
i.ready.promise=function(t){
return vt||(vt=i.Deferred(),"complete"===u.readyState||"loading"!==u.readyState&&!u.documentElement.doScroll?n.setTimeout(i.ready):(u.addEventListener("DOMContentLoaded",yt),n.addEventListener("load",yt))),vt.promise(t)}
;
i.ready.promise();
a=function(n,t,r,u,f,e,o){
var s=0,c=n.length,h=null==r;
if("object"===i.type(r)){
f=!0;
for(s in r)a(n,t,s,r[s],!0,e,o)}
else if(void 0!==u&&(f=!0,i.isFunction(u)||(o=!0),h&&(o?(t.call(n,u),t=null):(h=t,t=function(n,t,r){
return h.call(i(n),r)}
)),t))for(;
c>s;
s++)t(n[s],r,o?u:u.call(n[s],s,t(n[s],r)));
return f?n:h?t.call(n):c?t(n[0],r):e}
;
g=function(n){
return 1===n.nodeType||9===n.nodeType||!+n.nodeType}
;
et.uid=1;
et.prototype={
register:function(n,t){
var i=t||{
}
;
return n.nodeType?n[this.expando]=i:Object.defineProperty(n,this.expando,{
value:i,writable:!0,configurable:!0}
),n[this.expando]}
,cache:function(n){
if(!g(n))return{
}
;
var t=n[this.expando];
return t||(t={
}
,g(n)&&(n.nodeType?n[this.expando]=t:Object.defineProperty(n,this.expando,{
value:t,configurable:!0}
))),t}
,set:function(n,t,i){
var r,u=this.cache(n);
if("string"==typeof t)u[t]=i;
else for(r in t)u[r]=t[r];
return u}
,get:function(n,t){
return void 0===t?this.cache(n):n[this.expando]&&n[this.expando][t]}
,access:function(n,t,r){
var u;
return void 0===t||t&&"string"==typeof t&&void 0===r?(u=this.get(n,t),void 0!==u?u:this.get(n,i.camelCase(t))):(this.set(n,t,r),void 0!==r?r:t)}
,remove:function(n,t){
var f,r,e,u=n[this.expando];
if(void 0!==u){
if(void 0===t)this.register(n);
else for(i.isArray(t)?r=t.concat(t.map(i.camelCase)):(e=i.camelCase(t),(t in u)?r=[t,e]:(r=e,r=(r in u)?[r]:r.match(h)||[])),f=r.length;
f--;
)delete u[r[f]];
(void 0===t||i.isEmptyObject(u))&&(n.nodeType?n[this.expando]=void 0:delete n[this.expando])}
}
,hasData:function(n){
var t=n[this.expando];
return void 0!==t&&!i.isEmptyObject(t)}
}
;
var r=new et,e=new et,df=/^(?:\{
[\w\W]*\}
|\[[\w\W]*\])$/,cr=/[A-Z]/g;
i.extend({
hasData:function(n){
return e.hasData(n)||r.hasData(n)}
,data:function(n,t,i){
return e.access(n,t,i)}
,removeData:function(n,t){
e.remove(n,t)}
,_data:function(n,t,i){
return r.access(n,t,i)}
,_removeData:function(n,t){
r.remove(n,t)}
}
);
i.fn.extend({
data:function(n,t){
var o,f,s,u=this[0],h=u&&u.attributes;
if(void 0===n){
if(this.length&&(s=e.get(u),1===u.nodeType&&!r.get(u,"hasDataAttrs"))){
for(o=h.length;
o--;
)h[o]&&(f=h[o].name,0===f.indexOf("data-")&&(f=i.camelCase(f.slice(5)),lr(u,f,s[f])));
r.set(u,"hasDataAttrs",!0)}
return s}
return"object"==typeof n?this.each(function(){
e.set(this,n)}
):a(this,
function(t){
var r,f;
if(u&&void 0===t){
if((r=e.get(u,n)||e.get(u,n.replace(cr,"-$&").toLowerCase()),void 0!==r)||(f=i.camelCase(n),r=e.get(u,f),void 0!==r)||(r=lr(u,f,void 0),void 0!==r))return r}
else f=i.camelCase(n),this.each(function(){
var i=e.get(this,f);
e.set(this,f,t);
n.indexOf("-")>-1&&void 0!==i&&e.set(this,n,t)}
)}
,null,t,arguments.length>1,null,!0)}
,removeData:function(n){
return this.each(function(){
e.remove(this,n)}
)}
}
);
i.extend({
queue:function(n,t,u){
var f;
if(n)return(t=(t||"fx")+"queue",f=r.get(n,t),u&&(!f||i.isArray(u)?f=r.access(n,t,i.makeArray(u)):f.push(u)),f||[])}
,dequeue:function(n,t){
t=t||"fx";
var r=i.queue(n,t),e=r.length,u=r.shift(),f=i._queueHooks(n,t),o=function(){
i.dequeue(n,t)}
;
"inprogress"===u&&(u=r.shift(),e--);
u&&("fx"===t&&r.unshift("inprogress"),delete f.stop,u.call(n,o,f));
!e&&f&&f.empty.fire()}
,_queueHooks:function(n,t){
var u=t+"queueHooks";
return r.get(n,u)||r.access(n,u,{
empty:i.Callbacks("once memory").add(function(){
r.remove(n,[t+"queue",u])}
)}
)}
}
);
i.fn.extend({
queue:function(n,t){
var r=2;
return"string"!=typeof n&&(t=n,n="fx",r--),arguments.length<r?i.queue(this[0],n):void 0===t?this:this.each(function(){
var r=i.queue(this,n,t);
i._queueHooks(this,n);
"fx"===n&&"inprogress"!==r[0]&&i.dequeue(this,n)}
)}
,dequeue:function(n){
return this.each(function(){
i.dequeue(this,n)}
)}
,clearQueue:function(n){
return this.queue(n||"fx",[])}
,promise:function(n,t){
var u,e=1,o=i.Deferred(),f=this,s=this.length,h=function(){
--e||o.resolveWith(f,[f])}
;
for("string"!=typeof n&&(t=n,n=void 0),n=n||"fx";
s--;
)u=r.get(f[s],n+"queueHooks"),u&&u.empty&&(e++,u.empty.add(h));
return h(),o.promise(t)}
}
);
var ar=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,ot=new RegExp("^(?:([+-])=|)("+ar+")([a-z%]*)$","i"),w=["Top","Right","Bottom","Left"],st=function(n,t){
return n=t||n,"none"===i.css(n,"display")||!i.contains(n.ownerDocument,n)}
;
var yr=/^(?:checkbox|radio)$/i,pr=/<([\w:-]+)/,wr=/^$|\/(?:java|ecma)script/i,c={
option:[1,"<select multiple='multiple'>","<\/select>"],thead:[1,"<table>","<\/table>"],col:[2,"<table><colgroup>","<\/colgroup><\/table>"],tr:[2,"<table><tbody>","<\/tbody><\/table>"],td:[3,"<table><tbody><tr>","<\/tr><\/tbody><\/table>"],_default:[0,"",""]}
;
c.optgroup=c.option;
c.tbody=c.tfoot=c.colgroup=c.caption=c.thead;
c.th=c.td;
br=/<|&#?\w+;
/;
!function(){
var i=u.createDocumentFragment(),n=i.appendChild(u.createElement("div")),t=u.createElement("input");
t.setAttribute("type","radio");
t.setAttribute("checked","checked");
t.setAttribute("name","t");
n.appendChild(t);
f.checkClone=n.cloneNode(!0).cloneNode(!0).lastChild.checked;
n.innerHTML="<textarea>x<\/textarea>";
f.noCloneChecked=!!n.cloneNode(!0).lastChild.defaultValue}
();
var gf=/^key/,ne=/^(?:mouse|pointer|contextmenu|drag|drop)|click/,dr=/^([^.]*)(?:\.(.+)|)/;
i.event={
global:{
}
,add:function(n,t,u,f,e){
var v,y,w,p,b,c,s,l,o,k,d,a=r.get(n);
if(a)for(u.handler&&(v=u,u=v.handler,e=v.selector),u.guid||(u.guid=i.guid++),(p=a.events)||(p=a.events={
}
),(y=a.handle)||(y=a.handle=function(t){
if("undefined"!=typeof i&&i.event.triggered!==t.type)return i.event.dispatch.apply(n,arguments)}
),t=(t||"").match(h)||[""],b=t.length;
b--;
)w=dr.exec(t[b])||[],o=d=w[1],k=(w[2]||"").split(".").sort(),o&&(s=i.event.special[o]||{
}
,o=(e?s.delegateType:s.bindType)||o,s=i.event.special[o]||{
}
,c=i.extend({
type:o,origType:d,data:f,handler:u,guid:u.guid,selector:e,needsContext:e&&i.expr.match.needsContext.test(e),namespace:k.join(".")}
,v),(l=p[o])||(l=p[o]=[],l.delegateCount=0,s.setup&&s.setup.call(n,f,k,y)!==!1||n.addEventListener&&n.addEventListener(o,y)),s.add&&(s.add.call(n,c),c.handler.guid||(c.handler.guid=u.guid)),e?l.splice(l.delegateCount++,0,c):l.push(c),i.event.global[o]=!0)}
,remove:function(n,t,u,f,e){
var y,k,c,v,p,s,l,a,o,b,d,w=r.hasData(n)&&r.get(n);
if(w&&(v=w.events)){
for(t=(t||"").match(h)||[""],p=t.length;
p--;
)if(c=dr.exec(t[p])||[],o=d=c[1],b=(c[2]||"").split(".").sort(),o){
for(l=i.event.special[o]||{
}
,o=(f?l.delegateType:l.bindType)||o,a=v[o]||[],c=c[2]&&new RegExp("(^|\\.)"+b.join("\\.(?:.*\\.|)")+"(\\.|$)"),k=y=a.length;
y--;
)s=a[y],!e&&d!==s.origType||u&&u.guid!==s.guid||c&&!c.test(s.namespace)||f&&f!==s.selector&&("**"!==f||!s.selector)||(a.splice(y,1),s.selector&&a.delegateCount--,l.remove&&l.remove.call(n,s));
k&&!a.length&&(l.teardown&&l.teardown.call(n,b,w.handle)!==!1||i.removeEvent(n,o,w.handle),delete v[o])}
else for(o in v)i.event.remove(n,o+t[p],u,f,!0);
i.isEmptyObject(v)&&r.remove(n,"handle events")}
}
,dispatch:function(n){
n=i.event.fix(n);
var o,s,e,u,t,h=[],c=v.call(arguments),l=(r.get(this,"events")||{
}
)[n.type]||[],f=i.event.special[n.type]||{
}
;
if(c[0]=n,n.delegateTarget=this,!f.preDispatch||f.preDispatch.call(this,n)!==!1){
for(h=i.event.handlers.call(this,n,l),o=0;
(u=h[o++])&&!n.isPropagationStopped();
)for(n.currentTarget=u.elem,s=0;
(t=u.handlers[s++])&&!n.isImmediatePropagationStopped();
)n.rnamespace&&!n.rnamespace.test(t.namespace)||(n.handleObj=t,n.data=t.data,e=((i.event.special[t.origType]||{
}
).handle||t.handler).apply(u.elem,c),void 0!==e&&(n.result=e)===!1&&(n.preventDefault(),n.stopPropagation()));
return f.postDispatch&&f.postDispatch.call(this,n),n.result}
}
,handlers:function(n,t){
var e,u,f,o,h=[],s=t.delegateCount,r=n.target;
if(s&&r.nodeType&&("click"!==n.type||isNaN(n.button)||n.button<1))for(;
r!==this;
r=r.parentNode||this)if(1===r.nodeType&&(r.disabled!==!0||"click"!==n.type)){
for(u=[],e=0;
s>e;
e++)o=t[e],f=o.selector+" ",void 0===u[f]&&(u[f]=o.needsContext?i(f,this).index(r)>-1:i.find(f,this,null,[r]).length),u[f]&&u.push(o);
u.length&&h.push({
elem:r,handlers:u}
)}
return s<t.length&&h.push({
elem:this,handlers:t.slice(s)}
),h}
,props:"altKey bubbles cancelable ctrlKey currentTarget detail eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{
}
,keyHooks:{
props:"char charCode key keyCode".split(" "),filter:function(n,t){
return null==n.which&&(n.which=null!=t.charCode?t.charCode:t.keyCode),n}
}
,mouseHooks:{
props:"button buttons clientX clientY offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(n,t){
var e,i,r,f=t.button;
return null==n.pageX&&null!=t.clientX&&(e=n.target.ownerDocument||u,i=e.documentElement,r=e.body,n.pageX=t.clientX+(i&&i.scrollLeft||r&&r.scrollLeft||0)-(i&&i.clientLeft||r&&r.clientLeft||0),n.pageY=t.clientY+(i&&i.scrollTop||r&&r.scrollTop||0)-(i&&i.clientTop||r&&r.clientTop||0)),n.which||void 0===f||(n.which=1&f?1:2&f?3:4&f?2:0),n}
}
,fix:function(n){
if(n[i.expando])return n;
var f,e,o,r=n.type,s=n,t=this.fixHooks[r];
for(t||(this.fixHooks[r]=t=ne.test(r)?this.mouseHooks:gf.test(r)?this.keyHooks:{
}
),o=t.props?this.props.concat(t.props):this.props,n=new i.Event(s),f=o.length;
f--;
)e=o[f],n[e]=s[e];
return n.target||(n.target=u),3===n.target.nodeType&&(n.target=n.target.parentNode),t.filter?t.filter(n,s):n}
,special:{
load:{
noBubble:!0}
,focus:{
trigger:function(){
if(this!==gr()&&this.focus)return(this.focus(),!1)}
,delegateType:"focusin"}
,blur:{
trigger:function(){
if(this===gr()&&this.blur)return(this.blur(),!1)}
,delegateType:"focusout"}
,click:{
trigger:function(){
if("checkbox"===this.type&&this.click&&i.nodeName(this,"input"))return(this.click(),!1)}
,_default:function(n){
return i.nodeName(n.target,"a")}
}
,beforeunload:{
postDispatch:function(n){
void 0!==n.result&&n.originalEvent&&(n.originalEvent.returnValue=n.result)}
}
}
}
;
i.removeEvent=function(n,t,i){
n.removeEventListener&&n.removeEventListener(t,i)}
;
i.Event=function(n,t){
return this instanceof i.Event?(n&&n.type?(this.originalEvent=n,this.type=n.type,this.isDefaultPrevented=n.defaultPrevented||void 0===n.defaultPrevented&&n.returnValue===!1?pt:nt):this.type=n,t&&i.extend(this,t),this.timeStamp=n&&n.timeStamp||i.now(),void(this[i.expando]=!0)):new i.Event(n,t)}
;
i.Event.prototype={
constructor:i.Event,isDefaultPrevented:nt,isPropagationStopped:nt,isImmediatePropagationStopped:nt,preventDefault:function(){
var n=this.originalEvent;
this.isDefaultPrevented=pt;
n&&n.preventDefault()}
,stopPropagation:function(){
var n=this.originalEvent;
this.isPropagationStopped=pt;
n&&n.stopPropagation()}
,stopImmediatePropagation:function(){
var n=this.originalEvent;
this.isImmediatePropagationStopped=pt;
n&&n.stopImmediatePropagation();
this.stopPropagation()}
}
;
i.each({
mouseenter:"mouseover",mouseleave:"mouseout",pointerenter:"pointerover",pointerleave:"pointerout"}
,
function(n,t){
i.event.special[n]={
delegateType:t,bindType:t,handle:function(n){
var u,f=this,r=n.relatedTarget,e=n.handleObj;
return r&&(r===f||i.contains(f,r))||(n.type=e.origType,u=e.handler.apply(this,arguments),n.type=t),u}
}
}
);
i.fn.extend({
on:function(n,t,i,r){
return fi(this,n,t,i,r)}
,one:function(n,t,i,r){
return fi(this,n,t,i,r,1)}
,off:function(n,t,r){
var u,f;
if(n&&n.preventDefault&&n.handleObj)return u=n.handleObj,i(n.delegateTarget).off(u.namespace?u.origType+"."+u.namespace:u.origType,u.selector,u.handler),this;
if("object"==typeof n){
for(f in n)this.off(f,t,n[f]);
return this}
return t!==!1&&"function"!=typeof t||(r=t,t=void 0),r===!1&&(r=nt),this.each(function(){
i.event.remove(this,n,r,t)}
)}
}
);
var te=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:-]+)[^>]*)\/>/gi,ie=/<script|<style|<link/i,re=/checked\s*(?:[^=]|=\s*.checked.)/i,ue=/^true\/(.*)/,fe=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
i.extend({
htmlPrefilter:function(n){
return n.replace(te,"<$1><\/$2>")}
,clone:function(n,t,r){
var u,c,s,e,h=n.cloneNode(!0),l=i.contains(n.ownerDocument,n);
if(!(f.noCloneChecked||1!==n.nodeType&&11!==n.nodeType||i.isXMLDoc(n)))for(e=o(h),s=o(n),u=0,c=s.length;
c>u;
u++)se(s[u],e[u]);
if(t)if(r)for(s=s||o(n),e=e||o(h),u=0,c=s.length;
c>u;
u++)tu(s[u],e[u]);
else tu(n,h);
return e=o(h,"script"),e.length>0&&ui(e,!l&&o(n,"script")),h}
,cleanData:function(n){
for(var u,t,f,s=i.event.special,o=0;
void 0!==(t=n[o]);
o++)if(g(t)){
if(u=t[r.expando]){
if(u.events)for(f in u.events)s[f]?i.event.remove(t,f):i.removeEvent(t,f,u.handle);
t[r.expando]=void 0}
t[e.expando]&&(t[e.expando]=void 0)}
}
}
);
i.fn.extend({
domManip:b,detach:function(n){
return iu(this,n,!0)}
,remove:function(n){
return iu(this,n)}
,text:function(n){
return a(this,
function(n){
return void 0===n?i.text(this):this.empty().each(function(){
1!==this.nodeType&&11!==this.nodeType&&9!==this.nodeType||(this.textContent=n)}
)}
,null,n,arguments.length)}
,append:function(){
return b(this,arguments,
function(n){
if(1===this.nodeType||11===this.nodeType||9===this.nodeType){
var t=nu(this,n);
t.appendChild(n)}
}
)}
,prepend:function(){
return b(this,arguments,
function(n){
if(1===this.nodeType||11===this.nodeType||9===this.nodeType){
var t=nu(this,n);
t.insertBefore(n,t.firstChild)}
}
)}
,before:function(){
return b(this,arguments,
function(n){
this.parentNode&&this.parentNode.insertBefore(n,this)}
)}
,after:function(){
return b(this,arguments,
function(n){
this.parentNode&&this.parentNode.insertBefore(n,this.nextSibling)}
)}
,empty:function(){
for(var n,t=0;
null!=(n=this[t]);
t++)1===n.nodeType&&(i.cleanData(o(n,!1)),n.textContent="");
return this}
,clone:function(n,t){
return n=null==n?!1:n,t=null==t?n:t,this.map(function(){
return i.clone(this,n,t)}
)}
,html:function(n){
return a(this,
function(n){
var t=this[0]||{
}
,r=0,u=this.length;
if(void 0===n&&1===t.nodeType)return t.innerHTML;
if("string"==typeof n&&!ie.test(n)&&!c[(pr.exec(n)||["",""])[1].toLowerCase()]){
n=i.htmlPrefilter(n);
try{
for(;
u>r;
r++)t=this[r]||{
}
,1===t.nodeType&&(i.cleanData(o(t,!1)),t.innerHTML=n);
t=0}
catch(f){
}
}
t&&this.empty().append(n)}
,null,n,arguments.length)}
,replaceWith:function(){
var n=[];
return b(this,arguments,
function(t){
var r=this.parentNode;
i.inArray(this,n)<0&&(i.cleanData(o(this)),r&&r.replaceChild(t,this))}
,n)}
}
);
i.each({
appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"}
,
function(n,t){
i.fn[n]=function(n){
for(var u,f=[],e=i(n),o=e.length-1,r=0;
o>=r;
r++)u=r===o?this:this.clone(!0),i(e[r])[t](u),ti.apply(f,u.get());
return this.pushStack(f)}
}
);
ei={
HTML:"block",BODY:"block"}
;
var uu=/^margin/,si=new RegExp("^("+ar+")(?!px)[a-z%]+$","i"),bt=function(t){
var i=t.ownerDocument.defaultView;
return i&&i.opener||(i=n),i.getComputedStyle(t)}
,hi=function(n,t,i,r){
var f,u,e={
}
;
for(u in t)e[u]=n.style[u],n.style[u]=t[u];
f=i.apply(n,r||[]);
for(u in t)n.style[u]=e[u];
return f}
,ht=u.documentElement;
!function(){
var o,e,s,h,r=u.createElement("div"),t=u.createElement("div");
if(t.style){
t.style.backgroundClip="content-box";
t.cloneNode(!0).style.backgroundClip="";
f.clearCloneStyle="content-box"===t.style.backgroundClip;
r.style.cssText="border:0;
width:8px;
height:0;
top:0;
left:-9999px;
padding:0;
margin-top:1px;
position:absolute";
r.appendChild(t);
function c(){
t.style.cssText="-webkit-box-sizing:border-box;
-moz-box-sizing:border-box;
box-sizing:border-box;
position:relative;
display:block;
margin:auto;
border:1px;
padding:1px;
top:1%;
width:50%";
t.innerHTML="";
ht.appendChild(r);
var i=n.getComputedStyle(t);
o="1%"!==i.top;
h="2px"===i.marginLeft;
e="4px"===i.width;
t.style.marginRight="50%";
s="4px"===i.marginRight;
ht.removeChild(r)}
i.extend(f,{
pixelPosition:function(){
return c(),o}
,boxSizingReliable:function(){
return null==e&&c(),e}
,pixelMarginRight:function(){
return null==e&&c(),s}
,reliableMarginLeft:function(){
return null==e&&c(),h}
,reliableMarginRight:function(){
var f,i=t.appendChild(u.createElement("div"));
return i.style.cssText=t.style.cssText="-webkit-box-sizing:content-box;
box-sizing:content-box;
display:block;
margin:0;
border:0;
padding:0",i.style.marginRight=i.style.width="0",t.style.width="1px",ht.appendChild(r),f=!parseFloat(n.getComputedStyle(i).marginRight),ht.removeChild(r),t.removeChild(i),f}
}
)}
}
();
var he=/^(none|table(?!-c[ea]).+)/,ce={
position:"absolute",visibility:"hidden",display:"block"}
,fu={
letterSpacing:"0",fontWeight:"400"}
,eu=["Webkit","O","Moz","ms"],ou=u.createElement("div").style;
i.extend({
cssHooks:{
opacity:{
get:function(n,t){
if(t){
var i=tt(n,"opacity");
return""===i?"1":i}
}
}
}
,cssNumber:{
animationIterationCount:!0,columnCount:!0,fillOpacity:!0,flexGrow:!0,flexShrink:!0,fontWeight:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0}
,cssProps:{
float:"cssFloat"}
,style:function(n,t,r,u){
if(n&&3!==n.nodeType&&8!==n.nodeType&&n.style){
var e,h,o,s=i.camelCase(t),c=n.style;
return t=i.cssProps[s]||(i.cssProps[s]=su(s)||s),o=i.cssHooks[t]||i.cssHooks[s],void 0===r?o&&"get"in o&&void 0!==(e=o.get(n,!1,u))?e:c[t]:(h=typeof r,"string"===h&&(e=ot.exec(r))&&e[1]&&(r=vr(n,t,e),h="number"),null!=r&&r===r&&("number"===h&&(r+=e&&e[3]||(i.cssNumber[s]?"":"px")),f.clearCloneStyle||""!==r||0!==t.indexOf("background")||(c[t]="inherit"),o&&"set"in o&&void 0===(r=o.set(n,r,u))||(c[t]=r)),void 0)}
}
,css:function(n,t,r,u){
var f,s,o,e=i.camelCase(t);
return t=i.cssProps[e]||(i.cssProps[e]=su(e)||e),o=i.cssHooks[t]||i.cssHooks[e],o&&"get"in o&&(f=o.get(n,!0,r)),void 0===f&&(f=tt(n,t,u)),"normal"===f&&t in fu&&(f=fu[t]),""===r||r?(s=parseFloat(f),r===!0||isFinite(s)?s||0:f):f}
}
);
i.each(["height","width"],
function(n,t){
i.cssHooks[t]={
get:function(n,r,u){
if(r)return he.test(i.css(n,"display"))&&0===n.offsetWidth?hi(n,ce,
function(){
return lu(n,t,u)}
):lu(n,t,u)}
,set:function(n,r,u){
var f,e=u&&bt(n),o=u&&cu(n,t,u,"border-box"===i.css(n,"boxSizing",!1,e),e);
return o&&(f=ot.exec(r))&&"px"!==(f[3]||"px")&&(n.style[t]=r,r=i.css(n,t)),hu(n,r,o)}
}
}
);
i.cssHooks.marginLeft=ci(f.reliableMarginLeft,
function(n,t){
if(t)return(parseFloat(tt(n,"marginLeft"))||n.getBoundingClientRect().left-hi(n,{
marginLeft:0}
,
function(){
return n.getBoundingClientRect().left}
))+"px"}
);
i.cssHooks.marginRight=ci(f.reliableMarginRight,
function(n,t){
if(t)return hi(n,{
display:"inline-block"}
,tt,[n,"marginRight"])}
);
i.each({
margin:"",padding:"",border:"Width"}
,
function(n,t){
i.cssHooks[n+t]={
expand:function(i){
for(var r=0,f={
}
,u="string"==typeof i?i.split(" "):[i];
4>r;
r++)f[n+w[r]+t]=u[r]||u[r-2]||u[0];
return f}
}
;
uu.test(n)||(i.cssHooks[n+t].set=hu)}
);
i.fn.extend({
css:function(n,t){
return a(this,
function(n,t,r){
var f,e,o={
}
,u=0;
if(i.isArray(t)){
for(f=bt(n),e=t.length;
e>u;
u++)o[t[u]]=i.css(n,t[u],!1,f);
return o}
return void 0!==r?i.style(n,t,r):i.css(n,t)}
,n,t,arguments.length>1)}
,show:function(){
return au(this,!0)}
,hide:function(){
return au(this)}
,toggle:function(n){
return"boolean"==typeof n?n?this.show():this.hide():this.each(function(){
st(this)?i(this).show():i(this).hide()}
)}
}
);
i.Tween=s;
s.prototype={
constructor:s,init:function(n,t,r,u,f,e){
this.elem=n;
this.prop=r;
this.easing=f||i.easing._default;
this.options=t;
this.start=this.now=this.cur();
this.end=u;
this.unit=e||(i.cssNumber[r]?"":"px")}
,cur:function(){
var n=s.propHooks[this.prop];
return n&&n.get?n.get(this):s.propHooks._default.get(this)}
,run:function(n){
var t,r=s.propHooks[this.prop];
return this.pos=this.options.duration?t=i.easing[this.easing](n,this.options.duration*n,0,1,this.options.duration):t=n,this.now=(this.end-this.start)*t+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),r&&r.set?r.set(this):s.propHooks._default.set(this),this}
}
;
s.prototype.init.prototype=s.prototype;
s.propHooks={
_default:{
get:function(n){
var t;
return 1!==n.elem.nodeType||null!=n.elem[n.prop]&&null==n.elem.style[n.prop]?n.elem[n.prop]:(t=i.css(n.elem,n.prop,""),t&&"auto"!==t?t:0)}
,set:function(n){
i.fx.step[n.prop]?i.fx.step[n.prop](n):1!==n.elem.nodeType||null==n.elem.style[i.cssProps[n.prop]]&&!i.cssHooks[n.prop]?n.elem[n.prop]=n.now:i.style(n.elem,n.prop,n.now+n.unit)}
}
}
;
s.propHooks.scrollTop=s.propHooks.scrollLeft={
set:function(n){
n.elem.nodeType&&n.elem.parentNode&&(n.elem[n.prop]=n.now)}
}
;
i.easing={
linear:function(n){
return n}
,swing:function(n){
return.5-Math.cos(n*Math.PI)/2}
,_default:"swing"}
;
i.fx=s.prototype.init;
i.fx.step={
}
;
vu=/^(?:toggle|show|hide)$/;
yu=/queueHooks$/;
i.Animation=i.extend(l,{
tweeners:{
"*":[function(n,t){
var i=this.createTween(n,t);
return vr(i.elem,n,ot.exec(t),i),i}
]}
,tweener:function(n,t){
i.isFunction(n)?(t=n,n=["*"]):n=n.match(h);
for(var r,u=0,f=n.length;
f>u;
u++)r=n[u],l.tweeners[r]=l.tweeners[r]||[],l.tweeners[r].unshift(t)}
,prefilters:[le],prefilter:function(n,t){
t?l.prefilters.unshift(n):l.prefilters.push(n)}
}
);
i.speed=function(n,t,r){
var u=n&&"object"==typeof n?i.extend({
}
,n):{
complete:r||!r&&t||i.isFunction(n)&&n,duration:n,easing:r&&t||t&&!i.isFunction(t)&&t}
;
return u.duration=i.fx.off?0:"number"==typeof u.duration?u.duration:u.duration in i.fx.speeds?i.fx.speeds[u.duration]:i.fx.speeds._default,null!=u.queue&&u.queue!==!0||(u.queue="fx"),u.old=u.complete,u.complete=function(){
i.isFunction(u.old)&&u.old.call(this);
u.queue&&i.dequeue(this,u.queue)}
,u}
;
i.fn.extend({
fadeTo:function(n,t,i,r){
return this.filter(st).css("opacity",0).show().end().animate({
opacity:t}
,n,i,r)}
,animate:function(n,t,u,f){
var s=i.isEmptyObject(n),o=i.speed(t,u,f),e=function(){
var t=l(this,i.extend({
}
,n),o);
(s||r.get(this,"finish"))&&t.stop(!0)}
;
return e.finish=e,s||o.queue===!1?this.each(e):this.queue(o.queue,e)}
,stop:function(n,t,u){
var f=function(n){
var t=n.stop;
delete n.stop;
t(u)}
;
return"string"!=typeof n&&(u=t,t=n,n=void 0),t&&n!==!1&&this.queue(n||"fx",[]),this.each(function(){
var s=!0,t=null!=n&&n+"queueHooks",o=i.timers,e=r.get(this);
if(t)e[t]&&e[t].stop&&f(e[t]);
else for(t in e)e[t]&&e[t].stop&&yu.test(t)&&f(e[t]);
for(t=o.length;
t--;
)o[t].elem!==this||null!=n&&o[t].queue!==n||(o[t].anim.stop(u),s=!1,o.splice(t,1));
!s&&u||i.dequeue(this,n)}
)}
,finish:function(n){
return n!==!1&&(n=n||"fx"),this.each(function(){
var t,e=r.get(this),u=e[n+"queue"],o=e[n+"queueHooks"],f=i.timers,s=u?u.length:0;
for(e.finish=!0,i.queue(this,n,[]),o&&o.stop&&o.stop.call(this,!0),t=f.length;
t--;
)f[t].elem===this&&f[t].queue===n&&(f[t].anim.stop(!0),f.splice(t,1));
for(t=0;
s>t;
t++)u[t]&&u[t].finish&&u[t].finish.call(this);
delete e.finish}
)}
}
);
i.each(["toggle","show","hide"],
function(n,t){
var r=i.fn[t];
i.fn[t]=function(n,i,u){
return null==n||"boolean"==typeof n?r.apply(this,arguments):this.animate(dt(t,!0),n,i,u)}
}
);
i.each({
slideDown:dt("show"),slideUp:dt("hide"),slideToggle:dt("toggle"),fadeIn:{
opacity:"show"}
,fadeOut:{
opacity:"hide"}
,fadeToggle:{
opacity:"toggle"}
}
,
function(n,t){
i.fn[n]=function(n,i,r){
return this.animate(t,n,i,r)}
}
);
i.timers=[];
i.fx.tick=function(){
var r,n=0,t=i.timers;
for(it=i.now();
n<t.length;
n++)r=t[n],r()||t[n]!==r||t.splice(n--,1);
t.length||i.fx.stop();
it=void 0}
;
i.fx.timer=function(n){
i.timers.push(n);
n()?i.fx.start():i.timers.pop()}
;
i.fx.interval=13;
i.fx.start=function(){
kt||(kt=n.setInterval(i.fx.tick,i.fx.interval))}
;
i.fx.stop=function(){
n.clearInterval(kt);
kt=null}
;
i.fx.speeds={
slow:600,fast:200,_default:400}
;
i.fn.delay=function(t,r){
return t=i.fx?i.fx.speeds[t]||t:t,r=r||"fx",this.queue(r,
function(i,r){
var u=n.setTimeout(i,t);
r.stop=function(){
n.clearTimeout(u)}
}
)}
,
function(){
var n=u.createElement("input"),t=u.createElement("select"),i=t.appendChild(u.createElement("option"));
n.type="checkbox";
f.checkOn=""!==n.value;
f.optSelected=i.selected;
t.disabled=!0;
f.optDisabled=!i.disabled;
n=u.createElement("input");
n.value="t";
n.type="radio";
f.radioValue="t"===n.value}
();
rt=i.expr.attrHandle;
i.fn.extend({
attr:function(n,t){
return a(this,i.attr,n,t,arguments.length>1)}
,removeAttr:function(n){
return this.each(function(){
i.removeAttr(this,n)}
)}
}
);
i.extend({
attr:function(n,t,r){
var u,f,e=n.nodeType;
if(3!==e&&8!==e&&2!==e)return"undefined"==typeof n.getAttribute?i.prop(n,t,r):(1===e&&i.isXMLDoc(n)||(t=t.toLowerCase(),f=i.attrHooks[t]||(i.expr.match.bool.test(t)?bu:void 0)),void 0!==r?null===r?void i.removeAttr(n,t):f&&"set"in f&&void 0!==(u=f.set(n,r,t))?u:(n.setAttribute(t,r+""),r):f&&"get"in f&&null!==(u=f.get(n,t))?u:(u=i.find.attr(n,t),null==u?void 0:u))}
,attrHooks:{
type:{
set:function(n,t){
if(!f.radioValue&&"radio"===t&&i.nodeName(n,"input")){
var r=n.value;
return n.setAttribute("type",t),r&&(n.value=r),t}
}
}
}
,removeAttr:function(n,t){
var r,u,e=0,f=t&&t.match(h);
if(f&&1===n.nodeType)while(r=f[e++])u=i.propFix[r]||r,i.expr.match.bool.test(r)&&(n[u]=!1),n.removeAttribute(r)}
}
);
bu={
set:function(n,t,r){
return t===!1?i.removeAttr(n,r):n.setAttribute(r,r),r}
}
;
i.each(i.expr.match.bool.source.match(/\w+/g),
function(n,t){
var r=rt[t]||i.find.attr;
rt[t]=function(n,t,i){
var u,f;
return i||(f=rt[t],rt[t]=u,u=null!=r(n,t,i)?t.toLowerCase():null,rt[t]=f),u}
}
);
ku=/^(?:input|select|textarea|button)$/i;
du=/^(?:a|area)$/i;
i.fn.extend({
prop:function(n,t){
return a(this,i.prop,n,t,arguments.length>1)}
,removeProp:function(n){
return this.each(function(){
delete this[i.propFix[n]||n]}
)}
}
);
i.extend({
prop:function(n,t,r){
var f,u,e=n.nodeType;
if(3!==e&&8!==e&&2!==e)return 1===e&&i.isXMLDoc(n)||(t=i.propFix[t]||t,u=i.propHooks[t]),void 0!==r?u&&"set"in u&&void 0!==(f=u.set(n,r,t))?f:n[t]=r:u&&"get"in u&&null!==(f=u.get(n,t))?f:n[t]}
,propHooks:{
tabIndex:{
get:function(n){
var t=i.find.attr(n,"tabindex");
return t?parseInt(t,10):ku.test(n.nodeName)||du.test(n.nodeName)&&n.href?0:-1}
}
}
,propFix:{
"for":"htmlFor","class":"className"}
}
);
f.optSelected||(i.propHooks.selected={
get:function(n){
var t=n.parentNode;
return t&&t.parentNode&&t.parentNode.selectedIndex,null}
,set:function(n){
var t=n.parentNode;
t&&(t.selectedIndex,t.parentNode&&t.parentNode.selectedIndex)}
}
);
i.each(["tabIndex","readOnly","maxLength","cellSpacing","cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"],
function(){
i.propFix[this.toLowerCase()]=this}
);
gt=/[\t\r\n\f]/g;
i.fn.extend({
addClass:function(n){
var o,t,r,u,f,s,e,c=0;
if(i.isFunction(n))return this.each(function(t){
i(this).addClass(n.call(this,t,k(this)))}
);
if("string"==typeof n&&n)for(o=n.match(h)||[];
t=this[c++];
)if(u=k(t),r=1===t.nodeType&&(" "+u+" ").replace(gt," ")){
for(s=0;
f=o[s++];
)r.indexOf(" "+f+" ")<0&&(r+=f+" ");
e=i.trim(r);
u!==e&&t.setAttribute("class",e)}
return this}
,removeClass:function(n){
var o,r,t,u,f,s,e,c=0;
if(i.isFunction(n))return this.each(function(t){
i(this).removeClass(n.call(this,t,k(this)))}
);
if(!arguments.length)return this.attr("class","");
if("string"==typeof n&&n)for(o=n.match(h)||[];
r=this[c++];
)if(u=k(r),t=1===r.nodeType&&(" "+u+" ").replace(gt," ")){
for(s=0;
f=o[s++];
)while(t.indexOf(" "+f+" ")>-1)t=t.replace(" "+f+" "," ");
e=i.trim(t);
u!==e&&r.setAttribute("class",e)}
return this}
,toggleClass:function(n,t){
var u=typeof n;
return"boolean"==typeof t&&"string"===u?t?this.addClass(n):this.removeClass(n):i.isFunction(n)?this.each(function(r){
i(this).toggleClass(n.call(this,r,k(this),t),t)}
):this.each(function(){
var t,e,f,o;
if("string"===u)for(e=0,f=i(this),o=n.match(h)||[];
t=o[e++];
)f.hasClass(t)?f.removeClass(t):f.addClass(t);
else void 0!==n&&"boolean"!==u||(t=k(this),t&&r.set(this,"__className__",t),this.setAttribute&&this.setAttribute("class",t||n===!1?"":r.get(this,"__className__")||""))}
)}
,hasClass:function(n){
for(var t,r=0,i=" "+n+" ";
t=this[r++];
)if(1===t.nodeType&&(" "+k(t)+" ").replace(gt," ").indexOf(i)>-1)return!0;
return!1}
}
);
gu=/\r/g;
nf=/[\x20\t\r\n\f]+/g;
i.fn.extend({
val:function(n){
var t,r,f,u=this[0];
return arguments.length?(f=i.isFunction(n),this.each(function(r){
var u;
1===this.nodeType&&(u=f?n.call(this,r,i(this).val()):n,null==u?u="":"number"==typeof u?u+="":i.isArray(u)&&(u=i.map(u,
function(n){
return null==n?"":n+""}
)),t=i.valHooks[this.type]||i.valHooks[this.nodeName.toLowerCase()],t&&"set"in t&&void 0!==t.set(this,u,"value")||(this.value=u))}
)):u?(t=i.valHooks[u.type]||i.valHooks[u.nodeName.toLowerCase()],t&&"get"in t&&void 0!==(r=t.get(u,"value"))?r:(r=u.value,"string"==typeof r?r.replace(gu,""):null==r?"":r)):void 0}
}
);
i.extend({
valHooks:{
option:{
get:function(n){
var t=i.find.attr(n,"value");
return null!=t?t:i.trim(i.text(n)).replace(nf," ")}
}
,select:{
get:function(n){
for(var o,t,s=n.options,r=n.selectedIndex,u="select-one"===n.type||0>r,h=u?null:[],c=u?r+1:s.length,e=0>r?c:u?r:0;
c>e;
e++)if(t=s[e],(t.selected||e===r)&&(f.optDisabled?!t.disabled:null===t.getAttribute("disabled"))&&(!t.parentNode.disabled||!i.nodeName(t.parentNode,"optgroup"))){
if(o=i(t).val(),u)return o;
h.push(o)}
return h}
,set:function(n,t){
for(var u,r,f=n.options,e=i.makeArray(t),o=f.length;
o--;
)r=f[o],(r.selected=i.inArray(i.valHooks.option.get(r),e)>-1)&&(u=!0);
return u||(n.selectedIndex=-1),e}
}
}
}
);
i.each(["radio","checkbox"],
function(){
i.valHooks[this]={
set:function(n,t){
if(i.isArray(t))return n.checked=i.inArray(i(n).val(),t)>-1}
}
;
f.checkOn||(i.valHooks[this].get=function(n){
return null===n.getAttribute("value")?"on":n.value}
)}
);
li=/^(?:focusinfocus|focusoutblur)$/;
i.extend(i.event,{
trigger:function(t,f,e,o){
var w,s,c,b,a,v,l,p=[e||u],h=ft.call(t,"type")?t.type:t,y=ft.call(t,"namespace")?t.namespace.split("."):[];
if(s=c=e=e||u,3!==e.nodeType&&8!==e.nodeType&&!li.test(h+i.event.triggered)&&(h.indexOf(".")>-1&&(y=h.split("."),h=y.shift(),y.sort()),a=h.indexOf(":")<0&&"on"+h,t=t[i.expando]?t:new i.Event(h,"object"==typeof t&&t),t.isTrigger=o?2:3,t.namespace=y.join("."),t.rnamespace=t.namespace?new RegExp("(^|\\.)"+y.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,t.result=void 0,t.target||(t.target=e),f=null==f?[t]:i.makeArray(f,[t]),l=i.event.special[h]||{
}
,o||!l.trigger||l.trigger.apply(e,f)!==!1)){
if(!o&&!l.noBubble&&!i.isWindow(e)){
for(b=l.delegateType||h,li.test(b+h)||(s=s.parentNode);
s;
s=s.parentNode)p.push(s),c=s;
c===(e.ownerDocument||u)&&p.push(c.defaultView||c.parentWindow||n)}
for(w=0;
(s=p[w++])&&!t.isPropagationStopped();
)t.type=w>1?b:l.bindType||h,v=(r.get(s,"events")||{
}
)[t.type]&&r.get(s,"handle"),v&&v.apply(s,f),v=a&&s[a],v&&v.apply&&g(s)&&(t.result=v.apply(s,f),t.result===!1&&t.preventDefault());
return t.type=h,o||t.isDefaultPrevented()||l._default&&l._default.apply(p.pop(),f)!==!1||!g(e)||a&&i.isFunction(e[h])&&!i.isWindow(e)&&(c=e[a],c&&(e[a]=null),i.event.triggered=h,e[h](),i.event.triggered=void 0,c&&(e[a]=c)),t.result}
}
,simulate:function(n,t,r){
var u=i.extend(new i.Event,r,{
type:n,isSimulated:!0}
);
i.event.trigger(u,null,t);
u.isDefaultPrevented()&&r.preventDefault()}
}
);
i.fn.extend({
trigger:function(n,t){
return this.each(function(){
i.event.trigger(n,t,this)}
)}
,triggerHandler:function(n,t){
var r=this[0];
if(r)return i.event.trigger(n,t,r,!0)}
}
);
i.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),
function(n,t){
i.fn[t]=function(n,i){
return arguments.length>0?this.on(t,null,n,i):this.trigger(t)}
}
);
i.fn.extend({
hover:function(n,t){
return this.mouseenter(n).mouseleave(t||n)}
}
);
f.focusin="onfocusin"in n;
f.focusin||i.each({
focus:"focusin",blur:"focusout"}
,
function(n,t){
var u=function(n){
i.event.simulate(t,n.target,i.event.fix(n))}
;
i.event.special[t]={
setup:function(){
var i=this.ownerDocument||this,f=r.access(i,t);
f||i.addEventListener(n,u,!0);
r.access(i,t,(f||0)+1)}
,teardown:function(){
var i=this.ownerDocument||this,f=r.access(i,t)-1;
f?r.access(i,t,f):(i.removeEventListener(n,u,!0),r.remove(i,t))}
}
}
);
var ct=n.location,ai=i.now(),vi=/\?/;
i.parseJSON=function(n){
return JSON.parse(n+"")}
;
i.parseXML=function(t){
var r;
if(!t||"string"!=typeof t)return null;
try{
r=(new n.DOMParser).parseFromString(t,"text/xml")}
catch(u){
r=void 0}
return r&&!r.getElementsByTagName("parsererror").length||i.error("Invalid XML: "+t),r}
;
var ve=/#.*$/,tf=/([?&])_=[^&]*/,ye=/^(.*?):[ \t]*([^\r\n]*)$/gm,pe=/^(?:GET|HEAD)$/,we=/^\/\//,rf={
}
,yi={
}
,uf="*/".concat("*"),pi=u.createElement("a");
pi.href=ct.href;
i.extend({
active:0,lastModified:{
}
,etag:{
}
,ajaxSettings:{
url:ct.href,type:"GET",isLocal:/^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(ct.protocol),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded;
 charset=UTF-8",accepts:{
"*":uf,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"}
,contents:{
xml:/\bxml\b/,html:/\bhtml/,json:/\bjson\b/}
,responseFields:{
xml:"responseXML",text:"responseText",json:"responseJSON"}
,converters:{
"* text":String,"text html":!0,"text json":i.parseJSON,"text xml":i.parseXML}
,flatOptions:{
url:!0,context:!0}
}
,ajaxSetup:function(n,t){
return t?wi(wi(n,i.ajaxSettings),t):wi(i.ajaxSettings,n)}
,ajaxPrefilter:ff(rf),ajaxTransport:ff(yi),ajax:function(t,r){
function b(t,r,u,h){
var a,rt,it,p,b,l=r;
2!==s&&(s=2,d&&n.clearTimeout(d),v=void 0,k=h||"",e.readyState=t>0?4:0,a=t>=200&&300>t||304===t,u&&(p=be(f,e,u)),p=ke(f,p,e,a),a?(f.ifModified&&(b=e.getResponseHeader("Last-Modified"),b&&(i.lastModified[o]=b),b=e.getResponseHeader("etag"),b&&(i.etag[o]=b)),204===t||"HEAD"===f.type?l="nocontent":304===t?l="notmodified":(l=p.state,rt=p.data,it=p.error,a=!it)):(it=l,!t&&l||(l="error",0>t&&(t=0))),e.status=t,e.statusText=(r||l)+"",a?nt.resolveWith(c,[rt,l,e]):nt.rejectWith(c,[e,l,it]),e.statusCode(w),w=void 0,y&&g.trigger(a?"ajaxSuccess":"ajaxError",[e,f,a?rt:it]),tt.fireWith(c,[e,l]),y&&(g.trigger("ajaxComplete",[e,f]),--i.active||i.event.trigger("ajaxStop")))}
"object"==typeof t&&(r=t,t=void 0);
r=r||{
}
;
var v,o,k,p,d,l,y,a,f=i.ajaxSetup({
}
,r),c=f.context||f,g=f.context&&(c.nodeType||c.jquery)?i(c):i.event,nt=i.Deferred(),tt=i.Callbacks("once memory"),w=f.statusCode||{
}
,it={
}
,rt={
}
,s=0,ut="canceled",e={
readyState:0,getResponseHeader:function(n){
var t;
if(2===s){
if(!p)for(p={
}
;
t=ye.exec(k);
)p[t[1].toLowerCase()]=t[2];
t=p[n.toLowerCase()]}
return null==t?null:t}
,getAllResponseHeaders:function(){
return 2===s?k:null}
,setRequestHeader:function(n,t){
var i=n.toLowerCase();
return s||(n=rt[i]=rt[i]||n,it[n]=t),this}
,overrideMimeType:function(n){
return s||(f.mimeType=n),this}
,statusCode:function(n){
var t;
if(n)if(2>s)for(t in n)w[t]=[w[t],n[t]];
else e.always(n[e.status]);
return this}
,abort:function(n){
var t=n||ut;
return v&&v.abort(t),b(0,t),this}
}
;
if(nt.promise(e).complete=tt.add,e.success=e.done,e.error=e.fail,f.url=((t||f.url||ct.href)+"").replace(ve,"").replace(we,ct.protocol+"//"),f.type=r.method||r.type||f.method||f.type,f.dataTypes=i.trim(f.dataType||"*").toLowerCase().match(h)||[""],null==f.crossDomain){
l=u.createElement("a");
try{
l.href=f.url;
l.href=l.href;
f.crossDomain=pi.protocol+"//"+pi.host!=l.protocol+"//"+l.host}
catch(ft){
f.crossDomain=!0}
}
if(f.data&&f.processData&&"string"!=typeof f.data&&(f.data=i.param(f.data,f.traditional)),ef(rf,f,r,e),2===s)return e;
y=i.event&&f.global;
y&&0==i.active++&&i.event.trigger("ajaxStart");
f.type=f.type.toUpperCase();
f.hasContent=!pe.test(f.type);
o=f.url;
f.hasContent||(f.data&&(o=f.url+=(vi.test(o)?"&":"?")+f.data,delete f.data),f.cache===!1&&(f.url=tf.test(o)?o.replace(tf,"$1_="+ai++):o+(vi.test(o)?"&":"?")+"_="+ai++));
f.ifModified&&(i.lastModified[o]&&e.setRequestHeader("If-Modified-Since",i.lastModified[o]),i.etag[o]&&e.setRequestHeader("If-None-Match",i.etag[o]));
(f.data&&f.hasContent&&f.contentType!==!1||r.contentType)&&e.setRequestHeader("Content-Type",f.contentType);
e.setRequestHeader("Accept",f.dataTypes[0]&&f.accepts[f.dataTypes[0]]?f.accepts[f.dataTypes[0]]+("*"!==f.dataTypes[0]?", "+uf+";
 q=0.01":""):f.accepts["*"]);
for(a in f.headers)e.setRequestHeader(a,f.headers[a]);
if(f.beforeSend&&(f.beforeSend.call(c,e,f)===!1||2===s))return e.abort();
ut="abort";
for(a in{
success:1,error:1,complete:1}
)e[a](f[a]);
if(v=ef(yi,f,r,e)){
if(e.readyState=1,y&&g.trigger("ajaxSend",[e,f]),2===s)return e;
f.async&&f.timeout>0&&(d=n.setTimeout(function(){
e.abort("timeout")}
,f.timeout));
try{
s=1;
v.send(it,b)}
catch(ft){
if(!(2>s))throw ft;
b(-1,ft)}
}
else b(-1,"No Transport");
return e}
,getJSON:function(n,t,r){
return i.get(n,t,r,"json")}
,getScript:function(n,t){
return i.get(n,void 0,t,"script")}
}
);
i.each(["get","post"],
function(n,t){
i[t]=function(n,r,u,f){
return i.isFunction(r)&&(f=f||u,u=r,r=void 0),i.ajax(i.extend({
url:n,type:t,dataType:f,data:r,success:u}
,i.isPlainObject(n)&&n))}
}
);
i._evalUrl=function(n){
return i.ajax({
url:n,type:"GET",dataType:"script",async:!1,global:!1,throws:!0}
)}
;
i.fn.extend({
wrapAll:function(n){
var t;
return i.isFunction(n)?this.each(function(t){
i(this).wrapAll(n.call(this,t))}
):(this[0]&&(t=i(n,this[0].ownerDocument).eq(0).clone(!0),this[0].parentNode&&t.insertBefore(this[0]),t.map(function(){
for(var n=this;
n.firstElementChild;
)n=n.firstElementChild;
return n}
).append(this)),this)}
,wrapInner:function(n){
return i.isFunction(n)?this.each(function(t){
i(this).wrapInner(n.call(this,t))}
):this.each(function(){
var t=i(this),r=t.contents();
r.length?r.wrapAll(n):t.append(n)}
)}
,wrap:function(n){
var t=i.isFunction(n);
return this.each(function(r){
i(this).wrapAll(t?n.call(this,r):n)}
)}
,unwrap:function(){
return this.parent().each(function(){
i.nodeName(this,"body")||i(this).replaceWith(this.childNodes)}
).end()}
}
);
i.expr.filters.hidden=function(n){
return!i.expr.filters.visible(n)}
;
i.expr.filters.visible=function(n){
return n.offsetWidth>0||n.offsetHeight>0||n.getClientRects().length>0}
;
var de=/%20/g,ge=/\[\]$/,of=/\r?\n/g,no=/^(?:submit|button|image|reset|file)$/i,to=/^(?:input|select|textarea|keygen)/i;
return i.param=function(n,t){
var r,u=[],f=function(n,t){
t=i.isFunction(t)?t():null==t?"":t;
u[u.length]=encodeURIComponent(n)+"="+encodeURIComponent(t)}
;
if(void 0===t&&(t=i.ajaxSettings&&i.ajaxSettings.traditional),i.isArray(n)||n.jquery&&!i.isPlainObject(n))i.each(n,
function(){
f(this.name,this.value)}
);
else for(r in n)bi(r,n[r],t,f);
return u.join("&").replace(de,"+")}
,i.fn.extend({
serialize:function(){
return i.param(this.serializeArray())}
,serializeArray:function(){
return this.map(function(){
var n=i.prop(this,"elements");
return n?i.makeArray(n):this}
).filter(function(){
var n=this.type;
return this.name&&!i(this).is(":disabled")&&to.test(this.nodeName)&&!no.test(n)&&(this.checked||!yr.test(n))}
).map(function(n,t){
var r=i(this).val();
return null==r?null:i.isArray(r)?i.map(r,
function(n){
return{
name:t.name,value:n.replace(of,"\r\n")}
}
):{
name:t.name,value:r.replace(of,"\r\n")}
}
).get()}
}
),i.ajaxSettings.xhr=function(){
try{
return new n.XMLHttpRequest}
catch(t){
}
}
,sf={
0:200,1223:204}
,ut=i.ajaxSettings.xhr(),f.cors=!!ut&&"withCredentials"in ut,f.ajax=ut=!!ut,i.ajaxTransport(function(t){
var i,r;
if(f.cors||ut&&!t.crossDomain)return{
send:function(u,f){
var o,e=t.xhr();
if(e.open(t.type,t.url,t.async,t.username,t.password),t.xhrFields)for(o in t.xhrFields)e[o]=t.xhrFields[o];
t.mimeType&&e.overrideMimeType&&e.overrideMimeType(t.mimeType);
t.crossDomain||u["X-Requested-With"]||(u["X-Requested-With"]="XMLHttpRequest");
for(o in u)e.setRequestHeader(o,u[o]);
i=function(n){
return function(){
i&&(i=r=e.onload=e.onerror=e.onabort=e.onreadystatechange=null,"abort"===n?e.abort():"error"===n?"number"!=typeof e.status?f(0,"error"):f(e.status,e.statusText):f(sf[e.status]||e.status,e.statusText,"text"!==(e.responseType||"text")||"string"!=typeof e.responseText?{
binary:e.response}
:{
text:e.responseText}
,e.getAllResponseHeaders()))}
}
;
e.onload=i();
r=e.onerror=i("error");
void 0!==e.onabort?e.onabort=r:e.onreadystatechange=function(){
4===e.readyState&&n.setTimeout(function(){
i&&r()}
)}
;
i=i("abort");
try{
e.send(t.hasContent&&t.data||null)}
catch(s){
if(i)throw s;
}
}
,abort:function(){
i&&i()}
}
}
),i.ajaxSetup({
accepts:{
script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"}
,contents:{
script:/\b(?:java|ecma)script\b/}
,converters:{
"text script":function(n){
return i.globalEval(n),n}
}
}
),i.ajaxPrefilter("script",
function(n){
void 0===n.cache&&(n.cache=!1);
n.crossDomain&&(n.type="GET")}
),i.ajaxTransport("script",
function(n){
if(n.crossDomain){
var r,t;
return{
send:function(f,e){
r=i("<script>").prop({
charset:n.scriptCharset,src:n.url}
).on("load error",t=function(n){
r.remove();
t=null;
n&&e("error"===n.type?404:200,n.type)}
);
u.head.appendChild(r[0])}
,abort:function(){
t&&t()}
}
}
}
),ki=[],ni=/(=)\?(?=&|$)|\?\?/,i.ajaxSetup({
jsonp:"callback",jsonpCallback:function(){
var n=ki.pop()||i.expando+"_"+ai++;
return this[n]=!0,n}
}
),i.ajaxPrefilter("json jsonp",
function(t,r,u){
var f,e,o,s=t.jsonp!==!1&&(ni.test(t.url)?"url":"string"==typeof t.data&&0===(t.contentType||"").indexOf("application/x-www-form-urlencoded")&&ni.test(t.data)&&"data");
if(s||"jsonp"===t.dataTypes[0])return(f=t.jsonpCallback=i.isFunction(t.jsonpCallback)?t.jsonpCallback():t.jsonpCallback,s?t[s]=t[s].replace(ni,"$1"+f):t.jsonp!==!1&&(t.url+=(vi.test(t.url)?"&":"?")+t.jsonp+"="+f),t.converters["script json"]=function(){
return o||i.error(f+" was not called"),o[0]}
,t.dataTypes[0]="json",e=n[f],n[f]=function(){
o=arguments}
,u.always(function(){
void 0===e?i(n).removeProp(f):n[f]=e;
t[f]&&(t.jsonpCallback=r.jsonpCallback,ki.push(f));
o&&i.isFunction(e)&&e(o[0]);
o=e=void 0}
),"script")}
),i.parseHTML=function(n,t,r){
if(!n||"string"!=typeof n)return null;
"boolean"==typeof t&&(r=t,t=!1);
t=t||u;
var f=rr.exec(n),e=!r&&[];
return f?[t.createElement(f[1])]:(f=kr([n],t,e),e&&e.length&&i(e).remove(),i.merge([],f.childNodes))}
,di=i.fn.load,i.fn.load=function(n,t,r){
if("string"!=typeof n&&di)return di.apply(this,arguments);
var u,o,s,f=this,e=n.indexOf(" ");
return e>-1&&(u=i.trim(n.slice(e)),n=n.slice(0,e)),i.isFunction(t)?(r=t,t=void 0):t&&"object"==typeof t&&(o="POST"),f.length>0&&i.ajax({
url:n,type:o||"GET",dataType:"html",data:t}
).done(function(n){
s=arguments;
f.html(u?i("<div>").append(i.parseHTML(n)).find(u):n)}
).always(r&&function(n,t){
f.each(function(){
r.apply(this,s||[n.responseText,t,n])}
)}
),this}
,i.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],
function(n,t){
i.fn[t]=function(n){
return this.on(t,n)}
}
),i.expr.filters.animated=function(n){
return i.grep(i.timers,
function(t){
return n===t.elem}
).length}
,i.offset={
setOffset:function(n,t,r){
var e,o,s,h,u,c,v,l=i.css(n,"position"),a=i(n),f={
}
;
"static"===l&&(n.style.position="relative");
u=a.offset();
s=i.css(n,"top");
c=i.css(n,"left");
v=("absolute"===l||"fixed"===l)&&(s+c).indexOf("auto")>-1;
v?(e=a.position(),h=e.top,o=e.left):(h=parseFloat(s)||0,o=parseFloat(c)||0);
i.isFunction(t)&&(t=t.call(n,r,i.extend({
}
,u)));
null!=t.top&&(f.top=t.top-u.top+h);
null!=t.left&&(f.left=t.left-u.left+o);
"using"in t?t.using.call(n,f):a.css(f)}
}
,i.fn.extend({
offset:function(n){
if(arguments.length)return void 0===n?this:this.each(function(t){
i.offset.setOffset(this,n,t)}
);
var t,f,r=this[0],u={
top:0,left:0}
,e=r&&r.ownerDocument;
if(e)return t=e.documentElement,i.contains(t,r)?(u=r.getBoundingClientRect(),f=hf(e),{
top:u.top+f.pageYOffset-t.clientTop,left:u.left+f.pageXOffset-t.clientLeft}
):u}
,position:function(){
if(this[0]){
var n,r,u=this[0],t={
top:0,left:0}
;
return"fixed"===i.css(u,"position")?r=u.getBoundingClientRect():(n=this.offsetParent(),r=this.offset(),i.nodeName(n[0],"html")||(t=n.offset()),t.top+=i.css(n[0],"borderTopWidth",!0),t.left+=i.css(n[0],"borderLeftWidth",!0)),{
top:r.top-t.top-i.css(u,"marginTop",!0),left:r.left-t.left-i.css(u,"marginLeft",!0)}
}
}
,offsetParent:function(){
return this.map(function(){
for(var n=this.offsetParent;
n&&"static"===i.css(n,"position");
)n=n.offsetParent;
return n||ht}
)}
}
),i.each({
scrollLeft:"pageXOffset",scrollTop:"pageYOffset"}
,
function(n,t){
var r="pageYOffset"===t;
i.fn[n]=function(i){
return a(this,
function(n,i,u){
var f=hf(n);
return void 0===u?f?f[t]:n[i]:void(f?f.scrollTo(r?f.pageXOffset:u,r?u:f.pageYOffset):n[i]=u)}
,n,i,arguments.length)}
}
),i.each(["top","left"],
function(n,t){
i.cssHooks[t]=ci(f.pixelPosition,
function(n,r){
if(r)return(r=tt(n,t),si.test(r)?i(n).position()[t]+"px":r)}
)}
),i.each({
Height:"height",Width:"width"}
,
function(n,t){
i.each({
padding:"inner"+n,content:t,"":"outer"+n}
,
function(r,u){
i.fn[u]=function(u,f){
var e=arguments.length&&(r||"boolean"!=typeof u),o=r||(u===!0||f===!0?"margin":"border");
return a(this,
function(t,r,u){
var f;
return i.isWindow(t)?t.document.documentElement["client"+n]:9===t.nodeType?(f=t.documentElement,Math.max(t.body["scroll"+n],f["scroll"+n],t.body["offset"+n],f["offset"+n],f["client"+n])):void 0===u?i.css(t,r,o):i.style(t,r,u,o)}
,t,e?u:void 0,e,null)}
}
)}
),i.fn.extend({
bind:function(n,t,i){
return this.on(n,null,t,i)}
,unbind:function(n,t){
return this.off(n,null,t)}
,delegate:function(n,t,i,r){
return this.on(t,n,i,r)}
,undelegate:function(n,t,i){
return 1===arguments.length?this.off(n,"**"):this.off(t,n||"**",i)}
,size:function(){
return this.length}
}
),i.fn.andSelf=i.fn.addBack,"function"==typeof define&&define.amd&&define("jquery",[],
function(){
return i}
),cf=n.jQuery,lf=n.$,i.noConflict=function(t){
return n.$===i&&(n.$=lf),t&&n.jQuery===i&&(n.jQuery=cf),i}
,t||(n.jQuery=n.$=i),i}
),!function(n){
"function"==typeof define&&define.amd?define(["jquery"],n):"object"==typeof module&&module.exports?module.exports=n(require("jquery")):n(jQuery)}
(function(n){
n.extend(n.fn,{
validate:function(t){
if(!this.length)return void(t&&t.debug&&window.console&&console.warn("Nothing selected, can't validate, returning nothing."));
var i=n.data(this[0],"validator");
return i?i:(this.attr("novalidate","novalidate"),i=new n.validator(t,this[0]),n.data(this[0],"validator",i),i.settings.onsubmit&&(this.on("click.validate",":submit",
function(t){
i.settings.submitHandler&&(i.submitButton=t.target);
n(this).hasClass("cancel")&&(i.cancelSubmit=!0);
void 0!==n(this).attr("formnovalidate")&&(i.cancelSubmit=!0)}
),this.on("submit.validate",
function(t){
function r(){
var u,r;
return!i.settings.submitHandler||(i.submitButton&&(u=n("<input type='hidden'/>").attr("name",i.submitButton.name).val(n(i.submitButton).val()).appendTo(i.currentForm)),r=i.settings.submitHandler.call(i,i.currentForm,t),i.submitButton&&u.remove(),void 0!==r&&r)}
return i.settings.debug&&t.preventDefault(),i.cancelSubmit?(i.cancelSubmit=!1,r()):i.form()?i.pendingRequest?(i.formSubmitted=!0,!1):r():(i.focusInvalid(),!1)}
)),i)}
,valid:function(){
var t,i,r;
return n(this[0]).is("form")?t=this.validate().form():(r=[],t=!0,i=n(this[0].form).validate(),this.each(function(){
t=i.element(this)&&t;
t||(r=r.concat(i.errorList))}
),i.errorList=r),t}
,rules:function(t,i){
var e,s,f,u,o,h,r=this[0];
if(null!=r&&null!=r.form){
if(t)switch(e=n.data(r.form,"validator").settings,s=e.rules,f=n.validator.staticRules(r),t){
case"add":n.extend(f,n.validator.normalizeRule(i));
delete f.messages;
s[r.name]=f;
i.messages&&(e.messages[r.name]=n.extend(e.messages[r.name],i.messages));
break;
case"remove":return i?(h={
}
,n.each(i.split(/\s/),
function(t,i){
h[i]=f[i];
delete f[i];
"required"===i&&n(r).removeAttr("aria-required")}
),h):(delete s[r.name],f)}
return u=n.validator.normalizeRules(n.extend({
}
,n.validator.classRules(r),n.validator.attributeRules(r),n.validator.dataRules(r),n.validator.staticRules(r)),r),u.required&&(o=u.required,delete u.required,u=n.extend({
required:o}
,u),n(r).attr("aria-required","true")),u.remote&&(o=u.remote,delete u.remote,u=n.extend(u,{
remote:o}
)),u}
}
}
);
n.extend(n.expr[":"],{
blank:function(t){
return!n.trim(""+n(t).val())}
,filled:function(t){
var i=n(t).val();
return null!==i&&!!n.trim(""+i)}
,unchecked:function(t){
return!n(t).prop("checked")}
}
);
n.validator=function(t,i){
this.settings=n.extend(!0,{
}
,n.validator.defaults,t);
this.currentForm=i;
this.init()}
;
n.validator.format=function(t,i){
return 1===arguments.length?function(){
var i=n.makeArray(arguments);
return i.unshift(t),n.validator.format.apply(this,i)}
:void 0===i?t:(arguments.length>2&&i.constructor!==Array&&(i=n.makeArray(arguments).slice(1)),i.constructor!==Array&&(i=[i]),n.each(i,
function(n,i){
t=t.replace(new RegExp("\\{
"+n+"\\}
","g"),
function(){
return i}
)}
),t)}
;
n.extend(n.validator,{
defaults:{
messages:{
}
,groups:{
}
,rules:{
}
,errorClass:"error",pendingClass:"pending",validClass:"valid",errorElement:"label",focusCleanup:!1,focusInvalid:!0,errorContainer:n([]),errorLabelContainer:n([]),onsubmit:!0,ignore:":hidden",ignoreTitle:!1,onfocusin:function(n){
this.lastActive=n;
this.settings.focusCleanup&&(this.settings.unhighlight&&this.settings.unhighlight.call(this,n,this.settings.errorClass,this.settings.validClass),this.hideThese(this.errorsFor(n)))}
,onfocusout:function(n){
!this.checkable(n)&&(n.name in this.submitted||!this.optional(n))&&this.element(n)}
,onkeyup:function(t,i){
9===i.which&&""===this.elementValue(t)||n.inArray(i.keyCode,[16,17,18,20,35,36,37,38,39,40,45,144,225])!==-1||(t.name in this.submitted||t.name in this.invalid)&&this.element(t)}
,onclick:function(n){
n.name in this.submitted?this.element(n):n.parentNode.name in this.submitted&&this.element(n.parentNode)}
,highlight:function(t,i,r){
"radio"===t.type?this.findByName(t.name).addClass(i).removeClass(r):n(t).addClass(i).removeClass(r)}
,unhighlight:function(t,i,r){
"radio"===t.type?this.findByName(t.name).removeClass(i).addClass(r):n(t).removeClass(i).addClass(r)}
}
,setDefaults:function(t){
n.extend(n.validator.defaults,t)}
,messages:{
required:"This field is required.",remote:"Please fix this field.",email:"Please enter a valid email address.",url:"Please enter a valid URL.",date:"Please enter a valid date.",dateISO:"Please enter a valid date (ISO).",number:"Please enter a valid number.",digits:"Please enter only digits.",equalTo:"Please enter the same value again.",maxlength:n.validator.format("Please enter no more than {
0}
 characters."),minlength:n.validator.format("Please enter at least {
0}
 characters."),rangelength:n.validator.format("Please enter a value between {
0}
 and {
1}
 characters long."),range:n.validator.format("Please enter a value between {
0}
 and {
1}
."),max:n.validator.format("Please enter a value less than or equal to {
0}
."),min:n.validator.format("Please enter a value greater than or equal to {
0}
."),step:n.validator.format("Please enter a multiple of {
0}
.")}
,autoCreateRanges:!1,prototype:{
init:function(){
function i(t){
!this.form&&this.hasAttribute("contenteditable")&&(this.form=n(this).closest("form")[0]);
var r=n.data(this.form,"validator"),u="on"+t.type.replace(/^validate/,""),i=r.settings;
i[u]&&!n(this).is(i.ignore)&&i[u].call(r,this,t)}
this.labelContainer=n(this.settings.errorLabelContainer);
this.errorContext=this.labelContainer.length&&this.labelContainer||n(this.currentForm);
this.containers=n(this.settings.errorContainer).add(this.settings.errorLabelContainer);
this.submitted={
}
;
this.valueCache={
}
;
this.pendingRequest=0;
this.pending={
}
;
this.invalid={
}
;
this.reset();
var t,r=this.groups={
}
;
n.each(this.settings.groups,
function(t,i){
"string"==typeof i&&(i=i.split(/\s/));
n.each(i,
function(n,i){
r[i]=t}
)}
);
t=this.settings.rules;
n.each(t,
function(i,r){
t[i]=n.validator.normalizeRule(r)}
);
n(this.currentForm).on("focusin.validate focusout.validate keyup.validate",":text, [type='password'], [type='file'], select, textarea, [type='number'], [type='search'], [type='tel'], [type='url'], [type='email'], [type='datetime'], [type='date'], [type='month'], [type='week'], [type='time'], [type='datetime-local'], [type='range'], [type='color'], [type='radio'], [type='checkbox'], [contenteditable]",i).on("click.validate","select, option, [type='radio'], [type='checkbox']",i);
this.settings.invalidHandler&&n(this.currentForm).on("invalid-form.validate",this.settings.invalidHandler);
n(this.currentForm).find("[required], [data-rule-required], .required").attr("aria-required","true")}
,form:function(){
return this.checkForm(),n.extend(this.submitted,this.errorMap),this.invalid=n.extend({
}
,this.errorMap),this.valid()||n(this.currentForm).triggerHandler("invalid-form",[this]),this.showErrors(),this.valid()}
,checkForm:function(){
this.prepareForm();
for(var n=0,t=this.currentElements=this.elements();
t[n];
n++)this.check(t[n]);
return this.valid()}
,element:function(t){
var e,o,i=this.clean(t),r=this.validationTargetFor(i),u=this,f=!0;
return void 0===r?delete this.invalid[i.name]:(this.prepareElement(r),this.currentElements=n(r),o=this.groups[r.name],o&&n.each(this.groups,
function(n,t){
t===o&&n!==r.name&&(i=u.validationTargetFor(u.clean(u.findByName(n))),i&&i.name in u.invalid&&(u.currentElements.push(i),f=u.check(i)&&f))}
),e=this.check(r)!==!1,f=f&&e,this.invalid[r.name]=e?!1:!0,this.numberOfInvalids()||(this.toHide=this.toHide.add(this.containers)),this.showErrors(),n(t).attr("aria-invalid",!e)),f}
,showErrors:function(t){
if(t){
var i=this;
n.extend(this.errorMap,t);
this.errorList=n.map(this.errorMap,
function(n,t){
return{
message:n,element:i.findByName(t)[0]}
}
);
this.successList=n.grep(this.successList,
function(n){
return!(n.name in t)}
)}
this.settings.showErrors?this.settings.showErrors.call(this,this.errorMap,this.errorList):this.defaultShowErrors()}
,resetForm:function(){
n.fn.resetForm&&n(this.currentForm).resetForm();
this.invalid={
}
;
this.submitted={
}
;
this.prepareForm();
this.hideErrors();
var t=this.elements().removeData("previousValue").removeAttr("aria-invalid");
this.resetElements(t)}
,resetElements:function(n){
var t;
if(this.settings.unhighlight)for(t=0;
n[t];
t++)this.settings.unhighlight.call(this,n[t],this.settings.errorClass,""),this.findByName(n[t].name).removeClass(this.settings.validClass);
else n.removeClass(this.settings.errorClass).removeClass(this.settings.validClass)}
,numberOfInvalids:function(){
return this.objectLength(this.invalid)}
,objectLength:function(n){
var t,i=0;
for(t in n)n[t]&&i++;
return i}
,hideErrors:function(){
this.hideThese(this.toHide)}
,hideThese:function(n){
n.not(this.containers).text("");
this.addWrapper(n).hide()}
,valid:function(){
return 0===this.size()}
,size:function(){
return this.errorList.length}
,focusInvalid:function(){
if(this.settings.focusInvalid)try{
n(this.findLastActive()||this.errorList.length&&this.errorList[0].element||[]).filter(":visible").focus().trigger("focusin")}
catch(n){
}
}
,findLastActive:function(){
var t=this.lastActive;
return t&&1===n.grep(this.errorList,
function(n){
return n.element.name===t.name}
).length&&t}
,elements:function(){
var t=this,i={
}
;
return n(this.currentForm).find("input, select, textarea, [contenteditable]").not(":submit, :reset, :image, :disabled").not(this.settings.ignore).filter(function(){
var r=this.name||n(this).attr("name");
return!r&&t.settings.debug&&window.console&&console.error("%o has no name assigned",this),this.hasAttribute("contenteditable")&&(this.form=n(this).closest("form")[0]),!(r in i||!t.objectLength(n(this).rules()))&&(i[r]=!0,!0)}
)}
,clean:function(t){
return n(t)[0]}
,errors:function(){
var t=this.settings.errorClass.split(" ").join(".");
return n(this.settings.errorElement+"."+t,this.errorContext)}
,resetInternals:function(){
this.successList=[];
this.errorList=[];
this.errorMap={
}
;
this.toShow=n([]);
this.toHide=n([])}
,reset:function(){
this.resetInternals();
this.currentElements=n([])}
,prepareForm:function(){
this.reset();
this.toHide=this.errors().add(this.containers)}
,prepareElement:function(n){
this.reset();
this.toHide=this.errorsFor(n)}
,elementValue:function(t){
var i,r,f=n(t),u=t.type;
return"radio"===u||"checkbox"===u?this.findByName(t.name).filter(":checked").val():"number"===u&&"undefined"!=typeof t.validity?t.validity.badInput?"NaN":f.val():(i=t.hasAttribute("contenteditable")?f.text():f.val(),"file"===u?"C:\\fakepath\\"===i.substr(0,12)?i.substr(12):(r=i.lastIndexOf("/"),r>=0?i.substr(r+1):(r=i.lastIndexOf("\\"),r>=0?i.substr(r+1):i)):"string"==typeof i?i.replace(/\r/g,""):i)}
,check:function(t){
t=this.validationTargetFor(this.clean(t));
var u,f,r,i=n(t).rules(),s=n.map(i,
function(n,t){
return t}
).length,o=!1,e=this.elementValue(t);
if("function"==typeof i.normalizer){
if(e=i.normalizer.call(t,e),"string"!=typeof e)throw new TypeError("The normalizer should return a string value.");
delete i.normalizer}
for(f in i){
r={
method:f,parameters:i[f]}
;
try{
if(u=n.validator.methods[f].call(this,e,t,r.parameters),"dependency-mismatch"===u&&1===s){
o=!0;
continue}
if(o=!1,"pending"===u)return void(this.toHide=this.toHide.not(this.errorsFor(t)));
if(!u)return this.formatAndAdd(t,r),!1}
catch(n){
throw this.settings.debug&&window.console&&console.log("Exception occurred when checking element "+t.id+", check the '"+r.method+"' method.",n),n instanceof TypeError&&(n.message+=".  Exception occurred when checking element "+t.id+", check the '"+r.method+"' method."),n;
}
}
if(!o)return this.objectLength(i)&&this.successList.push(t),!0}
,customDataMessage:function(t,i){
return n(t).data("msg"+i.charAt(0).toUpperCase()+i.substring(1).toLowerCase())||n(t).data("msg")}
,customMessage:function(n,t){
var i=this.settings.messages[n];
return i&&(i.constructor===String?i:i[t])}
,findDefined:function(){
for(var n=0;
n<arguments.length;
n++)if(void 0!==arguments[n])return arguments[n]}
,defaultMessage:function(t,i){
"string"==typeof i&&(i={
method:i}
);
var r=this.findDefined(this.customMessage(t.name,i.method),this.customDataMessage(t,i.method),!this.settings.ignoreTitle&&t.title||void 0,n.validator.messages[i.method],"<strong>Warning: No message defined for "+t.name+"<\/strong>"),u=/\$?\{
(\d+)\}
/g;
return"function"==typeof r?r=r.call(this,i.parameters,t):u.test(r)&&(r=n.validator.format(r.replace(u,"{
$1}
"),i.parameters)),r}
,formatAndAdd:function(n,t){
var i=this.defaultMessage(n,t);
this.errorList.push({
message:i,element:n,method:t.method}
);
this.errorMap[n.name]=i;
this.submitted[n.name]=i}
,addWrapper:function(n){
return this.settings.wrapper&&(n=n.add(n.parent(this.settings.wrapper))),n}
,defaultShowErrors:function(){
for(var i,t,n=0;
this.errorList[n];
n++)t=this.errorList[n],this.settings.highlight&&this.settings.highlight.call(this,t.element,this.settings.errorClass,this.settings.validClass),this.showLabel(t.element,t.message);
if(this.errorList.length&&(this.toShow=this.toShow.add(this.containers)),this.settings.success)for(n=0;
this.successList[n];
n++)this.showLabel(this.successList[n]);
if(this.settings.unhighlight)for(n=0,i=this.validElements();
i[n];
n++)this.settings.unhighlight.call(this,i[n],this.settings.errorClass,this.settings.validClass);
this.toHide=this.toHide.not(this.toShow);
this.hideErrors();
this.addWrapper(this.toShow).show()}
,validElements:function(){
return this.currentElements.not(this.invalidElements())}
,invalidElements:function(){
return n(this.errorList).map(function(){
return this.element}
)}
,showLabel:function(t,i){
var u,s,e,o,r=this.errorsFor(t),h=this.idOrName(t),f=n(t).attr("aria-describedby");
r.length?(r.removeClass(this.settings.validClass).addClass(this.settings.errorClass),r.html(i)):(r=n("<"+this.settings.errorElement+">").attr("id",h+"-error").addClass(this.settings.errorClass).html(i||""),u=r,this.settings.wrapper&&(u=r.hide().show().wrap("<"+this.settings.wrapper+"/>").parent()),this.labelContainer.length?this.labelContainer.append(u):this.settings.errorPlacement?this.settings.errorPlacement.call(this,u,n(t)):u.insertAfter(t),r.is("label")?r.attr("for",h):0===r.parents("label[for='"+this.escapeCssMeta(h)+"']").length&&(e=r.attr("id"),f?f.match(new RegExp("\\b"+this.escapeCssMeta(e)+"\\b"))||(f+=" "+e):f=e,n(t).attr("aria-describedby",f),s=this.groups[t.name],s&&(o=this,n.each(o.groups,
function(t,i){
i===s&&n("[name='"+o.escapeCssMeta(t)+"']",o.currentForm).attr("aria-describedby",r.attr("id"))}
))));
!i&&this.settings.success&&(r.text(""),"string"==typeof this.settings.success?r.addClass(this.settings.success):this.settings.success(r,t));
this.toShow=this.toShow.add(r)}
,errorsFor:function(t){
var r=this.escapeCssMeta(this.idOrName(t)),u=n(t).attr("aria-describedby"),i="label[for='"+r+"'], label[for='"+r+"'] *";
return u&&(i=i+", #"+this.escapeCssMeta(u).replace(/\s+/g,", #")),this.errors().filter(i)}
,escapeCssMeta:function(n){
return n.replace(/([\\!"#$%&'()*+,./:;
<=>?@\[\]^`{
|}
~])/g,"\\$1")}
,idOrName:function(n){
return this.groups[n.name]||(this.checkable(n)?n.name:n.id||n.name)}
,validationTargetFor:function(t){
return this.checkable(t)&&(t=this.findByName(t.name)),n(t).not(this.settings.ignore)[0]}
,checkable:function(n){
return/radio|checkbox/i.test(n.type)}
,findByName:function(t){
return n(this.currentForm).find("[name='"+this.escapeCssMeta(t)+"']")}
,getLength:function(t,i){
switch(i.nodeName.toLowerCase()){
case"select":return n("option:selected",i).length;
case"input":if(this.checkable(i))return this.findByName(i.name).filter(":checked").length}
return t.length}
,depend:function(n,t){
return!this.dependTypes[typeof n]||this.dependTypes[typeof n](n,t)}
,dependTypes:{
boolean:function(n){
return n}
,string:function(t,i){
return!!n(t,i.form).length}
,"function":function(n,t){
return n(t)}
}
,optional:function(t){
var i=this.elementValue(t);
return!n.validator.methods.required.call(this,i,t)&&"dependency-mismatch"}
,startRequest:function(t){
this.pending[t.name]||(this.pendingRequest++,n(t).addClass(this.settings.pendingClass),this.pending[t.name]=!0)}
,stopRequest:function(t,i){
this.pendingRequest--;
this.pendingRequest<0&&(this.pendingRequest=0);
delete this.pending[t.name];
n(t).removeClass(this.settings.pendingClass);
i&&0===this.pendingRequest&&this.formSubmitted&&this.form()?(n(this.currentForm).submit(),this.formSubmitted=!1):!i&&0===this.pendingRequest&&this.formSubmitted&&(n(this.currentForm).triggerHandler("invalid-form",[this]),this.formSubmitted=!1)}
,previousValue:function(t,i){
return i="string"==typeof i&&i||"remote",n.data(t,"previousValue")||n.data(t,"previousValue",{
old:null,valid:!0,message:this.defaultMessage(t,{
method:i}
)}
)}
,destroy:function(){
this.resetForm();
n(this.currentForm).off(".validate").removeData("validator").find(".validate-equalTo-blur").off(".validate-equalTo").removeClass("validate-equalTo-blur")}
}
,classRuleSettings:{
required:{
required:!0}
,email:{
email:!0}
,url:{
url:!0}
,date:{
date:!0}
,dateISO:{
dateISO:!0}
,number:{
number:!0}
,digits:{
digits:!0}
,creditcard:{
creditcard:!0}
}
,addClassRules:function(t,i){
t.constructor===String?this.classRuleSettings[t]=i:n.extend(this.classRuleSettings,t)}
,classRules:function(t){
var i={
}
,r=n(t).attr("class");
return r&&n.each(r.split(" "),
function(){
this in n.validator.classRuleSettings&&n.extend(i,n.validator.classRuleSettings[this])}
),i}
,normalizeAttributeRule:function(n,t,i,r){
/min|max|step/.test(i)&&(null===t||/number|range|text/.test(t))&&(r=Number(r),isNaN(r)&&(r=void 0));
r||0===r?n[i]=r:t===i&&"range"!==t&&(n[i]=!0)}
,attributeRules:function(t){
var r,i,u={
}
,f=n(t),e=t.getAttribute("type");
for(r in n.validator.methods)"required"===r?(i=t.getAttribute(r),""===i&&(i=!0),i=!!i):i=f.attr(r),this.normalizeAttributeRule(u,e,r,i);
return u.maxlength&&/-1|2147483647|524288/.test(u.maxlength)&&delete u.maxlength,u}
,dataRules:function(t){
var i,r,u={
}
,f=n(t),e=t.getAttribute("type");
for(i in n.validator.methods)r=f.data("rule"+i.charAt(0).toUpperCase()+i.substring(1).toLowerCase()),this.normalizeAttributeRule(u,e,i,r);
return u}
,staticRules:function(t){
var i={
}
,r=n.data(t.form,"validator");
return r.settings.rules&&(i=n.validator.normalizeRule(r.settings.rules[t.name])||{
}
),i}
,normalizeRules:function(t,i){
return n.each(t,
function(r,u){
if(u===!1)return void delete t[r];
if(u.param||u.depends){
var f=!0;
switch(typeof u.depends){
case"string":f=!!n(u.depends,i.form).length;
break;
case"function":f=u.depends.call(i,i)}
f?t[r]=void 0===u.param||u.param:(n.data(i.form,"validator").resetElements(n(i)),delete t[r])}
}
),n.each(t,
function(r,u){
t[r]=n.isFunction(u)&&"normalizer"!==r?u(i):u}
),n.each(["minlength","maxlength"],
function(){
t[this]&&(t[this]=Number(t[this]))}
),n.each(["rangelength","range"],
function(){
var i;
t[this]&&(n.isArray(t[this])?t[this]=[Number(t[this][0]),Number(t[this][1])]:"string"==typeof t[this]&&(i=t[this].replace(/[\[\]]/g,"").split(/[\s,]+/),t[this]=[Number(i[0]),Number(i[1])]))}
),n.validator.autoCreateRanges&&(null!=t.min&&null!=t.max&&(t.range=[t.min,t.max],delete t.min,delete t.max),null!=t.minlength&&null!=t.maxlength&&(t.rangelength=[t.minlength,t.maxlength],delete t.minlength,delete t.maxlength)),t}
,normalizeRule:function(t){
if("string"==typeof t){
var i={
}
;
n.each(t.split(/\s/),
function(){
i[this]=!0}
);
t=i}
return t}
,addMethod:function(t,i,r){
n.validator.methods[t]=i;
n.validator.messages[t]=void 0!==r?r:n.validator.messages[t];
i.length<3&&n.validator.addClassRules(t,n.validator.normalizeRule(t))}
,methods:{
required:function(t,i,r){
if(!this.depend(r,i))return"dependency-mismatch";
if("select"===i.nodeName.toLowerCase()){
var u=n(i).val();
return u&&u.length>0}
return this.checkable(i)?this.getLength(t,i)>0:t.length>0}
,email:function(n,t){
return this.optional(t)||/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{
|}
~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{
0,61}
[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{
0,61}
[a-zA-Z0-9])?)*$/.test(n)}
,url:function(n,t){
return this.optional(t)||/^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{
1,3}
){
3}
)(?!(?:169\.254|192\.168)(?:\.\d{
1,3}
){
2}
)(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{
1,3}
){
2}
)(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{
1,2}
|2[0-4]\d|25[0-5])){
2}
(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{
2,}
)).?)(?::\d{
2,5}
)?(?:[/?#]\S*)?$/i.test(n)}
,date:function(n,t){
return this.optional(t)||!/Invalid|NaN/.test(new Date(n).toString())}
,dateISO:function(n,t){
return this.optional(t)||/^\d{
4}
[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/.test(n)}
,number:function(n,t){
return this.optional(t)||/^(?:-?\d+|-?\d{
1,3}
(?:,\d{
3}
)+)?(?:\.\d+)?$/.test(n)}
,digits:function(n,t){
return this.optional(t)||/^\d+$/.test(n)}
,minlength:function(t,i,r){
var u=n.isArray(t)?t.length:this.getLength(t,i);
return this.optional(i)||u>=r}
,maxlength:function(t,i,r){
var u=n.isArray(t)?t.length:this.getLength(t,i);
return this.optional(i)||u<=r}
,rangelength:function(t,i,r){
var u=n.isArray(t)?t.length:this.getLength(t,i);
return this.optional(i)||u>=r[0]&&u<=r[1]}
,min:function(n,t,i){
return this.optional(t)||n>=i}
,max:function(n,t,i){
return this.optional(t)||n<=i}
,range:function(n,t,i){
return this.optional(t)||n>=i[0]&&n<=i[1]}
,step:function(t,i,r){
var u,f=n(i).attr("type"),h="Step attribute on input type "+f+" is not supported.",c=new RegExp("\\b"+f+"\\b"),l=f&&!c.test("text,number,range"),e=function(n){
var t=(""+n).match(/(?:\.(\d+))?$/);
return t&&t[1]?t[1].length:0}
,o=function(n){
return Math.round(n*Math.pow(10,u))}
,s=!0;
if(l)throw new Error(h);
return u=e(r),(e(t)>u||o(t)%o(r)!=0)&&(s=!1),this.optional(i)||s}
,equalTo:function(t,i,r){
var u=n(r);
return this.settings.onfocusout&&u.not(".validate-equalTo-blur").length&&u.addClass("validate-equalTo-blur").on("blur.validate-equalTo",
function(){
n(i).valid()}
),t===u.val()}
,remote:function(t,i,r,u){
if(this.optional(i))return"dependency-mismatch";
u="string"==typeof u&&u||"remote";
var f,o,s,e=this.previousValue(i,u);
return this.settings.messages[i.name]||(this.settings.messages[i.name]={
}
),e.originalMessage=e.originalMessage||this.settings.messages[i.name][u],this.settings.messages[i.name][u]=e.message,r="string"==typeof r&&{
url:r}
||r,s=n.param(n.extend({
data:t}
,r.data)),e.old===s?e.valid:(e.old=s,f=this,this.startRequest(i),o={
}
,o[i.name]=t,n.ajax(n.extend(!0,{
mode:"abort",port:"validate"+i.name,dataType:"json",data:o,context:f.currentForm,success:function(n){
var r,s,h,o=n===!0||"true"===n;
f.settings.messages[i.name][u]=e.originalMessage;
o?(h=f.formSubmitted,f.resetInternals(),f.toHide=f.errorsFor(i),f.formSubmitted=h,f.successList.push(i),f.invalid[i.name]=!1,f.showErrors()):(r={
}
,s=n||f.defaultMessage(i,{
method:u,parameters:t}
),r[i.name]=e.message=s,f.invalid[i.name]=!0,f.showErrors(r));
e.valid=o;
f.stopRequest(i,o)}
}
,r)),"pending")}
}
}
);
var i,t={
}
;
n.ajaxPrefilter?n.ajaxPrefilter(function(n,i,r){
var u=n.port;
"abort"===n.mode&&(t[u]&&t[u].abort(),t[u]=r)}
):(i=n.ajax,n.ajax=function(r){
var f=("mode"in r?r:n.ajaxSettings).mode,u=("port"in r?r:n.ajaxSettings).port;
return"abort"===f?(t[u]&&t[u].abort(),t[u]=i.apply(this,arguments),t[u]):i.apply(this,arguments)}
)}
),
function(n){
function i(n,t,i){
n.rules[t]=i;
n.message&&(n.messages[t]=n.message)}
function h(n){
return n.replace(/^\s+|\s+$/g,"").split(/\s*,\s*/g)}
function f(n){
return n.replace(/([!"#$%&'()*+,./:;
<=>?@\[\\\]^`{
|}
~])/g,"\\$1")}
function e(n){
return n.substr(0,n.lastIndexOf(".")+1)}
function o(n,t){
return n.indexOf("*.")===0&&(n=n.replace("*.",t)),n}
function c(t,i){
var r=n(this).find("[data-valmsg-for='"+f(i[0].name)+"']"),u=r.attr("data-valmsg-replace"),e=u?n.parseJSON(u)!==!1:null;
r.removeClass("field-validation-valid").addClass("field-validation-error");
t.data("unobtrusiveContainer",r);
e?(r.empty(),t.removeClass("input-validation-error").appendTo(r)):t.hide()}
function l(t,i){
var u=n(this).find("[data-valmsg-summary=true]"),r=u.find("ul");
r&&r.length&&i.errorList.length&&(r.empty(),u.addClass("validation-summary-errors").removeClass("validation-summary-valid"),n.each(i.errorList,
function(){
n("<li />").html(this.message).appendTo(r)}
))}
function a(t){
var i=t.data("unobtrusiveContainer"),r=i.attr("data-valmsg-replace"),u=r?n.parseJSON(r):null;
i&&(i.addClass("field-validation-valid").removeClass("field-validation-error"),t.removeData("unobtrusiveContainer"),u&&i.empty())}
function v(){
var t=n(this),i="__jquery_unobtrusive_validation_form_reset";
if(!t.data(i)){
t.data(i,!0);
try{
t.data("validator").resetForm()}
finally{
t.removeData(i)}
t.find(".validation-summary-errors").addClass("validation-summary-valid").removeClass("validation-summary-errors");
t.find(".field-validation-error").addClass("field-validation-valid").removeClass("field-validation-error").removeData("unobtrusiveContainer").find(">*").removeData("unobtrusiveContainer")}
}
function s(t){
var i=n(t),f=i.data(u),s=n.proxy(v,t),e=r.unobtrusive.options||{
}
,o=function(i,r){
var u=e[i];
u&&n.isFunction(u)&&u.apply(t,r)}
;
return f||(f={
options:{
errorClass:e.errorClass||"input-validation-error",errorElement:e.errorElement||"span",errorPlacement:function(){
c.apply(t,arguments);
o("errorPlacement",arguments)}
,invalidHandler:function(){
l.apply(t,arguments);
o("invalidHandler",arguments)}
,messages:{
}
,rules:{
}
,success:function(){
a.apply(t,arguments);
o("success",arguments)}
}
,attachValidation:function(){
i.off("reset."+u,s).on("reset."+u,s).validate(this.options)}
,validate:function(){
return i.validate(),i.valid()}
}
,i.data(u,f)),f}
var r=n.validator,t,u="unobtrusiveValidation";
r.unobtrusive={
adapters:[],parseElement:function(t,i){
var u=n(t),f=u.parents("form")[0],r,e,o;
f&&(r=s(f),r.options.rules[t.name]=e={
}
,r.options.messages[t.name]=o={
}
,n.each(this.adapters,
function(){
var i="data-val-"+this.name,r=u.attr(i),s={
}
;
r!==undefined&&(i+="-",n.each(this.params,
function(){
s[this]=u.attr(i+this)}
),this.adapt({
element:t,form:f,message:r,params:s,rules:e,messages:o}
))}
),n.extend(e,{
__dummy__:!0}
),i||r.attachValidation())}
,parse:function(t){
var i=n(t),u=i.parents().addBack().filter("form").add(i.find("form")).has("[data-val=true]");
i.find("[data-val=true]").each(function(){
r.unobtrusive.parseElement(this,!0)}
);
u.each(function(){
var n=s(this);
n&&n.attachValidation()}
)}
}
;
t=r.unobtrusive.adapters;
t.add=function(n,t,i){
return i||(i=t,t=[]),this.push({
name:n,params:t,adapt:i}
),this}
;
t.addBool=function(n,t){
return this.add(n,
function(r){
i(r,t||n,!0)}
)}
;
t.addMinMax=function(n,t,r,u,f,e){
return this.add(n,[f||"min",e||"max"],
function(n){
var f=n.params.min,e=n.params.max;
f&&e?i(n,u,[f,e]):f?i(n,t,f):e&&i(n,r,e)}
)}
;
t.addSingleVal=function(n,t,r){
return this.add(n,[t||"val"],
function(u){
i(u,r||n,u.params[t])}
)}
;
r.addMethod("__dummy__",
function(){
return!0}
);
r.addMethod("regex",
function(n,t,i){
var r;
return this.optional(t)?!0:(r=new RegExp(i).exec(n),r&&r.index===0&&r[0].length===n.length)}
);
r.addMethod("nonalphamin",
function(n,t,i){
var r;
return i&&(r=n.match(/\W/g),r=r&&r.length>=i),r}
);
r.methods.extension?(t.addSingleVal("accept","mimtype"),t.addSingleVal("extension","extension")):t.addSingleVal("extension","extension","accept");
t.addSingleVal("regex","pattern");
t.addBool("creditcard").addBool("date").addBool("digits").addBool("email").addBool("number").addBool("url");
t.addMinMax("length","minlength","maxlength","rangelength").addMinMax("range","min","max","range");
t.addMinMax("minlength","minlength").addMinMax("maxlength","minlength","maxlength");
t.add("equalto",["other"],
function(t){
var r=e(t.element.name),u=t.params.other,s=o(u,r),h=n(t.form).find(":input").filter("[name='"+f(s)+"']")[0];
i(t,"equalTo",h)}
);
t.add("required",
function(n){
(n.element.tagName.toUpperCase()!=="INPUT"||n.element.type.toUpperCase()!=="CHECKBOX")&&i(n,"required",!0)}
);
t.add("remote",["url","type","additionalfields"],
function(t){
var r={
url:t.params.url,type:t.params.type||"GET",data:{
}
}
,u=e(t.element.name);
n.each(h(t.params.additionalfields||t.element.name),
function(i,e){
var s=o(e,u);
r.data[s]=function(){
var i=n(t.form).find(":input").filter("[name='"+f(s)+"']");
return i.is(":checkbox")?i.filter(":checked").val()||i.filter(":hidden").val()||"":i.is(":radio")?i.filter(":checked").val()||"":i.val()}
}
);
i(t,"remote",r)}
);
t.add("password",["min","nonalphamin","regex"],
function(n){
n.params.min&&i(n,"minlength",n.params.min);
n.params.nonalphamin&&i(n,"nonalphamin",n.params.nonalphamin);
n.params.regex&&i(n,"regex",n.params.regex)}
);
n(function(){
r.unobtrusive.parse(document)}
)}
(jQuery),window.Modernizr=function(n,t,i){
function a(n){
c.cssText=n}
function vt(n,t){
return a(y.join(n+";
")+(t||""))}
function h(n,t){
return typeof n===t}
function v(n,t){
return!!~(""+n).indexOf(t)}
function lt(n,t){
var u,r;
for(u in n)if(r=n[u],!v(r,"-")&&c[r]!==i)return t=="pfx"?r:!0;
return!1}
function yt(n,t,r){
var f,u;
for(f in n)if(u=t[n[f]],u!==i)return r===!1?n[f]:h(u,"function")?u.bind(r||t):u;
return!1}
function f(n,t,i){
var r=n.charAt(0).toUpperCase()+n.slice(1),u=(n+" "+ot.join(r+" ")+r).split(" ");
return h(t,"string")||h(t,"undefined")?lt(u,t):(u=(n+" "+st.join(r+" ")+r).split(" "),yt(u,t,i))}
function pt(){
u.input=function(i){
for(var r=0,u=i.length;
r<u;
r++)w[i[r]]=!!(i[r]in o);
return w.list&&(w.list=!!(t.createElement("datalist")&&n.HTMLDataListElement)),w}
("autocomplete autofocus list placeholder max min multiple pattern required step".split(" "));
u.inputtypes=function(n){
for(var u=0,r,f,e,h=n.length;
u<h;
u++)o.setAttribute("type",f=n[u]),r=o.type!=="text",r&&(o.value=g,o.style.cssText="position:absolute;
visibility:hidden;
",/^range$/.test(f)&&o.style.WebkitAppearance!==i?(s.appendChild(o),e=t.defaultView,r=e.getComputedStyle&&e.getComputedStyle(o,null).WebkitAppearance!=="textfield"&&o.offsetHeight!==0,s.removeChild(o)):/^(search|tel)$/.test(f)||(r=/^(url|email)$/.test(f)?o.checkValidity&&o.checkValidity()===!1:o.value!=g)),ht[n[u]]=!!r;
return ht}
("search tel url email datetime date month week time datetime-local number range color".split(" "))}
var u={
}
,d=!0,s=t.documentElement,e="modernizr",ut=t.createElement(e),c=ut.style,o=t.createElement("input"),g=":)",ft={
}
.toString,y=" -webkit- -moz- -o- -ms- ".split(" "),et="Webkit Moz O ms",ot=et.split(" "),st=et.toLowerCase().split(" "),p={
svg:"http://www.w3.org/2000/svg"}
,r={
}
,ht={
}
,w={
}
,nt=[],tt=nt.slice,b,l=function(n,i,r,u){
var l,a,c,v,f=t.createElement("div"),h=t.body,o=h||t.createElement("body");
if(parseInt(r,10))while(r--)c=t.createElement("div"),c.id=u?u[r]:e+(r+1),f.appendChild(c);
return l=["&#173;
",'<style id="s',e,'">',n,"<\/style>"].join(""),f.id=e,(h?f:o).innerHTML+=l,o.appendChild(f),h||(o.style.background="",o.style.overflow="hidden",v=s.style.overflow,s.style.overflow="hidden",s.appendChild(o)),a=i(f,n),h?f.parentNode.removeChild(f):(o.parentNode.removeChild(o),s.style.overflow=v),!!a}
,at=function(t){
var i=n.matchMedia||n.msMatchMedia,r;
return i?i(t)&&i(t).matches||!1:(l("@media "+t+" {
 #"+e+" {
 position: absolute;
 }
 }
",
function(t){
r=(n.getComputedStyle?getComputedStyle(t,null):t.currentStyle).position=="absolute"}
),r)}
,ct=function(){
function r(r,u){
u=u||t.createElement(n[r]||"div");
r="on"+r;
var f=r in u;
return f||(u.setAttribute||(u=t.createElement("div")),u.setAttribute&&u.removeAttribute&&(u.setAttribute(r,""),f=h(u[r],"function"),h(u[r],"undefined")||(u[r]=i),u.removeAttribute(r))),u=null,f}
var n={
select:"input",change:"input",submit:"form",reset:"form",error:"img",load:"img",abort:"img"}
;
return r}
(),it={
}
.hasOwnProperty,rt,k;
rt=h(it,"undefined")||h(it.call,"undefined")?function(n,t){
return t in n&&h(n.constructor.prototype[t],"undefined")}
:function(n,t){
return it.call(n,t)}
;
Function.prototype.bind||(Function.prototype.bind=function(n){
var t=this,i,r;
if(typeof t!="function")throw new TypeError;
return i=tt.call(arguments,1),r=function(){
var f,e,u;
return this instanceof r?(f=function(){
}
,f.prototype=t.prototype,e=new f,u=t.apply(e,i.concat(tt.call(arguments))),Object(u)===u)?u:e:t.apply(n,i.concat(tt.call(arguments)))}
,r}
);
r.flexbox=function(){
return f("flexWrap")}
;
r.flexboxlegacy=function(){
return f("boxDirection")}
;
r.canvas=function(){
var n=t.createElement("canvas");
return!!(n.getContext&&n.getContext("2d"))}
;
r.canvastext=function(){
return!!(u.canvas&&h(t.createElement("canvas").getContext("2d").fillText,"function"))}
;
r.webgl=function(){
return!!n.WebGLRenderingContext}
;
r.touch=function(){
var i;
return"ontouchstart"in n||n.DocumentTouch&&t instanceof DocumentTouch?i=!0:l(["@media (",y.join("touch-enabled),("),e,")","{
#modernizr{
top:9px;
position:absolute}
}
"].join(""),
function(n){
i=n.offsetTop===9}
),i}
;
r.geolocation=function(){
return"geolocation"in navigator}
;
r.postmessage=function(){
return!!n.postMessage}
;
r.websqldatabase=function(){
return!!n.openDatabase}
;
r.indexedDB=function(){
return!!f("indexedDB",n)}
;
r.hashchange=function(){
return ct("hashchange",n)&&(t.documentMode===i||t.documentMode>7)}
;
r.history=function(){
return!!(n.history&&history.pushState)}
;
r.draganddrop=function(){
var n=t.createElement("div");
return"draggable"in n||"ondragstart"in n&&"ondrop"in n}
;
r.websockets=function(){
return"WebSocket"in n||"MozWebSocket"in n}
;
r.rgba=function(){
return a("background-color:rgba(150,255,150,.5)"),v(c.backgroundColor,"rgba")}
;
r.hsla=function(){
return a("background-color:hsla(120,40%,100%,.5)"),v(c.backgroundColor,"rgba")||v(c.backgroundColor,"hsla")}
;
r.multiplebgs=function(){
return a("background:url(https://),url(https://),red url(https://)"),/(url\s*\(.*?){
3}
/.test(c.background)}
;
r.backgroundsize=function(){
return f("backgroundSize")}
;
r.borderimage=function(){
return f("borderImage")}
;
r.borderradius=function(){
return f("borderRadius")}
;
r.boxshadow=function(){
return f("boxShadow")}
;
r.textshadow=function(){
return t.createElement("div").style.textShadow===""}
;
r.opacity=function(){
return vt("opacity:.55"),/^0.55$/.test(c.opacity)}
;
r.cssanimations=function(){
return f("animationName")}
;
r.csscolumns=function(){
return f("columnCount")}
;
r.cssgradients=function(){
var n="background-image:";
return a((n+"-webkit- ".split(" ").join("gradient(linear,left top,right bottom,from(#9f9),to(white));
"+n)+y.join("linear-gradient(left top,#9f9, white);
"+n)).slice(0,-n.length)),v(c.backgroundImage,"gradient")}
;
r.cssreflections=function(){
return f("boxReflect")}
;
r.csstransforms=function(){
return!!f("transform")}
;
r.csstransforms3d=function(){
var n=!!f("perspective");
return n&&"webkitPerspective"in s.style&&l("@media (transform-3d),(-webkit-transform-3d){
#modernizr{
left:9px;
position:absolute;
height:3px;
}
}
",
function(t){
n=t.offsetLeft===9&&t.offsetHeight===3}
),n}
;
r.csstransitions=function(){
return f("transition")}
;
r.fontface=function(){
var n;
return l('@font-face {
font-family:"font";
src:url("https://")}
',
function(i,r){
var f=t.getElementById("smodernizr"),u=f.sheet||f.styleSheet,e=u?u.cssRules&&u.cssRules[0]?u.cssRules[0].cssText:u.cssText||"":"";
n=/src/i.test(e)&&e.indexOf(r.split(" ")[0])===0}
),n}
;
r.generatedcontent=function(){
var n;
return l(["#",e,"{
font:0/0 a}
#",e,':after{
content:"',g,'";
visibility:hidden;
font:3px/1 a}
'].join(""),
function(t){
n=t.offsetHeight>=3}
),n}
;
r.video=function(){
var i=t.createElement("video"),n=!1;
try{
(n=!!i.canPlayType)&&(n=new Boolean(n),n.ogg=i.canPlayType('video/ogg;
 codecs="theora"').replace(/^no$/,""),n.h264=i.canPlayType('video/mp4;
 codecs="avc1.42E01E"').replace(/^no$/,""),n.webm=i.canPlayType('video/webm;
 codecs="vp8, vorbis"').replace(/^no$/,""))}
catch(r){
}
return n}
;
r.audio=function(){
var i=t.createElement("audio"),n=!1;
try{
(n=!!i.canPlayType)&&(n=new Boolean(n),n.ogg=i.canPlayType('audio/ogg;
 codecs="vorbis"').replace(/^no$/,""),n.mp3=i.canPlayType("audio/mpeg;
").replace(/^no$/,""),n.wav=i.canPlayType('audio/wav;
 codecs="1"').replace(/^no$/,""),n.m4a=(i.canPlayType("audio/x-m4a;
")||i.canPlayType("audio/aac;
")).replace(/^no$/,""))}
catch(r){
}
return n}
;
r.localstorage=function(){
try{
return localStorage.setItem(e,e),localStorage.removeItem(e),!0}
catch(n){
return!1}
}
;
r.sessionstorage=function(){
try{
return sessionStorage.setItem(e,e),sessionStorage.removeItem(e),!0}
catch(n){
return!1}
}
;
r.webworkers=function(){
return!!n.Worker}
;
r.applicationcache=function(){
return!!n.applicationCache}
;
r.svg=function(){
return!!t.createElementNS&&!!t.createElementNS(p.svg,"svg").createSVGRect}
;
r.inlinesvg=function(){
var n=t.createElement("div");
return n.innerHTML="<svg/>",(n.firstChild&&n.firstChild.namespaceURI)==p.svg}
;
r.smil=function(){
return!!t.createElementNS&&/SVGAnimate/.test(ft.call(t.createElementNS(p.svg,"animate")))}
;
r.svgclippaths=function(){
return!!t.createElementNS&&/SVGClipPath/.test(ft.call(t.createElementNS(p.svg,"clipPath")))}
;
for(k in r)rt(r,k)&&(b=k.toLowerCase(),u[b]=r[k](),nt.push((u[b]?"":"no-")+b));
return u.input||pt(),u.addTest=function(n,t){
if(typeof n=="object")for(var r in n)rt(n,r)&&u.addTest(r,n[r]);
else{
if(n=n.toLowerCase(),u[n]!==i)return u;
t=typeof t=="function"?t():t;
typeof d!="undefined"&&d&&(s.className+=" "+(t?"":"no-")+n);
u[n]=t}
return u}
,a(""),ut=o=null,
function(n,t){
function p(n,t){
var i=n.createElement("p"),r=n.getElementsByTagName("head")[0]||n.documentElement;
return i.innerHTML="x<style>"+t+"<\/style>",r.insertBefore(i.lastChild,r.firstChild)}
function c(){
var n=r.elements;
return typeof n=="string"?n.split(" "):n}
function o(n){
var t=h[n[s]];
return t||(t={
}
,e++,n[s]=e,h[e]=t),t}
function l(n,r,u){
if(r||(r=t),i)return r.createElement(n);
u||(u=o(r));
var f;
return f=u.cache[n]?u.cache[n].cloneNode():y.test(n)?(u.cache[n]=u.createElem(n)).cloneNode():u.createElem(n),f.canHaveChildren&&!v.test(n)&&!f.tagUrn?u.frag.appendChild(f):f}
function w(n,r){
if(n||(n=t),i)return n.createDocumentFragment();
r=r||o(n);
for(var f=r.frag.cloneNode(),u=0,e=c(),s=e.length;
u<s;
u++)f.createElement(e[u]);
return f}
function b(n,t){
t.cache||(t.cache={
}
,t.createElem=n.createElement,t.createFrag=n.createDocumentFragment,t.frag=t.createFrag());
n.createElement=function(i){
return r.shivMethods?l(i,n,t):t.createElem(i)}
;
n.createDocumentFragment=Function("h,f","return function(){
var n=f.cloneNode(),c=n.createElement;
h.shivMethods&&("+c().join().replace(/[\w\-]+/g,
function(n){
return t.createElem(n),t.frag.createElement(n),'c("'+n+'")'}
)+");
return n}
")(r,t.frag)}
function a(n){
n||(n=t);
var u=o(n);
return!r.shivCSS||f||u.hasCSS||(u.hasCSS=!!p(n,"article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{
display:block}
mark{
background:#FF0;
color:#000}
template{
display:none}
")),i||b(n,u),n}
var u=n.html5||{
}
,v=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,y=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,f,s="_html5shiv",e=0,h={
}
,i,r;
(function(){
try{
var n=t.createElement("a");
n.innerHTML="<xyz><\/xyz>";
f="hidden"in n;
i=n.childNodes.length==1||function(){
t.createElement("a");
var n=t.createDocumentFragment();
return typeof n.cloneNode=="undefined"||typeof n.createDocumentFragment=="undefined"||typeof n.createElement=="undefined"}
()}
catch(r){
f=!0;
i=!0}
}
)();
r={
elements:u.elements||"abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",version:"3.7.0",shivCSS:u.shivCSS!==!1,supportsUnknownElements:i,shivMethods:u.shivMethods!==!1,type:"default",shivDocument:a,createElement:l,createDocumentFragment:w}
;
n.html5=r;
a(t)}
(this,t),u._version="2.8.3",u._prefixes=y,u._domPrefixes=st,u._cssomPrefixes=ot,u.mq=at,u.hasEvent=ct,u.testProp=function(n){
return lt([n])}
,u.testAllProps=f,u.testStyles=l,u.prefixed=function(n,t,i){
return t?f(n,t,i):f(n,"pfx")}
,s.className=s.className.replace(/(^|\s)no-js(\s|$)/,"$1$2")+(d?" js "+nt.join(" "):""),u}
(this,this.document),foolproof=function(){
}
,foolproof.is=function(n,t,i,r){
if(r){
var u=function(n){
return n==null||n==undefined||n==""}
,f=u(n),e=u(i);
if(f&&!e||e&&!f)return!0}
var o=function(n){
return+n==n&&n.length>0}
,s=function(n){
var t=new RegExp(/(?=\d)^(?:(?!(?:10\D(?:0?[5-9]|1[0-4])\D(?:1582))|(?:0?9\D(?:0?[3-9]|1[0-3])\D(?:1752)))((?:0?[13578]|1[02])|(?:0?[469]|11)(?!\/31)(?!-31)(?!\.31)|(?:0?2(?=.?(?:(?:29.(?!000[04]|(?:(?:1[^0-6]|[2468][^048]|[3579][^26])00))(?:(?:(?:\d\d)(?:[02468][048]|[13579][26])(?!\x20BC))|(?:00(?:42|3[0369]|2[147]|1[258]|09)\x20BC))))))|(?:0?2(?=.(?:(?:\d\D)|(?:[01]\d)|(?:2[0-8])))))([-.\/])(0?[1-9]|[12]\d|3[01])\2(?!0000)((?=(?:00(?:4[0-5]|[0-3]?\d)\x20BC)|(?:\d{
4}
(?!\x20BC)))\d{
4}
(?:\x20BC)?)(?:$|(?=\x20\d)\x20))?((?:(?:0?[1-9]|1[012])(?::[0-5]\d){
0,2}
(?:\x20[aApP][mM]))|(?:[01]\d|2[0-3])(?::[0-5]\d){
1,2}
)?$/);
return t.test(n)}
,h=function(n){
return n===!0||n===!1||n==="true"||n==="false"}
;
s(n)?(n=Date.parse(n),i=Date.parse(i)):h(n)?(n=="false"&&(n=!1),i=="false"&&(i=!1),n=!!n,i=!!i):o(n)&&(n=parseFloat(n),i=parseFloat(i));
switch(t){
case"EqualTo":if(n==i)return!0;
break;
case"NotEqualTo":if(n!=i)return!0;
break;
case"GreaterThan":if(n>i)return!0;
break;
case"LessThan":if(n<i)return!0;
break;
case"GreaterThanOrEqualTo":if(n>=i)return!0;
break;
case"LessThanOrEqualTo":if(n<=i)return!0;
break;
case"RegExMatch":return new RegExp(i).test(n);
case"NotRegExMatch":return!new RegExp(i).test(n)}
return!1}
,foolproof.getId=function(n,t){
var i=n.id.lastIndexOf("_")+1;
return n.id.substr(0,i)+t.replace(/\./g,"_")}
,foolproof.getName=function(n,t){
var i=n.name.lastIndexOf(".")+1;
return n.name.substr(0,i)+t}
,
function(){
jQuery.validator.addMethod("is",
function(n,t,i){
var r=foolproof.getId(t,i.dependentproperty),u=i.operator,f=i.passonnull,e=document.getElementById(r).value;
return foolproof.is(n,u,e,f)?!0:!1}
);
jQuery.validator.addMethod("requiredif",
function(n,t,i){
var o=foolproof.getName(t,i.dependentproperty),s=i.dependentvalue,h=i.operator,e=i.pattern,r=document.getElementsByName(o),u=null,f;
if(r.length>1){
for(f=0;
f!=r.length;
f++)if(r[f].checked){
u=r[f].value;
break}
u==null&&(u=!1)}
else u=r[0].value;
if(foolproof.is(u,h,s))if(e==null){
if(n!=null&&n.toString().replace(/^\s\s*/,"").replace(/\s\s*$/,"")!="")return!0}
else return new RegExp(e).test(n);
else return!0;
return!1}
);
jQuery.validator.addMethod("requiredifempty",
function(n,t,i){
var u=foolproof.getId(t,i.dependentproperty),r=document.getElementById(u).value;
if(r==null||r.toString().replace(/^\s\s*/,"").replace(/\s\s*$/,"")==""){
if(n!=null&&n.toString().replace(/^\s\s*/,"").replace(/\s\s*$/,"")!="")return!0}
else return!0;
return!1}
);
jQuery.validator.addMethod("requiredifnotempty",
function(n,t,i){
var u=foolproof.getId(t,i.dependentproperty),r=document.getElementById(u).value;
if(r!=null&&r.toString().replace(/^\s\s*/,"").replace(/\s\s*$/,"")!=""){
if(n!=null&&n.toString().replace(/^\s\s*/,"").replace(/\s\s*$/,"")!="")return!0}
else return!0;
return!1}
);
var n=function(n,t,i){
n.rules[t]=i;
n.message&&(n.messages[t]=n.message)}
,t=$.validator.unobtrusive;
t.adapters.add("requiredif",["dependentproperty","dependentvalue","operator","pattern"],
function(t){
var i={
dependentproperty:t.params.dependentproperty,dependentvalue:t.params.dependentvalue,operator:t.params.operator,pattern:t.params.pattern}
;
n(t,"requiredif",i)}
);
t.adapters.add("is",["dependentproperty","operator","passonnull"],
function(t){
n(t,"is",{
dependentproperty:t.params.dependentproperty,operator:t.params.operator,passonnull:t.params.passonnull}
)}
);
t.adapters.add("requiredifempty",["dependentproperty"],
function(t){
n(t,"requiredifempty",{
dependentproperty:t.params.dependentproperty}
)}
);
t.adapters.add("requiredifnotempty",["dependentproperty"],
function(t){
n(t,"requiredifnotempty",{
dependentproperty:t.params.dependentproperty}
)}
)}
(),"undefined"==typeof jQuery)throw new Error("Bootstrap's JavaScript requires jQuery");
+function(n){
"use strict";
var t=n.fn.jquery.split(" ")[0].split(".");
if(t[0]<2&&t[1]<9||1==t[0]&&9==t[1]&&t[2]<1||t[0]>2)throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 3");
}
(jQuery);
+function(n){
"use strict";
function t(){
var i=document.createElement("bootstrap"),n={
WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd otransitionend",transition:"transitionend"}
;
for(var t in n)if(void 0!==i.style[t])return{
end:n[t]}
;
return!1}
n.fn.emulateTransitionEnd=function(t){
var i=!1,u=this,r;
n(this).one("bsTransitionEnd",
function(){
i=!0}
);
return r=function(){
i||n(u).trigger(n.support.transition.end)}
,setTimeout(r,t),this}
;
n(function(){
n.support.transition=t();
n.support.transition&&(n.event.special.bsTransitionEnd={
bindType:n.support.transition.end,delegateType:n.support.transition.end,handle:function(t){
if(n(t.target).is(this))return t.handleObj.handler.apply(this,arguments)}
}
)}
)}
(jQuery);
+function(n){
"use strict";
function u(i){
return this.each(function(){
var r=n(this),u=r.data("bs.alert");
u||r.data("bs.alert",u=new t(this));
"string"==typeof i&&u[i].call(r)}
)}
var i='[data-dismiss="alert"]',t=function(t){
n(t).on("click",i,this.close)}
,r;
t.VERSION="3.3.6";
t.TRANSITION_DURATION=150;
t.prototype.close=function(i){
function e(){
r.detach().trigger("closed.bs.alert").remove()}
var f=n(this),u=f.attr("data-target"),r;
u||(u=f.attr("href"),u=u&&u.replace(/.*(?=#[^\s]*$)/,""));
r=n(u);
i&&i.preventDefault();
r.length||(r=f.closest(".alert"));
r.trigger(i=n.Event("close.bs.alert"));
i.isDefaultPrevented()||(r.removeClass("in"),n.support.transition&&r.hasClass("fade")?r.one("bsTransitionEnd",e).emulateTransitionEnd(t.TRANSITION_DURATION):e())}
;
r=n.fn.alert;
n.fn.alert=u;
n.fn.alert.Constructor=t;
n.fn.alert.noConflict=function(){
return n.fn.alert=r,this}
;
n(document).on("click.bs.alert.data-api",i,t.prototype.close)}
(jQuery);
+function(n){
"use strict";
function i(i){
return this.each(function(){
var u=n(this),r=u.data("bs.button"),f="object"==typeof i&&i;
r||u.data("bs.button",r=new t(this,f));
"toggle"==i?r.toggle():i&&r.setState(i)}
)}
var t=function(i,r){
this.$element=n(i);
this.options=n.extend({
}
,t.DEFAULTS,r);
this.isLoading=!1}
,r;
t.VERSION="3.3.6";
t.DEFAULTS={
loadingText:"loading..."}
;
t.prototype.setState=function(t){
var r="disabled",i=this.$element,f=i.is("input")?"val":"html",u=i.data();
t+="Text";
null==u.resetText&&i.data("resetText",i[f]());
setTimeout(n.proxy(function(){
i[f](null==u[t]?this.options[t]:u[t]);
"loadingText"==t?(this.isLoading=!0,i.addClass(r).attr(r,r)):this.isLoading&&(this.isLoading=!1,i.removeClass(r).removeAttr(r))}
,this),0)}
;
t.prototype.toggle=function(){
var t=!0,i=this.$element.closest('[data-toggle="buttons"]'),n;
i.length?(n=this.$element.find("input"),"radio"==n.prop("type")?(n.prop("checked")&&(t=!1),i.find(".active").removeClass("active"),this.$element.addClass("active")):"checkbox"==n.prop("type")&&(n.prop("checked")!==this.$element.hasClass("active")&&(t=!1),this.$element.toggleClass("active")),n.prop("checked",this.$element.hasClass("active")),t&&n.trigger("change")):(this.$element.attr("aria-pressed",!this.$element.hasClass("active")),this.$element.toggleClass("active"))}
;
r=n.fn.button;
n.fn.button=i;
n.fn.button.Constructor=t;
n.fn.button.noConflict=function(){
return n.fn.button=r,this}
;
n(document).on("click.bs.button.data-api",'[data-toggle^="button"]',
function(t){
var r=n(t.target);
r.hasClass("btn")||(r=r.closest(".btn"));
i.call(r,"toggle");
n(t.target).is('input[type="radio"]')||n(t.target).is('input[type="checkbox"]')||t.preventDefault()}
).on("focus.bs.button.data-api blur.bs.button.data-api",'[data-toggle^="button"]',
function(t){
n(t.target).closest(".btn").toggleClass("focus",/^focus(in)?$/.test(t.type))}
)}
(jQuery);
+function(n){
"use strict";
function i(i){
return this.each(function(){
var u=n(this),r=u.data("bs.carousel"),f=n.extend({
}
,t.DEFAULTS,u.data(),"object"==typeof i&&i),e="string"==typeof i?i:f.slide;
r||u.data("bs.carousel",r=new t(this,f));
"number"==typeof i?r.to(i):e?r[e]():f.interval&&r.pause().cycle()}
)}
var t=function(t,i){
this.$element=n(t);
this.$indicators=this.$element.find(".carousel-indicators");
this.options=i;
this.paused=null;
this.sliding=null;
this.interval=null;
this.$active=null;
this.$items=null;
this.options.keyboard&&this.$element.on("keydown.bs.carousel",n.proxy(this.keydown,this));
"hover"==this.options.pause&&!("ontouchstart"in document.documentElement)&&this.$element.on("mouseenter.bs.carousel",n.proxy(this.pause,this)).on("mouseleave.bs.carousel",n.proxy(this.cycle,this))}
,u,r;
t.VERSION="3.3.6";
t.TRANSITION_DURATION=600;
t.DEFAULTS={
interval:5e3,pause:"hover",wrap:!0,keyboard:!0}
;
t.prototype.keydown=function(n){
if(!/input|textarea/i.test(n.target.tagName)){
switch(n.which){
case 37:this.prev();
break;
case 39:this.next();
break;
default:return}
n.preventDefault()}
}
;
t.prototype.cycle=function(t){
return t||(this.paused=!1),this.interval&&clearInterval(this.interval),this.options.interval&&!this.paused&&(this.interval=setInterval(n.proxy(this.next,this),this.options.interval)),this}
;
t.prototype.getItemIndex=function(n){
return this.$items=n.parent().children(".item"),this.$items.index(n||this.$active)}
;
t.prototype.getItemForDirection=function(n,t){
var i=this.getItemIndex(t),f="prev"==n&&0===i||"next"==n&&i==this.$items.length-1,r,u;
return f&&!this.options.wrap?t:(r="prev"==n?-1:1,u=(i+r)%this.$items.length,this.$items.eq(u))}
;
t.prototype.to=function(n){
var i=this,t=this.getItemIndex(this.$active=this.$element.find(".item.active"));
if(!(n>this.$items.length-1)&&!(0>n))return this.sliding?this.$element.one("slid.bs.carousel",
function(){
i.to(n)}
):t==n?this.pause().cycle():this.slide(n>t?"next":"prev",this.$items.eq(n))}
;
t.prototype.pause=function(t){
return t||(this.paused=!0),this.$element.find(".next, .prev").length&&n.support.transition&&(this.$element.trigger(n.support.transition.end),this.cycle(!0)),this.interval=clearInterval(this.interval),this}
;
t.prototype.next=function(){
if(!this.sliding)return this.slide("next")}
;
t.prototype.prev=function(){
if(!this.sliding)return this.slide("prev")}
;
t.prototype.slide=function(i,r){
var e=this.$element.find(".item.active"),u=r||this.getItemForDirection(i,e),l=this.interval,f="next"==i?"left":"right",a=this,o,s,h,c;
return u.hasClass("active")?this.sliding=!1:(o=u[0],s=n.Event("slide.bs.carousel",{
relatedTarget:o,direction:f}
),(this.$element.trigger(s),!s.isDefaultPrevented())?((this.sliding=!0,l&&this.pause(),this.$indicators.length)&&(this.$indicators.find(".active").removeClass("active"),h=n(this.$indicators.children()[this.getItemIndex(u)]),h&&h.addClass("active")),c=n.Event("slid.bs.carousel",{
relatedTarget:o,direction:f}
),n.support.transition&&this.$element.hasClass("slide")?(u.addClass(i),u[0].offsetWidth,e.addClass(f),u.addClass(f),e.one("bsTransitionEnd",
function(){
u.removeClass([i,f].join(" ")).addClass("active");
e.removeClass(["active",f].join(" "));
a.sliding=!1;
setTimeout(function(){
a.$element.trigger(c)}
,0)}
).emulateTransitionEnd(t.TRANSITION_DURATION)):(e.removeClass("active"),u.addClass("active"),this.sliding=!1,this.$element.trigger(c)),l&&this.cycle(),this):void 0)}
;
u=n.fn.carousel;
n.fn.carousel=i;
n.fn.carousel.Constructor=t;
n.fn.carousel.noConflict=function(){
return n.fn.carousel=u,this}
;
r=function(t){
var o,r=n(this),u=n(r.attr("data-target")||(o=r.attr("href"))&&o.replace(/.*(?=#[^\s]+$)/,"")),e,f;
u.hasClass("carousel")&&(e=n.extend({
}
,u.data(),r.data()),f=r.attr("data-slide-to"),f&&(e.interval=!1),i.call(u,e),f&&u.data("bs.carousel").to(f),t.preventDefault())}
;
n(document).on("click.bs.carousel.data-api","[data-slide]",r).on("click.bs.carousel.data-api","[data-slide-to]",r);
n(window).on("load",
function(){
n('[data-ride="carousel"]').each(function(){
var t=n(this);
i.call(t,t.data())}
)}
)}
(jQuery);
+function(n){
"use strict";
function r(t){
var i,r=t.attr("data-target")||(i=t.attr("href"))&&i.replace(/.*(?=#[^\s]+$)/,"");
return n(r)}
function i(i){
return this.each(function(){
var u=n(this),r=u.data("bs.collapse"),f=n.extend({
}
,t.DEFAULTS,u.data(),"object"==typeof i&&i);
!r&&f.toggle&&/show|hide/.test(i)&&(f.toggle=!1);
r||u.data("bs.collapse",r=new t(this,f));
"string"==typeof i&&r[i]()}
)}
var t=function(i,r){
this.$element=n(i);
this.options=n.extend({
}
,t.DEFAULTS,r);
this.$trigger=n('[data-toggle="collapse"][href="#'+i.id+'"],[data-toggle="collapse"][data-target="#'+i.id+'"]');
this.transitioning=null;
this.options.parent?this.$parent=this.getParent():this.addAriaAndCollapsedClass(this.$element,this.$trigger);
this.options.toggle&&this.toggle()}
,u;
t.VERSION="3.3.6";
t.TRANSITION_DURATION=350;
t.DEFAULTS={
toggle:!0}
;
t.prototype.dimension=function(){
var n=this.$element.hasClass("width");
return n?"width":"height"}
;
t.prototype.show=function(){
var f,r,e,u,o,s;
if(!this.transitioning&&!this.$element.hasClass("in")&&(r=this.$parent&&this.$parent.children(".panel").children(".in, .collapsing"),!(r&&r.length&&(f=r.data("bs.collapse"),f&&f.transitioning))&&(e=n.Event("show.bs.collapse"),this.$element.trigger(e),!e.isDefaultPrevented()))){
if(r&&r.length&&(i.call(r,"hide"),f||r.data("bs.collapse",null)),u=this.dimension(),this.$element.removeClass("collapse").addClass("collapsing")[u](0).attr("aria-expanded",!0),this.$trigger.removeClass("collapsed").attr("aria-expanded",!0),this.transitioning=1,o=function(){
this.$element.removeClass("collapsing").addClass("collapse in")[u]("");
this.transitioning=0;
this.$element.trigger("shown.bs.collapse")}
,!n.support.transition)return o.call(this);
s=n.camelCase(["scroll",u].join("-"));
this.$element.one("bsTransitionEnd",n.proxy(o,this)).emulateTransitionEnd(t.TRANSITION_DURATION)[u](this.$element[0][s])}
}
;
t.prototype.hide=function(){
var r,i,u;
if(!this.transitioning&&this.$element.hasClass("in")&&(r=n.Event("hide.bs.collapse"),this.$element.trigger(r),!r.isDefaultPrevented()))return i=this.dimension(),this.$element[i](this.$element[i]())[0].offsetHeight,this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded",!1),this.$trigger.addClass("collapsed").attr("aria-expanded",!1),this.transitioning=1,u=function(){
this.transitioning=0;
this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")}
,n.support.transition?void this.$element[i](0).one("bsTransitionEnd",n.proxy(u,this)).emulateTransitionEnd(t.TRANSITION_DURATION):u.call(this)}
;
t.prototype.toggle=function(){
this[this.$element.hasClass("in")?"hide":"show"]()}
;
t.prototype.getParent=function(){
return n(this.options.parent).find('[data-toggle="collapse"][data-parent="'+this.options.parent+'"]').each(n.proxy(function(t,i){
var u=n(i);
this.addAriaAndCollapsedClass(r(u),u)}
,this)).end()}
;
t.prototype.addAriaAndCollapsedClass=function(n,t){
var i=n.hasClass("in");
n.attr("aria-expanded",i);
t.toggleClass("collapsed",!i).attr("aria-expanded",i)}
;
u=n.fn.collapse;
n.fn.collapse=i;
n.fn.collapse.Constructor=t;
n.fn.collapse.noConflict=function(){
return n.fn.collapse=u,this}
;
n(document).on("click.bs.collapse.data-api",'[data-toggle="collapse"]',
function(t){
var u=n(this);
u.attr("data-target")||t.preventDefault();
var f=r(u),e=f.data("bs.collapse"),o=e?"toggle":u.data();
i.call(f,o)}
)}
(jQuery);
+function(n){
"use strict";
function r(t){
var i=t.attr("data-target"),r;
return i||(i=t.attr("href"),i=i&&/#[A-Za-z]/.test(i)&&i.replace(/.*(?=#[^\s]*$)/,"")),r=i&&n(i),r&&r.length?r:t.parent()}
function u(t){
t&&3===t.which||(n(o).remove(),n(i).each(function(){
var u=n(this),i=r(u),f={
relatedTarget:this}
;
i.hasClass("open")&&(t&&"click"==t.type&&/input|textarea/i.test(t.target.tagName)&&n.contains(i[0],t.target)||(i.trigger(t=n.Event("hide.bs.dropdown",f)),t.isDefaultPrevented()||(u.attr("aria-expanded","false"),i.removeClass("open").trigger(n.Event("hidden.bs.dropdown",f)))))}
))}
function e(i){
return this.each(function(){
var r=n(this),u=r.data("bs.dropdown");
u||r.data("bs.dropdown",u=new t(this));
"string"==typeof i&&u[i].call(r)}
)}
var o=".dropdown-backdrop",i='[data-toggle="dropdown"]',t=function(t){
n(t).on("click.bs.dropdown",this.toggle)}
,f;
t.VERSION="3.3.6";
t.prototype.toggle=function(t){
var f=n(this),i,o,e;
if(!f.is(".disabled, :disabled")){
if(i=r(f),o=i.hasClass("open"),u(),!o){
if("ontouchstart"in document.documentElement&&!i.closest(".navbar-nav").length&&n(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(n(this)).on("click",u),e={
relatedTarget:this}
,i.trigger(t=n.Event("show.bs.dropdown",e)),t.isDefaultPrevented())return;
f.trigger("focus").attr("aria-expanded","true");
i.toggleClass("open").trigger(n.Event("shown.bs.dropdown",e))}
return!1}
}
;
t.prototype.keydown=function(t){
var e,o,s,h,f,u;
if(/(38|40|27|32)/.test(t.which)&&!/input|textarea/i.test(t.target.tagName)&&(e=n(this),t.preventDefault(),t.stopPropagation(),!e.is(".disabled, :disabled"))){
if(o=r(e),s=o.hasClass("open"),!s&&27!=t.which||s&&27==t.which)return 27==t.which&&o.find(i).trigger("focus"),e.trigger("click");
h=" li:not(.disabled):visible a";
f=o.find(".dropdown-menu"+h);
f.length&&(u=f.index(t.target),38==t.which&&u>0&&u--,40==t.which&&u<f.length-1&&u++,~u||(u=0),f.eq(u).trigger("focus"))}
}
;
f=n.fn.dropdown;
n.fn.dropdown=e;
n.fn.dropdown.Constructor=t;
n.fn.dropdown.noConflict=function(){
return n.fn.dropdown=f,this}
;
n(document).on("click.bs.dropdown.data-api",u).on("click.bs.dropdown.data-api",".dropdown form",
function(n){
n.stopPropagation()}
).on("click.bs.dropdown.data-api",i,t.prototype.toggle).on("keydown.bs.dropdown.data-api",i,t.prototype.keydown).on("keydown.bs.dropdown.data-api",".dropdown-menu",t.prototype.keydown)}
(jQuery);
+function(n){
"use strict";
function i(i,r){
return this.each(function(){
var f=n(this),u=f.data("bs.modal"),e=n.extend({
}
,t.DEFAULTS,f.data(),"object"==typeof i&&i);
u||f.data("bs.modal",u=new t(this,e));
"string"==typeof i?u[i](r):e.show&&u.show(r)}
)}
var t=function(t,i){
this.options=i;
this.$body=n(document.body);
this.$element=n(t);
this.$dialog=this.$element.find(".modal-dialog");
this.$backdrop=null;
this.isShown=null;
this.originalBodyPad=null;
this.scrollbarWidth=0;
this.ignoreBackdropClick=!1;
this.options.remote&&this.$element.find(".modal-content").load(this.options.remote,n.proxy(function(){
this.$element.trigger("loaded.bs.modal")}
,this))}
,r;
t.VERSION="3.3.6";
t.TRANSITION_DURATION=300;
t.BACKDROP_TRANSITION_DURATION=150;
t.DEFAULTS={
backdrop:!0,keyboard:!0,show:!0}
;
t.prototype.toggle=function(n){
return this.isShown?this.hide():this.show(n)}
;
t.prototype.show=function(i){
var r=this,u=n.Event("show.bs.modal",{
relatedTarget:i}
);
this.$element.trigger(u);
this.isShown||u.isDefaultPrevented()||(this.isShown=!0,this.checkScrollbar(),this.setScrollbar(),this.$body.addClass("modal-open"),this.escape(),this.resize(),this.$element.on("click.dismiss.bs.modal",'[data-dismiss="modal"]',n.proxy(this.hide,this)),this.$dialog.on("mousedown.dismiss.bs.modal",
function(){
r.$element.one("mouseup.dismiss.bs.modal",
function(t){
n(t.target).is(r.$element)&&(r.ignoreBackdropClick=!0)}
)}
),this.backdrop(function(){
var f=n.support.transition&&r.$element.hasClass("fade"),u;
r.$element.parent().length||r.$element.appendTo(r.$body);
r.$element.show().scrollTop(0);
r.adjustDialog();
f&&r.$element[0].offsetWidth;
r.$element.addClass("in");
r.enforceFocus();
u=n.Event("shown.bs.modal",{
relatedTarget:i}
);
f?r.$dialog.one("bsTransitionEnd",
function(){
r.$element.trigger("focus").trigger(u)}
).emulateTransitionEnd(t.TRANSITION_DURATION):r.$element.trigger("focus").trigger(u)}
))}
;
t.prototype.hide=function(i){
i&&i.preventDefault();
i=n.Event("hide.bs.modal");
this.$element.trigger(i);
this.isShown&&!i.isDefaultPrevented()&&(this.isShown=!1,this.escape(),this.resize(),n(document).off("focusin.bs.modal"),this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"),this.$dialog.off("mousedown.dismiss.bs.modal"),n.support.transition&&this.$element.hasClass("fade")?this.$element.one("bsTransitionEnd",n.proxy(this.hideModal,this)).emulateTransitionEnd(t.TRANSITION_DURATION):this.hideModal())}
;
t.prototype.enforceFocus=function(){
n(document).off("focusin.bs.modal").on("focusin.bs.modal",n.proxy(function(n){
this.$element[0]===n.target||this.$element.has(n.target).length||this.$element.trigger("focus")}
,this))}
;
t.prototype.escape=function(){
this.isShown&&this.options.keyboard?this.$element.on("keydown.dismiss.bs.modal",n.proxy(function(n){
27==n.which&&this.hide()}
,this)):this.isShown||this.$element.off("keydown.dismiss.bs.modal")}
;
t.prototype.resize=function(){
this.isShown?n(window).on("resize.bs.modal",n.proxy(this.handleUpdate,this)):n(window).off("resize.bs.modal")}
;
t.prototype.hideModal=function(){
var n=this;
this.$element.hide();
this.backdrop(function(){
n.$body.removeClass("modal-open");
n.resetAdjustments();
n.resetScrollbar();
n.$element.trigger("hidden.bs.modal")}
)}
;
t.prototype.removeBackdrop=function(){
this.$backdrop&&this.$backdrop.remove();
this.$backdrop=null}
;
t.prototype.backdrop=function(i){
var e=this,f=this.$element.hasClass("fade")?"fade":"",r,u;
if(this.isShown&&this.options.backdrop){
if(r=n.support.transition&&f,this.$backdrop=n(document.createElement("div")).addClass("modal-backdrop "+f).appendTo(this.$body),this.$element.on("click.dismiss.bs.modal",n.proxy(function(n){
return this.ignoreBackdropClick?void(this.ignoreBackdropClick=!1):void(n.target===n.currentTarget&&("static"==this.options.backdrop?this.$element[0].focus():this.hide()))}
,this)),r&&this.$backdrop[0].offsetWidth,this.$backdrop.addClass("in"),!i)return;
r?this.$backdrop.one("bsTransitionEnd",i).emulateTransitionEnd(t.BACKDROP_TRANSITION_DURATION):i()}
else!this.isShown&&this.$backdrop?(this.$backdrop.removeClass("in"),u=function(){
e.removeBackdrop();
i&&i()}
,n.support.transition&&this.$element.hasClass("fade")?this.$backdrop.one("bsTransitionEnd",u).emulateTransitionEnd(t.BACKDROP_TRANSITION_DURATION):u()):i&&i()}
;
t.prototype.handleUpdate=function(){
this.adjustDialog()}
;
t.prototype.adjustDialog=function(){
var n=this.$element[0].scrollHeight>document.documentElement.clientHeight;
this.$element.css({
paddingLeft:!this.bodyIsOverflowing&&n?this.scrollbarWidth:"",paddingRight:this.bodyIsOverflowing&&!n?this.scrollbarWidth:""}
)}
;
t.prototype.resetAdjustments=function(){
this.$element.css({
paddingLeft:"",paddingRight:""}
)}
;
t.prototype.checkScrollbar=function(){
var n=window.innerWidth,t;
n||(t=document.documentElement.getBoundingClientRect(),n=t.right-Math.abs(t.left));
this.bodyIsOverflowing=document.body.clientWidth<n;
this.scrollbarWidth=this.measureScrollbar()}
;
t.prototype.setScrollbar=function(){
var n=parseInt(this.$body.css("padding-right")||0,10);
this.originalBodyPad=document.body.style.paddingRight||"";
this.bodyIsOverflowing&&this.$body.css("padding-right",n+this.scrollbarWidth)}
;
t.prototype.resetScrollbar=function(){
this.$body.css("padding-right",this.originalBodyPad)}
;
t.prototype.measureScrollbar=function(){
var n=document.createElement("div"),t;
return n.className="modal-scrollbar-measure",this.$body.append(n),t=n.offsetWidth-n.clientWidth,this.$body[0].removeChild(n),t}
;
r=n.fn.modal;
n.fn.modal=i;
n.fn.modal.Constructor=t;
n.fn.modal.noConflict=function(){
return n.fn.modal=r,this}
;
n(document).on("click.bs.modal.data-api",'[data-toggle="modal"]',
function(t){
var r=n(this),f=r.attr("href"),u=n(r.attr("data-target")||f&&f.replace(/.*(?=#[^\s]+$)/,"")),e=u.data("bs.modal")?"toggle":n.extend({
remote:!/#/.test(f)&&f}
,u.data(),r.data());
r.is("a")&&t.preventDefault();
u.one("show.bs.modal",
function(n){
n.isDefaultPrevented()||u.one("hidden.bs.modal",
function(){
r.is(":visible")&&r.trigger("focus")}
)}
);
i.call(u,e,this)}
)}
(jQuery);
+function(n){
"use strict";
function r(i){
return this.each(function(){
var u=n(this),r=u.data("bs.tooltip"),f="object"==typeof i&&i;
(r||!/destroy|hide/.test(i))&&(r||u.data("bs.tooltip",r=new t(this,f)),"string"==typeof i&&r[i]())}
)}
var t=function(n,t){
this.type=null;
this.options=null;
this.enabled=null;
this.timeout=null;
this.hoverState=null;
this.$element=null;
this.inState=null;
this.init("tooltip",n,t)}
,i;
t.VERSION="3.3.6";
t.TRANSITION_DURATION=150;
t.DEFAULTS={
animation:!0,placement:"top",selector:!1,template:'<div class="tooltip" role="tooltip"><div class="tooltip-arrow"><\/div><div class="tooltip-inner"><\/div><\/div>',trigger:"hover focus",title:"",delay:0,html:!1,container:!1,viewport:{
selector:"body",padding:0}
}
;
t.prototype.init=function(t,i,r){
var f,e,u,o,s;
if(this.enabled=!0,this.type=t,this.$element=n(i),this.options=this.getOptions(r),this.$viewport=this.options.viewport&&n(n.isFunction(this.options.viewport)?this.options.viewport.call(this,this.$element):this.options.viewport.selector||this.options.viewport),this.inState={
click:!1,hover:!1,focus:!1}
,this.$element[0]instanceof document.constructor&&!this.options.selector)throw new Error("`selector` option must be specified when initializing "+this.type+" on the window.document object!");
for(f=this.options.trigger.split(" "),e=f.length;
e--;
)if(u=f[e],"click"==u)this.$element.on("click."+this.type,this.options.selector,n.proxy(this.toggle,this));
else"manual"!=u&&(o="hover"==u?"mouseenter":"focusin",s="hover"==u?"mouseleave":"focusout",this.$element.on(o+"."+this.type,this.options.selector,n.proxy(this.enter,this)),this.$element.on(s+"."+this.type,this.options.selector,n.proxy(this.leave,this)));
this.options.selector?this._options=n.extend({
}
,this.options,{
trigger:"manual",selector:""}
):this.fixTitle()}
;
t.prototype.getDefaults=function(){
return t.DEFAULTS}
;
t.prototype.getOptions=function(t){
return t=n.extend({
}
,this.getDefaults(),this.$element.data(),t),t.delay&&"number"==typeof t.delay&&(t.delay={
show:t.delay,hide:t.delay}
),t}
;
t.prototype.getDelegateOptions=function(){
var t={
}
,i=this.getDefaults();
return this._options&&n.each(this._options,
function(n,r){
i[n]!=r&&(t[n]=r)}
),t}
;
t.prototype.enter=function(t){
var i=t instanceof this.constructor?t:n(t.currentTarget).data("bs."+this.type);
return i||(i=new this.constructor(t.currentTarget,this.getDelegateOptions()),n(t.currentTarget).data("bs."+this.type,i)),t instanceof n.Event&&(i.inState["focusin"==t.type?"focus":"hover"]=!0),i.tip().hasClass("in")||"in"==i.hoverState?void(i.hoverState="in"):(clearTimeout(i.timeout),i.hoverState="in",i.options.delay&&i.options.delay.show?void(i.timeout=setTimeout(function(){
"in"==i.hoverState&&i.show()}
,i.options.delay.show)):i.show())}
;
t.prototype.isInStateTrue=function(){
for(var n in this.inState)if(this.inState[n])return!0;
return!1}
;
t.prototype.leave=function(t){
var i=t instanceof this.constructor?t:n(t.currentTarget).data("bs."+this.type);
return i||(i=new this.constructor(t.currentTarget,this.getDelegateOptions()),n(t.currentTarget).data("bs."+this.type,i)),t instanceof n.Event&&(i.inState["focusout"==t.type?"focus":"hover"]=!1),i.isInStateTrue()?void 0:(clearTimeout(i.timeout),i.hoverState="out",i.options.delay&&i.options.delay.hide?void(i.timeout=setTimeout(function(){
"out"==i.hoverState&&i.hide()}
,i.options.delay.hide)):i.hide())}
;
t.prototype.show=function(){
var c=n.Event("show.bs."+this.type),l,p,e,w,h;
if(this.hasContent()&&this.enabled){
if(this.$element.trigger(c),l=n.contains(this.$element[0].ownerDocument.documentElement,this.$element[0]),c.isDefaultPrevented()||!l)return;
var u=this,r=this.tip(),a=this.getUID(this.type);
this.setContent();
r.attr("id",a);
this.$element.attr("aria-describedby",a);
this.options.animation&&r.addClass("fade");
var i="function"==typeof this.options.placement?this.options.placement.call(this,r[0],this.$element[0]):this.options.placement,v=/\s?auto?\s?/i,y=v.test(i);
y&&(i=i.replace(v,"")||"top");
r.detach().css({
top:0,left:0,display:"block"}
).addClass(i).data("bs."+this.type,this);
this.options.container?r.appendTo(this.options.container):r.insertAfter(this.$element);
this.$element.trigger("inserted.bs."+this.type);
var f=this.getPosition(),o=r[0].offsetWidth,s=r[0].offsetHeight;
y&&(p=i,e=this.getPosition(this.$viewport),i="bottom"==i&&f.bottom+s>e.bottom?"top":"top"==i&&f.top-s<e.top?"bottom":"right"==i&&f.right+o>e.width?"left":"left"==i&&f.left-o<e.left?"right":i,r.removeClass(p).addClass(i));
w=this.getCalculatedOffset(i,f,o,s);
this.applyPlacement(w,i);
h=function(){
var n=u.hoverState;
u.$element.trigger("shown.bs."+u.type);
u.hoverState=null;
"out"==n&&u.leave(u)}
;
n.support.transition&&this.$tip.hasClass("fade")?r.one("bsTransitionEnd",h).emulateTransitionEnd(t.TRANSITION_DURATION):h()}
}
;
t.prototype.applyPlacement=function(t,i){
var r=this.tip(),l=r[0].offsetWidth,e=r[0].offsetHeight,o=parseInt(r.css("margin-top"),10),s=parseInt(r.css("margin-left"),10),h,f,u;
isNaN(o)&&(o=0);
isNaN(s)&&(s=0);
t.top+=o;
t.left+=s;
n.offset.setOffset(r[0],n.extend({
using:function(n){
r.css({
top:Math.round(n.top),left:Math.round(n.left)}
)}
}
,t),0);
r.addClass("in");
h=r[0].offsetWidth;
f=r[0].offsetHeight;
"top"==i&&f!=e&&(t.top=t.top+e-f);
u=this.getViewportAdjustedDelta(i,t,h,f);
u.left?t.left+=u.left:t.top+=u.top;
var c=/top|bottom/.test(i),a=c?2*u.left-l+h:2*u.top-e+f,v=c?"offsetWidth":"offsetHeight";
r.offset(t);
this.replaceArrow(a,r[0][v],c)}
;
t.prototype.replaceArrow=function(n,t,i){
this.arrow().css(i?"left":"top",50*(1-n/t)+"%").css(i?"top":"left","")}
;
t.prototype.setContent=function(){
var n=this.tip(),t=this.getTitle();
n.find(".tooltip-inner")[this.options.html?"html":"text"](t);
n.removeClass("fade in top bottom left right")}
;
t.prototype.hide=function(i){
function f(){
"in"!=u.hoverState&&r.detach();
u.$element.removeAttr("aria-describedby").trigger("hidden.bs."+u.type);
i&&i()}
var u=this,r=n(this.$tip),e=n.Event("hide.bs."+this.type);
return this.$element.trigger(e),e.isDefaultPrevented()?void 0:(r.removeClass("in"),n.support.transition&&r.hasClass("fade")?r.one("bsTransitionEnd",f).emulateTransitionEnd(t.TRANSITION_DURATION):f(),this.hoverState=null,this)}
;
t.prototype.fixTitle=function(){
var n=this.$element;
(n.attr("title")||"string"!=typeof n.attr("data-original-title"))&&n.attr("data-original-title",n.attr("title")||"").attr("title","")}
;
t.prototype.hasContent=function(){
return this.getTitle()}
;
t.prototype.getPosition=function(t){
t=t||this.$element;
var u=t[0],r="BODY"==u.tagName,i=u.getBoundingClientRect();
null==i.width&&(i=n.extend({
}
,i,{
width:i.right-i.left,height:i.bottom-i.top}
));
var f=r?{
top:0,left:0}
:t.offset(),e={
scroll:r?document.documentElement.scrollTop||document.body.scrollTop:t.scrollTop()}
,o=r?{
width:n(window).width(),height:n(window).height()}
:null;
return n.extend({
}
,i,e,o,f)}
;
t.prototype.getCalculatedOffset=function(n,t,i,r){
return"bottom"==n?{
top:t.top+t.height,left:t.left+t.width/2-i/2}
:"top"==n?{
top:t.top-r,left:t.left+t.width/2-i/2}
:"left"==n?{
top:t.top+t.height/2-r/2,left:t.left-i}
:{
top:t.top+t.height/2-r/2,left:t.left+t.width}
}
;
t.prototype.getViewportAdjustedDelta=function(n,t,i,r){
var f={
top:0,left:0}
,e,u,o,s,h,c;
return this.$viewport?(e=this.options.viewport&&this.options.viewport.padding||0,u=this.getPosition(this.$viewport),/right|left/.test(n)?(o=t.top-e-u.scroll,s=t.top+e-u.scroll+r,o<u.top?f.top=u.top-o:s>u.top+u.height&&(f.top=u.top+u.height-s)):(h=t.left-e,c=t.left+e+i,h<u.left?f.left=u.left-h:c>u.right&&(f.left=u.left+u.width-c)),f):f}
;
t.prototype.getTitle=function(){
var t=this.$element,n=this.options;
return t.attr("data-original-title")||("function"==typeof n.title?n.title.call(t[0]):n.title)}
;
t.prototype.getUID=function(n){
do n+=~~(1e6*Math.random());
while(document.getElementById(n));
return n}
;
t.prototype.tip=function(){
if(!this.$tip&&(this.$tip=n(this.options.template),1!=this.$tip.length))throw new Error(this.type+" `template` option must consist of exactly 1 top-level element!");
return this.$tip}
;
t.prototype.arrow=function(){
return this.$arrow=this.$arrow||this.tip().find(".tooltip-arrow")}
;
t.prototype.enable=function(){
this.enabled=!0}
;
t.prototype.disable=function(){
this.enabled=!1}
;
t.prototype.toggleEnabled=function(){
this.enabled=!this.enabled}
;
t.prototype.toggle=function(t){
var i=this;
t&&(i=n(t.currentTarget).data("bs."+this.type),i||(i=new this.constructor(t.currentTarget,this.getDelegateOptions()),n(t.currentTarget).data("bs."+this.type,i)));
t?(i.inState.click=!i.inState.click,i.isInStateTrue()?i.enter(i):i.leave(i)):i.tip().hasClass("in")?i.leave(i):i.enter(i)}
;
t.prototype.destroy=function(){
var n=this;
clearTimeout(this.timeout);
this.hide(function(){
n.$element.off("."+n.type).removeData("bs."+n.type);
n.$tip&&n.$tip.detach();
n.$tip=null;
n.$arrow=null;
n.$viewport=null}
)}
;
i=n.fn.tooltip;
n.fn.tooltip=r;
n.fn.tooltip.Constructor=t;
n.fn.tooltip.noConflict=function(){
return n.fn.tooltip=i,this}
}
(jQuery);
+function(n){
"use strict";
function r(i){
return this.each(function(){
var u=n(this),r=u.data("bs.popover"),f="object"==typeof i&&i;
(r||!/destroy|hide/.test(i))&&(r||u.data("bs.popover",r=new t(this,f)),"string"==typeof i&&r[i]())}
)}
var t=function(n,t){
this.init("popover",n,t)}
,i;
if(!n.fn.tooltip)throw new Error("Popover requires tooltip.js");
t.VERSION="3.3.6";
t.DEFAULTS=n.extend({
}
,n.fn.tooltip.Constructor.DEFAULTS,{
placement:"right",trigger:"click",content:"",template:'<div class="popover" role="tooltip"><div class="arrow"><\/div><h3 class="popover-title"><\/h3><div class="popover-content"><\/div><\/div>'}
);
t.prototype=n.extend({
}
,n.fn.tooltip.Constructor.prototype);
t.prototype.constructor=t;
t.prototype.getDefaults=function(){
return t.DEFAULTS}
;
t.prototype.setContent=function(){
var n=this.tip(),i=this.getTitle(),t=this.getContent();
n.find(".popover-title")[this.options.html?"html":"text"](i);
n.find(".popover-content").children().detach().end()[this.options.html?"string"==typeof t?"html":"append":"text"](t);
n.removeClass("fade top bottom left right in");
n.find(".popover-title").html()||n.find(".popover-title").hide()}
;
t.prototype.hasContent=function(){
return this.getTitle()||this.getContent()}
;
t.prototype.getContent=function(){
var t=this.$element,n=this.options;
return t.attr("data-content")||("function"==typeof n.content?n.content.call(t[0]):n.content)}
;
t.prototype.arrow=function(){
return this.$arrow=this.$arrow||this.tip().find(".arrow")}
;
i=n.fn.popover;
n.fn.popover=r;
n.fn.popover.Constructor=t;
n.fn.popover.noConflict=function(){
return n.fn.popover=i,this}
}
(jQuery);
+function(n){
"use strict";
function t(i,r){
this.$body=n(document.body);
this.$scrollElement=n(n(i).is(document.body)?window:i);
this.options=n.extend({
}
,t.DEFAULTS,r);
this.selector=(this.options.target||"")+" .nav li > a";
this.offsets=[];
this.targets=[];
this.activeTarget=null;
this.scrollHeight=0;
this.$scrollElement.on("scroll.bs.scrollspy",n.proxy(this.process,this));
this.refresh();
this.process()}
function i(i){
return this.each(function(){
var u=n(this),r=u.data("bs.scrollspy"),f="object"==typeof i&&i;
r||u.data("bs.scrollspy",r=new t(this,f));
"string"==typeof i&&r[i]()}
)}
t.VERSION="3.3.6";
t.DEFAULTS={
offset:10}
;
t.prototype.getScrollHeight=function(){
return this.$scrollElement[0].scrollHeight||Math.max(this.$body[0].scrollHeight,document.documentElement.scrollHeight)}
;
t.prototype.refresh=function(){
var t=this,i="offset",r=0;
this.offsets=[];
this.targets=[];
this.scrollHeight=this.getScrollHeight();
n.isWindow(this.$scrollElement[0])||(i="position",r=this.$scrollElement.scrollTop());
this.$body.find(this.selector).map(function(){
var f=n(this),u=f.data("target")||f.attr("href"),t=/^#./.test(u)&&n(u);
return t&&t.length&&t.is(":visible")&&[[t[i]().top+r,u]]||null}
).sort(function(n,t){
return n[0]-t[0]}
).each(function(){
t.offsets.push(this[0]);
t.targets.push(this[1])}
)}
;
t.prototype.process=function(){
var n,i=this.$scrollElement.scrollTop()+this.options.offset,f=this.getScrollHeight(),e=this.options.offset+f-this.$scrollElement.height(),t=this.offsets,r=this.targets,u=this.activeTarget;
if(this.scrollHeight!=f&&this.refresh(),i>=e)return u!=(n=r[r.length-1])&&this.activate(n);
if(u&&i<t[0])return this.activeTarget=null,this.clear();
for(n=t.length;
n--;
)u!=r[n]&&i>=t[n]&&(void 0===t[n+1]||i<t[n+1])&&this.activate(r[n])}
;
t.prototype.activate=function(t){
this.activeTarget=t;
this.clear();
var r=this.selector+'[data-target="'+t+'"],'+this.selector+'[href="'+t+'"]',i=n(r).parents("li").addClass("active");
i.parent(".dropdown-menu").length&&(i=i.closest("li.dropdown").addClass("active"));
i.trigger("activate.bs.scrollspy")}
;
t.prototype.clear=function(){
n(this.selector).parentsUntil(this.options.target,".active").removeClass("active")}
;
var r=n.fn.scrollspy;
n.fn.scrollspy=i;
n.fn.scrollspy.Constructor=t;
n.fn.scrollspy.noConflict=function(){
return n.fn.scrollspy=r,this}
;
n(window).on("load.bs.scrollspy.data-api",
function(){
n('[data-spy="scroll"]').each(function(){
var t=n(this);
i.call(t,t.data())}
)}
)}
(jQuery);
+function(n){
"use strict";
function r(i){
return this.each(function(){
var u=n(this),r=u.data("bs.tab");
r||u.data("bs.tab",r=new t(this));
"string"==typeof i&&r[i]()}
)}
var t=function(t){
this.element=n(t)}
,u,i;
t.VERSION="3.3.6";
t.TRANSITION_DURATION=150;
t.prototype.show=function(){
var t=this.element,f=t.closest("ul:not(.dropdown-menu)"),i=t.data("target"),u;
if(i||(i=t.attr("href"),i=i&&i.replace(/.*(?=#[^\s]*$)/,"")),!t.parent("li").hasClass("active")){
var r=f.find(".active:last a"),e=n.Event("hide.bs.tab",{
relatedTarget:t[0]}
),o=n.Event("show.bs.tab",{
relatedTarget:r[0]}
);
(r.trigger(e),t.trigger(o),o.isDefaultPrevented()||e.isDefaultPrevented())||(u=n(i),this.activate(t.closest("li"),f),this.activate(u,u.parent(),
function(){
r.trigger({
type:"hidden.bs.tab",relatedTarget:t[0]}
);
t.trigger({
type:"shown.bs.tab",relatedTarget:r[0]}
)}
))}
}
;
t.prototype.activate=function(i,r,u){
function e(){
f.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!1);
i.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded",!0);
o?(i[0].offsetWidth,i.addClass("in")):i.removeClass("fade");
i.parent(".dropdown-menu").length&&i.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!0);
u&&u()}
var f=r.find("> .active"),o=u&&n.support.transition&&(f.length&&f.hasClass("fade")||!!r.find("> .fade").length);
f.length&&o?f.one("bsTransitionEnd",e).emulateTransitionEnd(t.TRANSITION_DURATION):e();
f.removeClass("in")}
;
u=n.fn.tab;
n.fn.tab=r;
n.fn.tab.Constructor=t;
n.fn.tab.noConflict=function(){
return n.fn.tab=u,this}
;
i=function(t){
t.preventDefault();
r.call(n(this),"show")}
;
n(document).on("click.bs.tab.data-api",'[data-toggle="tab"]',i).on("click.bs.tab.data-api",'[data-toggle="pill"]',i)}
(jQuery);
+function(n){
"use strict";
function i(i){
return this.each(function(){
var u=n(this),r=u.data("bs.affix"),f="object"==typeof i&&i;
r||u.data("bs.affix",r=new t(this,f));
"string"==typeof i&&r[i]()}
)}
var t=function(i,r){
this.options=n.extend({
}
,t.DEFAULTS,r);
this.$target=n(this.options.target).on("scroll.bs.affix.data-api",n.proxy(this.checkPosition,this)).on("click.bs.affix.data-api",n.proxy(this.checkPositionWithEventLoop,this));
this.$element=n(i);
this.affixed=null;
this.unpin=null;
this.pinnedOffset=null;
this.checkPosition()}
,r;
t.VERSION="3.3.6";
t.RESET="affix affix-top affix-bottom";
t.DEFAULTS={
offset:0,target:window}
;
t.prototype.getState=function(n,t,i,r){
var u=this.$target.scrollTop(),f=this.$element.offset(),e=this.$target.height();
if(null!=i&&"top"==this.affixed)return i>u?"top":!1;
if("bottom"==this.affixed)return null!=i?u+this.unpin<=f.top?!1:"bottom":n-r>=u+e?!1:"bottom";
var o=null==this.affixed,s=o?u:f.top,h=o?e:t;
return null!=i&&i>=u?"top":null!=r&&s+h>=n-r?"bottom":!1}
;
t.prototype.getPinnedOffset=function(){
if(this.pinnedOffset)return this.pinnedOffset;
this.$element.removeClass(t.RESET).addClass("affix");
var n=this.$target.scrollTop(),i=this.$element.offset();
return this.pinnedOffset=i.top-n}
;
t.prototype.checkPositionWithEventLoop=function(){
setTimeout(n.proxy(this.checkPosition,this),1)}
;
t.prototype.checkPosition=function(){
var i,e,o;
if(this.$element.is(":visible")){
var s=this.$element.height(),r=this.options.offset,f=r.top,u=r.bottom,h=Math.max(n(document).height(),n(document.body).height());
if("object"!=typeof r&&(u=f=r),"function"==typeof f&&(f=r.top(this.$element)),"function"==typeof u&&(u=r.bottom(this.$element)),i=this.getState(h,s,f,u),this.affixed!=i){
if(null!=this.unpin&&this.$element.css("top",""),e="affix"+(i?"-"+i:""),o=n.Event(e+".bs.affix"),this.$element.trigger(o),o.isDefaultPrevented())return;
this.affixed=i;
this.unpin="bottom"==i?this.getPinnedOffset():null;
this.$element.removeClass(t.RESET).addClass(e).trigger(e.replace("affix","affixed")+".bs.affix")}
"bottom"==i&&this.$element.offset({
top:h-s-u}
)}
}
;
r=n.fn.affix;
n.fn.affix=i;
n.fn.affix.Constructor=t;
n.fn.affix.noConflict=function(){
return n.fn.affix=r,this}
;
n(window).on("load",
function(){
n('[data-spy="affix"]').each(function(){
var r=n(this),t=r.data();
t.offset=t.offset||{
}
;
null!=t.offsetBottom&&(t.offset.bottom=t.offsetBottom);
null!=t.offsetTop&&(t.offset.top=t.offsetTop);
i.call(r,t)}
)}
)}
(jQuery);
!function(n){
"function"==typeof define&&define.amd?define(["jquery"],n):n("object"==typeof exports?require("jquery"):jQuery)}
(function(n){
function r(t){
var i=!1;
return n('[data-notify="container"]').each(function(r,u){
var f=n(u),e=f.find('[data-notify="title"]').text().trim(),o=f.find('[data-notify="message"]').html().trim(),s=e===n("<div>"+t.settings.content.title+"<\/div>").html().trim(),h=o===n("<div>"+t.settings.content.message+"<\/div>").html().trim(),c=f.hasClass("alert-"+t.settings.type);
return s&&h&&c&&(i=!0),!i}
),i}
function i(i,u,f){
var e={
content:{
message:"object"==typeof u?u.message:u,title:u.title?u.title:"",icon:u.icon?u.icon:"",url:u.url?u.url:"#",target:u.target?u.target:"-"}
}
;
f=n.extend(!0,{
}
,e,f);
this.settings=n.extend(!0,{
}
,t,f);
this._defaults=t;
"-"===this.settings.content.target&&(this.settings.content.target=this.settings.url_target);
this.animations={
start:"webkitAnimationStart oanimationstart MSAnimationStart animationstart",end:"webkitAnimationEnd oanimationend MSAnimationEnd animationend"}
;
"number"==typeof this.settings.offset&&(this.settings.offset={
x:this.settings.offset,y:this.settings.offset}
);
(this.settings.allow_duplicates||!this.settings.allow_duplicates&&!r(this))&&this.init()}
var t={
element:"body",position:null,type:"info",allow_dismiss:!0,allow_duplicates:!0,newest_on_top:!1,showProgressbar:!1,placement:{
from:"top",align:"right"}
,offset:20,spacing:10,z_index:1031,timer:1e3,url_target:"_blank",mouse_over:null,animate:{
enter:"animated fadeInDown",exit:"animated fadeOutUp"}
,onShow:null,onShown:null,onClose:null,onClosed:null,icon_type:"class",template:'<div data-notify="container" class="col-xs-11 col-sm-4 alert alert-{
0}
" role="alert"><button type="button" aria-hidden="true" class="close" data-notify="dismiss">&times;
<\/button><span data-notify="icon"><\/span> <span data-notify="title">{
1}
<\/span> <span data-notify="message">{
2}
<\/span><div class="progress" data-notify="progressbar"><div class="progress-bar progress-bar-{
0}
" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;
"><\/div><\/div><a href="{
3}
" target="{
4}
" data-notify="url"><\/a><\/div>'}
;
String.format=function(){
for(var t=arguments[0],n=1;
n<arguments.length;
n++)t=t.replace(RegExp("\\{
"+(n-1)+"\\}
","gm"),arguments[n]);
return t}
;
n.extend(i.prototype,{
init:function(){
var n=this;
this.buildNotify();
this.settings.content.icon&&this.setIcon();
"#"!=this.settings.content.url&&this.styleURL();
this.styleDismiss();
this.placement();
this.bind();
this.notify={
$ele:this.$ele,update:function(t,i){
var r={
}
,u,f,e,o;
"string"==typeof t?r[t]=i:r=t;
for(u in r)switch(u){
case"type":this.$ele.removeClass("alert-"+n.settings.type);
this.$ele.find('[data-notify="progressbar"] > .progress-bar').removeClass("progress-bar-"+n.settings.type);
n.settings.type=r[u];
this.$ele.addClass("alert-"+r[u]).find('[data-notify="progressbar"] > .progress-bar').addClass("progress-bar-"+r[u]);
break;
case"icon":f=this.$ele.find('[data-notify="icon"]');
"class"===n.settings.icon_type.toLowerCase()?f.removeClass(n.settings.content.icon).addClass(r[u]):(f.is("img")||f.find("img"),f.attr("src",r[u]));
break;
case"progress":e=n.settings.delay-n.settings.delay*(r[u]/100);
this.$ele.data("notify-delay",e);
this.$ele.find('[data-notify="progressbar"] > div').attr("aria-valuenow",r[u]).css("width",r[u]+"%");
break;
case"url":this.$ele.find('[data-notify="url"]').attr("href",r[u]);
break;
case"target":this.$ele.find('[data-notify="url"]').attr("target",r[u]);
break;
default:this.$ele.find('[data-notify="'+u+'"]').html(r[u])}
o=this.$ele.outerHeight()+parseInt(n.settings.spacing)+parseInt(n.settings.offset.y);
n.reposition(o)}
,close:function(){
n.close()}
}
}
,buildNotify:function(){
var t=this.settings.content;
this.$ele=n(String.format(this.settings.template,this.settings.type,t.title,t.message,t.url,t.target));
this.$ele.attr("data-notify-position",this.settings.placement.from+"-"+this.settings.placement.align);
this.settings.allow_dismiss||this.$ele.find('[data-notify="dismiss"]').css("display","none");
(this.settings.delay<=0&&!this.settings.showProgressbar||!this.settings.showProgressbar)&&this.$ele.find('[data-notify="progressbar"]').remove()}
,setIcon:function(){
"class"===this.settings.icon_type.toLowerCase()?this.$ele.find('[data-notify="icon"]').addClass(this.settings.content.icon):this.$ele.find('[data-notify="icon"]').is("img")?this.$ele.find('[data-notify="icon"]').attr("src",this.settings.content.icon):this.$ele.find('[data-notify="icon"]').append('<img src="'+this.settings.content.icon+'" alt="Notify Icon" />')}
,styleDismiss:function(){
this.$ele.find('[data-notify="dismiss"]').css({
position:"absolute",right:"10px",top:"5px",zIndex:this.settings.z_index+2}
)}
,styleURL:function(){
this.$ele.find('[data-notify="url"]').css({
backgroundImage:"url(data:image/gif;
base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)",height:"100%",left:0,position:"absolute",top:0,width:"100%",zIndex:this.settings.z_index+1}
)}
,placement:function(){
var t=this,i=this.settings.offset.y,r={
display:"inline-block",margin:"0px auto",position:this.settings.position?this.settings.position:"body"===this.settings.element?"fixed":"absolute",transition:"all .5s ease-in-out",zIndex:this.settings.z_index}
,u=!1,f=this.settings;
switch(n('[data-notify-position="'+this.settings.placement.from+"-"+this.settings.placement.align+'"]:not([data-closing="true"])').each(function(){
i=Math.max(i,parseInt(n(this).css(f.placement.from))+parseInt(n(this).outerHeight())+parseInt(f.spacing))}
),this.settings.newest_on_top===!0&&(i=this.settings.offset.y),r[this.settings.placement.from]=i+"px",this.settings.placement.align){
case"left":case"right":r[this.settings.placement.align]=this.settings.offset.x+"px";
break;
case"center":r.left=0;
r.right=0}
this.$ele.css(r).addClass(this.settings.animate.enter);
n.each(Array("webkit-","moz-","o-","ms-",""),
function(n,i){
t.$ele[0].style[i+"AnimationIterationCount"]=1}
);
n(this.settings.element).append(this.$ele);
this.settings.newest_on_top===!0&&(i=parseInt(i)+parseInt(this.settings.spacing)+this.$ele.outerHeight(),this.reposition(i));
n.isFunction(t.settings.onShow)&&t.settings.onShow.call(this.$ele);
this.$ele.one(this.animations.start,
function(){
u=!0}
).one(this.animations.end,
function(){
t.$ele.removeClass(t.settings.animate.enter);
n.isFunction(t.settings.onShown)&&t.settings.onShown.call(this)}
);
setTimeout(function(){
u||n.isFunction(t.settings.onShown)&&t.settings.onShown.call(this)}
,600)}
,bind:function(){
var t=this,i;
(this.$ele.find('[data-notify="dismiss"]').on("click",
function(){
t.close()}
),this.$ele.mouseover(function(){
n(this).data("data-hover","true")}
).mouseout(function(){
n(this).data("data-hover","false")}
),this.$ele.data("data-hover","false"),this.settings.delay>0)&&(t.$ele.data("notify-delay",t.settings.delay),i=setInterval(function(){
var n=parseInt(t.$ele.data("notify-delay"))-t.settings.timer,r;
("false"===t.$ele.data("data-hover")&&"pause"===t.settings.mouse_over||"pause"!=t.settings.mouse_over)&&(r=(t.settings.delay-n)/t.settings.delay*100,t.$ele.data("notify-delay",n),t.$ele.find('[data-notify="progressbar"] > div').attr("aria-valuenow",r).css("width",r+"%"));
n<=-t.settings.timer&&(clearInterval(i),t.close())}
,t.settings.timer))}
,close:function(){
var t=this,r=parseInt(this.$ele.css(this.settings.placement.from)),i=!1;
this.$ele.attr("data-closing","true").addClass(this.settings.animate.exit);
t.reposition(r);
n.isFunction(t.settings.onClose)&&t.settings.onClose.call(this.$ele);
this.$ele.one(this.animations.start,
function(){
i=!0}
).one(this.animations.end,
function(){
n(this).remove();
n.isFunction(t.settings.onClosed)&&t.settings.onClosed.call(this)}
);
setTimeout(function(){
i||(t.$ele.remove(),t.settings.onClosed&&t.settings.onClosed(t.$ele))}
,600)}
,reposition:function(t){
var i=this,r='[data-notify-position="'+this.settings.placement.from+"-"+this.settings.placement.align+'"]:not([data-closing="true"])',u=this.$ele.nextAll(r);
this.settings.newest_on_top===!0&&(u=this.$ele.prevAll(r));
u.each(function(){
n(this).css(i.settings.placement.from,t);
t=parseInt(t)+parseInt(i.settings.spacing)+n(this).outerHeight()}
)}
}
);
n.notify=function(n,t){
var r=new i(this,n,t);
return r.notify}
;
n.notifyDefaults=function(i){
return t=n.extend(!0,{
}
,t,i)}
;
n.notifyClose=function(t){
"warning"===t&&(t="danger");
"undefined"==typeof t||"all"===t?n("[data-notify]").find('[data-notify="dismiss"]').trigger("click"):"success"===t||"info"===t||"warning"===t||"danger"===t?n(".alert-"+t+"[data-notify]").find('[data-notify="dismiss"]').trigger("click"):t?n(t+"[data-notify]").find('[data-notify="dismiss"]').trigger("click"):n('[data-notify-position="'+t+'"]').find('[data-notify="dismiss"]').trigger("click")}
;
n.notifyCloseExcept=function(t){
"warning"===t&&(t="danger");
"success"===t||"info"===t||"warning"===t||"danger"===t?n("[data-notify]").not(".alert-"+t).find('[data-notify="dismiss"]').trigger("click"):n("[data-notify]").not(t).find('[data-notify="dismiss"]').trigger("click")}
}
),
function(n,t){
typeof exports=="object"&&typeof module!="undefined"?module.exports=t():typeof define=="function"&&define.amd?define(t):n.moment=t()}
(this,
function(){
"use strict";
function i(){
return fo.apply(null,arguments)}
function sl(n){
fo=n}
function li(n){
return n instanceof Array||Object.prototype.toString.call(n)==="[object Array]"}
function fu(n){
return n instanceof Date||Object.prototype.toString.call(n)==="[object Date]"}
function eo(n,t){
for(var r=[],i=0;
i<n.length;
++i)r.push(t(n[i],i));
return r}
function b(n,t){
return Object.prototype.hasOwnProperty.call(n,t)}
function ai(n,t){
for(var i in t)b(t,i)&&(n[i]=t[i]);
return b(t,"toString")&&(n.toString=t.toString),b(t,"valueOf")&&(n.valueOf=t.valueOf),n}
function lt(n,t,i,r){
return ps(n,t,i,r,!0).utc()}
function hl(){
return{
empty:!1,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:!1,invalidMonth:null,invalidFormat:!1,userInvalidated:!1,iso:!1,parsedDateParts:[],meridiem:null}
}
function e(n){
return n._pf==null&&(n._pf=hl()),n._pf}
function sf(n){
if(n._isValid==null){
var t=e(n),i=oo.call(t.parsedDateParts,
function(n){
return n!=null}
);
n._isValid=!isNaN(n._d.getTime())&&t.overflow<0&&!t.empty&&!t.invalidMonth&&!t.invalidWeekday&&!t.nullInput&&!t.invalidFormat&&!t.userInvalidated&&(!t.meridiem||t.meridiem&&i);
n._strict&&(n._isValid=n._isValid&&t.charsLeftOver===0&&t.unusedTokens.length===0&&t.bigHour===undefined)}
return n._isValid}
function eu(n){
var t=lt(NaN);
return n!=null?ai(e(t),n):e(t).userInvalidated=!0,t}
function w(n){
return n===void 0}
function hf(n,t){
var u,i,r;
if(w(t._isAMomentObject)||(n._isAMomentObject=t._isAMomentObject),w(t._i)||(n._i=t._i),w(t._f)||(n._f=t._f),w(t._l)||(n._l=t._l),w(t._strict)||(n._strict=t._strict),w(t._tzm)||(n._tzm=t._tzm),w(t._isUTC)||(n._isUTC=t._isUTC),w(t._offset)||(n._offset=t._offset),w(t._pf)||(n._pf=e(t)),w(t._locale)||(n._locale=t._locale),ou.length>0)for(u in ou)i=ou[u],r=t[i],w(r)||(n[i]=r);
return n}
function ar(n){
hf(this,n);
this._d=new Date(n._d!=null?n._d.getTime():NaN);
su===!1&&(su=!0,i.updateOffset(this),su=!1)}
function ri(n){
return n instanceof ar||n!=null&&n._isAMomentObject!=null}
function k(n){
return n<0?Math.ceil(n):Math.floor(n)}
function o(n){
var t=+n,i=0;
return t!==0&&isFinite(t)&&(i=k(t)),i}
function so(n,t,i){
for(var f=Math.min(n.length,t.length),e=Math.abs(n.length-t.length),u=0,r=0;
r<f;
r++)(i&&n[r]!==t[r]||!i&&o(n[r])!==o(t[r]))&&u++;
return u+e}
function ho(n){
i.suppressDeprecationWarnings===!1&&typeof console!="undefined"&&console.warn&&console.warn("Deprecation warning: "+n)}
function g(n,t){
var r=!0;
return ai(function(){
return i.deprecationHandler!=null&&i.deprecationHandler(null,n),r&&(ho(n+"\nArguments: "+Array.prototype.slice.call(arguments).join(", ")+"\n"+(new Error).stack),r=!1),t.apply(this,arguments)}
,t)}
function lf(n,t){
i.deprecationHandler!=null&&i.deprecationHandler(n,t);
cf[n]||(ho(t),cf[n]=!0)}
function wt(n){
return n instanceof Function||Object.prototype.toString.call(n)==="[object Function]"}
function co(n){
return Object.prototype.toString.call(n)==="[object Object]"}
function cl(n){
var t;
for(var i in n)t=n[i],wt(t)?this[i]=t:this["_"+i]=t;
this._config=n;
this._ordinalParseLenient=new RegExp(this._ordinalParse.source+"|"+/\d{
1,2}
/.source)}
function af(n,t){
var r=ai({
}
,n);
for(var i in t)b(t,i)&&(co(n[i])&&co(t[i])?(r[i]={
}
,ai(r[i],n[i]),ai(r[i],t[i])):t[i]!=null?r[i]=t[i]:delete r[i]);
return r}
function vf(n){
n!=null&&this.set(n)}
function ao(n){
return n?n.toLowerCase().replace("_","-"):n}
function ll(n){
for(var r=0,i,t,f,u;
r<n.length;
){
for(u=ao(n[r]).split("-"),i=u.length,t=ao(n[r+1]),t=t?t.split("-"):null;
i>0;
){
if(f=vo(u.slice(0,i).join("-")),f)return f;
if(t&&t.length>=i&&so(u,t,!0)>=i-1)break;
i--}
r++}
return null}
function vo(n){
var t=null;
if(!a[n]&&typeof module!="undefined"&&module&&module.exports)try{
t=hu._abbr;
require("./locale/"+n);
tr(t)}
catch(i){
}
return a[n]}
function tr(n,t){
var i;
return n&&(i=w(t)?ui(n):yo(n,t),i&&(hu=i)),hu._abbr}
function yo(n,t){
return t!==null?(t.abbr=n,a[n]!=null?(lf("defineLocaleOverride","use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale"),t=af(a[n]._config,t)):t.parentLocale!=null&&(a[t.parentLocale]!=null?t=af(a[t.parentLocale]._config,t):lf("parentLocaleUndefined","specified parentLocale is not defined yet")),a[n]=new vf(t),tr(n),a[n]):(delete a[n],null)}
function al(n,t){
if(t!=null){
var i;
a[n]!=null&&(t=af(a[n]._config,t));
i=new vf(t);
i.parentLocale=a[n];
a[n]=i;
tr(n)}
else a[n]!=null&&(a[n].parentLocale!=null?a[n]=a[n].parentLocale:a[n]!=null&&delete a[n]);
return a[n]}
function ui(n){
var t;
if(n&&n._locale&&n._locale._abbr&&(n=n._locale._abbr),!n)return hu;
if(!li(n)){
if(t=vo(n),t)return t;
n=[n]}
return ll(n)}
function vl(){
return lo(a)}
function p(n,t){
var i=n.toLowerCase();
ir[i]=ir[i+"s"]=ir[t]=n}
function nt(n){
return typeof n=="string"?ir[n]||ir[n.toLowerCase()]:undefined}
function po(n){
var r={
}
,t;
for(var i in n)b(n,i)&&(t=nt(i),t&&(r[t]=n[i]));
return r}
function rr(n,t){
return function(r){
return r!=null?(wo(this,n,r),i.updateOffset(this,t),this):cu(this,n)}
}
function cu(n,t){
return n.isValid()?n._d["get"+(n._isUTC?"UTC":"")+t]():NaN}
function wo(n,t,i){
n.isValid()&&n._d["set"+(n._isUTC?"UTC":"")+t](i)}
function bo(n,t){
var i;
if(typeof n=="object")for(i in n)this.set(i,n[i]);
else if(n=nt(n),wt(this[n]))return this[n](t);
return this}
function bt(n,t,i){
var r=""+Math.abs(n),u=t-r.length,f=n>=0;
return(f?i?"+":"":"-")+Math.pow(10,Math.max(0,u)).toString().substr(1)+r}
function u(n,t,i,r){
var u=r;
typeof r=="string"&&(u=function(){
return this[r]()}
);
n&&(ur[n]=u);
t&&(ur[t[0]]=function(){
return bt(u.apply(this,arguments),t[1],t[2])}
);
i&&(ur[i]=function(){
return this.localeData().ordinal(u.apply(this,arguments),n)}
)}
function yl(n){
return n.match(/\[[\s\S]/)?n.replace(/^\[|\]$/g,""):n.replace(/\\/g,"")}
function pl(n){
for(var t=n.match(ko),i=0,r=t.length;
i<r;
i++)t[i]=ur[t[i]]?ur[t[i]]:yl(t[i]);
return function(i){
for(var f="",u=0;
u<r;
u++)f+=t[u]instanceof Function?t[u].call(i,n):t[u];
return f}
}
function pf(n,t){
return n.isValid()?(t=go(t,n.localeData()),yf[t]=yf[t]||pl(t),yf[t](n)):n.localeData().invalidDate()}
function go(n,t){
function r(n){
return t.longDateFormat(n)||n}
var i=5;
for(lu.lastIndex=0;
i>=0&&lu.test(n);
)n=n.replace(lu,r),lu.lastIndex=0,i-=1;
return n}
function r(n,t,i){
kf[n]=wt(t)?t:function(n){
return n&&i?i:t}
}
function bl(n,t){
return b(kf,n)?kf[n](t._strict,t._locale):new RegExp(kl(n))}
function kl(n){
return vi(n.replace("\\","").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,
function(n,t,i,r,u){
return t||i||r||u}
))}
function vi(n){
return n.replace(/[-\/\\^$*+?.()|[\]{
}
]/g,"\\$&")}
function h(n,t){
var i,r=t;
for(typeof n=="string"&&(n=[n]),typeof t=="number"&&(r=function(n,i){
i[t]=o(n)}
),i=0;
i<n.length;
i++)bu[n[i]]=r}
function yr(n,t){
h(n,
function(n,i,r,u){
r._w=r._w||{
}
;
t(n,r._w,r,u)}
)}
function dl(n,t,i){
t!=null&&b(bu,n)&&bu[n](t,i._a,i,n)}
function df(n,t){
return new Date(Date.UTC(n,t+1,0)).getUTCDate()}
function ta(n,t){
return li(this._months)?this._months[n.month()]:this._months[gf.test(t)?"format":"standalone"][n.month()]}
function ia(n,t){
return li(this._monthsShort)?this._monthsShort[n.month()]:this._monthsShort[gf.test(t)?"format":"standalone"][n.month()]}
function ra(n,t,i){
var u,r,e,f=n.toLocaleLowerCase();
if(!this._monthsParse)for(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[],u=0;
u<12;
++u)e=lt([2e3,u]),this._shortMonthsParse[u]=this.monthsShort(e,"").toLocaleLowerCase(),this._longMonthsParse[u]=this.months(e,"").toLocaleLowerCase();
return i?t==="MMM"?(r=v.call(this._shortMonthsParse,f),r!==-1?r:null):(r=v.call(this._longMonthsParse,f),r!==-1?r:null):t==="MMM"?(r=v.call(this._shortMonthsParse,f),r!==-1)?r:(r=v.call(this._longMonthsParse,f),r!==-1?r:null):(r=v.call(this._longMonthsParse,f),r!==-1)?r:(r=v.call(this._shortMonthsParse,f),r!==-1?r:null)}
function ua(n,t,i){
var r,u,f;
if(this._monthsParseExact)return ra.call(this,n,t,i);
for(this._monthsParse||(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[]),r=0;
r<12;
r++)if((u=lt([2e3,r]),i&&!this._longMonthsParse[r]&&(this._longMonthsParse[r]=new RegExp("^"+this.months(u,"").replace(".","")+"$","i"),this._shortMonthsParse[r]=new RegExp("^"+this.monthsShort(u,"").replace(".","")+"$","i")),i||this._monthsParse[r]||(f="^"+this.months(u,"")+"|^"+this.monthsShort(u,""),this._monthsParse[r]=new RegExp(f.replace(".",""),"i")),i&&t==="MMMM"&&this._longMonthsParse[r].test(n))||i&&t==="MMM"&&this._shortMonthsParse[r].test(n)||!i&&this._monthsParse[r].test(n))return r}
function es(n,t){
var i;
if(!n.isValid())return n;
if(typeof t=="string")if(/^\d+$/.test(t))t=o(t);
else if(t=n.localeData().monthsParse(t),typeof t!="number")return n;
return i=Math.min(n.date(),df(n.year(),t)),n._d["set"+(n._isUTC?"UTC":"")+"Month"](t,i),n}
function os(n){
return n!=null?(es(this,n),i.updateOffset(this,!0),this):cu(this,"Month")}
function fa(){
return df(this.year(),this.month())}
function ea(n){
return this._monthsParseExact?(b(this,"_monthsRegex")||cs.call(this),n?this._monthsShortStrictRegex:this._monthsShortRegex):this._monthsShortStrictRegex&&n?this._monthsShortStrictRegex:this._monthsShortRegex}
function oa(n){
return this._monthsParseExact?(b(this,"_monthsRegex")||cs.call(this),n?this._monthsStrictRegex:this._monthsRegex):this._monthsStrictRegex&&n?this._monthsStrictRegex:this._monthsRegex}
function cs(){
function f(n,t){
return t.length-n.length}
for(var i=[],r=[],t=[],u,n=0;
n<12;
n++)u=lt([2e3,n]),i.push(this.monthsShort(u,"")),r.push(this.months(u,"")),t.push(this.months(u,"")),t.push(this.monthsShort(u,""));
for(i.sort(f),r.sort(f),t.sort(f),n=0;
n<12;
n++)i[n]=vi(i[n]),r[n]=vi(r[n]),t[n]=vi(t[n]);
this._monthsRegex=new RegExp("^("+t.join("|")+")","i");
this._monthsShortRegex=this._monthsRegex;
this._monthsStrictRegex=new RegExp("^("+r.join("|")+")","i");
this._monthsShortStrictRegex=new RegExp("^("+i.join("|")+")","i")}
function ne(n){
var i,t=n._a;
return t&&e(n).overflow===-2&&(i=t[kt]<0||t[kt]>11?kt:t[at]<1||t[at]>df(t[tt],t[kt])?at:t[y]<0||t[y]>24||t[y]===24&&(t[it]!==0||t[dt]!==0||t[yi]!==0)?y:t[it]<0||t[it]>59?it:t[dt]<0||t[dt]>59?dt:t[yi]<0||t[yi]>999?yi:-1,e(n)._overflowDayOfYear&&(i<tt||i>at)&&(i=at),e(n)._overflowWeeks&&i===-1&&(i=gl),e(n)._overflowWeekday&&i===-1&&(i=na),e(n).overflow=i),n}
function ls(n){
var t,r,o=n._i,i=sa.exec(o)||ha.exec(o),s,f,u,h;
if(i){
for(e(n).iso=!0,t=0,r=ku.length;
t<r;
t++)if(ku[t][1].exec(i[1])){
f=ku[t][0];
s=ku[t][2]!==!1;
break}
if(f==null){
n._isValid=!1;
return}
if(i[3]){
for(t=0,r=te.length;
t<r;
t++)if(te[t][1].exec(i[3])){
u=(i[2]||" ")+te[t][0];
break}
if(u==null){
n._isValid=!1;
return}
}
if(!s&&u!=null){
n._isValid=!1;
return}
if(i[4])if(ca.exec(i[4]))h="Z";
else{
n._isValid=!1;
return}
n._f=f+(u||"")+(h||"");
ue(n)}
else n._isValid=!1}
function aa(n){
var t=la.exec(n._i);
if(t!==null){
n._d=new Date(+t[1]);
return}
ls(n);
n._isValid===!1&&(delete n._isValid,i.createFromInputFallback(n))}
function va(n,t,i,r,u,f,e){
var o=new Date(n,t,i,r,u,f,e);
return n<100&&n>=0&&isFinite(o.getFullYear())&&o.setFullYear(n),o}
function du(n){
var t=new Date(Date.UTC.apply(null,arguments));
return n<100&&n>=0&&isFinite(t.getUTCFullYear())&&t.setUTCFullYear(n),t}
function pr(n){
return as(n)?366:365}
function as(n){
return n%4==0&&n%100!=0||n%400==0}
function ya(){
return as(this.year())}
function gu(n,t,i){
var r=7+t-i,u=(7+du(n,0,r).getUTCDay()-t)%7;
return-u+r-1}
function vs(n,t,i,r,u){
var s=(7+i-r)%7,h=gu(n,r,u),f=1+7*(t-1)+s+h,e,o;
return f<=0?(e=n-1,o=pr(e)+f):f>pr(n)?(e=n+1,o=f-pr(n)):(e=n,o=f),{
year:e,dayOfYear:o}
}
function wr(n,t,i){
var e=gu(n.year(),t,i),r=Math.floor((n.dayOfYear()-e-1)/7)+1,f,u;
return r<1?(u=n.year()-1,f=r+pi(u,t,i)):r>pi(n.year(),t,i)?(f=r-pi(n.year(),t,i),u=n.year()+1):(u=n.year(),f=r),{
week:f,year:u}
}
function pi(n,t,i){
var r=gu(n,t,i),u=gu(n+1,t,i);
return(pr(n)-r+u)/7}
function fr(n,t,i){
return n!=null?n:t!=null?t:i}
function pa(n){
var t=new Date(i.now());
return n._useUTC?[t.getUTCFullYear(),t.getUTCMonth(),t.getUTCDate()]:[t.getFullYear(),t.getMonth(),t.getDate()]}
function re(n){
var t,i,r=[],u,f;
if(!n._d){
for(u=pa(n),n._w&&n._a[at]==null&&n._a[kt]==null&&wa(n),n._dayOfYear&&(f=fr(n._a[tt],u[tt]),n._dayOfYear>pr(f)&&(e(n)._overflowDayOfYear=!0),i=du(f,0,n._dayOfYear),n._a[kt]=i.getUTCMonth(),n._a[at]=i.getUTCDate()),t=0;
t<3&&n._a[t]==null;
++t)n._a[t]=r[t]=u[t];
for(;
t<7;
t++)n._a[t]=r[t]=n._a[t]==null?t===2?1:0:n._a[t];
n._a[y]===24&&n._a[it]===0&&n._a[dt]===0&&n._a[yi]===0&&(n._nextDay=!0,n._a[y]=0);
n._d=(n._useUTC?du:va).apply(null,r);
n._tzm!=null&&n._d.setUTCMinutes(n._d.getUTCMinutes()-n._tzm);
n._nextDay&&(n._a[y]=24)}
}
function wa(n){
var t,o,u,i,r,f,h,s;
t=n._w;
t.GG!=null||t.W!=null||t.E!=null?(r=1,f=4,o=fr(t.GG,n._a[tt],wr(l(),1,4).year),u=fr(t.W,1),i=fr(t.E,1),(i<1||i>7)&&(s=!0)):(r=n._locale._week.dow,f=n._locale._week.doy,o=fr(t.gg,n._a[tt],wr(l(),r,f).year),u=fr(t.w,1),t.d!=null?(i=t.d,(i<0||i>6)&&(s=!0)):t.e!=null?(i=t.e+r,(t.e<0||t.e>6)&&(s=!0)):i=r);
u<1||u>pi(o,r,f)?e(n)._overflowWeeks=!0:s!=null?e(n)._overflowWeekday=!0:(h=vs(o,u,i,r,f),n._a[tt]=h.year,n._dayOfYear=h.dayOfYear)}
function ue(n){
if(n._f===i.ISO_8601){
ls(n);
return}
n._a=[];
e(n).empty=!0;
for(var t=""+n._i,r,u,s,c=t.length,h=0,o=go(n._f,n._locale).match(ko)||[],f=0;
f<o.length;
f++)u=o[f],r=(t.match(bl(u,n))||[])[0],r&&(s=t.substr(0,t.indexOf(r)),s.length>0&&e(n).unusedInput.push(s),t=t.slice(t.indexOf(r)+r.length),h+=r.length),ur[u]?(r?e(n).empty=!1:e(n).unusedTokens.push(u),dl(u,r,n)):n._strict&&!r&&e(n).unusedTokens.push(u);
e(n).charsLeftOver=c-h;
t.length>0&&e(n).unusedInput.push(t);
e(n).bigHour===!0&&n._a[y]<=12&&n._a[y]>0&&(e(n).bigHour=undefined);
e(n).parsedDateParts=n._a.slice(0);
e(n).meridiem=n._meridiem;
n._a[y]=ba(n._locale,n._a[y],n._meridiem);
re(n);
ne(n)}
function ba(n,t,i){
var r;
return i==null?t:n.meridiemHour!=null?n.meridiemHour(t,i):n.isPM!=null?(r=n.isPM(i),r&&t<12&&(t+=12),r||t!==12||(t=0),t):t}
function ka(n){
var t,f,u,r,i;
if(n._f.length===0){
e(n).invalidFormat=!0;
n._d=new Date(NaN);
return}
for(r=0;
r<n._f.length;
r++)(i=0,t=hf({
}
,n),n._useUTC!=null&&(t._useUTC=n._useUTC),t._f=n._f[r],ue(t),sf(t))&&(i+=e(t).charsLeftOver,i+=e(t).unusedTokens.length*10,e(t).score=i,(u==null||i<u)&&(u=i,f=t));
ai(n,f||t)}
function da(n){
if(!n._d){
var t=po(n._i);
n._a=eo([t.year,t.month,t.day||t.date,t.hour,t.minute,t.second,t.millisecond],
function(n){
return n&&parseInt(n,10)}
);
re(n)}
}
function ga(n){
var t=new ar(ne(ys(n)));
return t._nextDay&&(t.add(1,"d"),t._nextDay=undefined),t}
function ys(n){
var t=n._i,i=n._f;
return(n._locale=n._locale||ui(n._l),t===null||i===undefined&&t==="")?eu({
nullInput:!0}
):(typeof t=="string"&&(n._i=t=n._locale.preparse(t)),ri(t))?new ar(ne(t)):(li(i)?ka(n):i?ue(n):fu(t)?n._d=t:nv(n),sf(n)||(n._d=null),n)}
function nv(n){
var t=n._i;
t===undefined?n._d=new Date(i.now()):fu(t)?n._d=new Date(t.valueOf()):typeof t=="string"?aa(n):li(t)?(n._a=eo(t.slice(0),
function(n){
return parseInt(n,10)}
),re(n)):typeof t=="object"?da(n):typeof t=="number"?n._d=new Date(t):i.createFromInputFallback(n)}
function ps(n,t,i,r,u){
var f={
}
;
return typeof i=="boolean"&&(r=i,i=undefined),f._isAMomentObject=!0,f._useUTC=f._isUTC=u,f._l=i,f._i=n,f._f=t,f._strict=r,ga(f)}
function l(n,t,i,r){
return ps(n,t,i,r,!1)}
function ks(n,t){
var r,i;
if(t.length===1&&li(t[0])&&(t=t[0]),!t.length)return l();
for(r=t[0],i=1;
i<t.length;
++i)(!t[i].isValid()||t[i][n](r))&&(r=t[i]);
return r}
function tv(){
var n=[].slice.call(arguments,0);
return ks("isBefore",n)}
function iv(){
var n=[].slice.call(arguments,0);
return ks("isAfter",n)}
function nf(n){
var t=po(n),i=t.year||0,r=t.quarter||0,u=t.month||0,f=t.week||0,e=t.day||0,o=t.hour||0,s=t.minute||0,h=t.second||0,c=t.millisecond||0;
this._milliseconds=+c+h*1e3+s*6e4+o*36e5;
this._days=+e+f*7;
this._months=+u+r*3+i*12;
this._data={
}
;
this._locale=ui();
this._bubble()}
function fe(n){
return n instanceof nf}
function gs(n,t){
u(n,0,0,
function(){
var n=this.utcOffset(),i="+";
return n<0&&(n=-n,i="-"),i+bt(~~(n/60),2)+t+bt(~~n%60,2)}
)}
function ee(n,t){
var r=(t||"").match(n)||[],f=r[r.length-1]||[],i=(f+"").match(nh)||["-",0,0],u=+(i[1]*60)+o(i[2]);
return i[0]==="+"?u:-u}
function oe(n,t){
var r,u;
return t._isUTC?(r=t.clone(),u=(ri(n)||fu(n)?n.valueOf():l(n).valueOf())-r.valueOf(),r._d.setTime(r._d.valueOf()+u),i.updateOffset(r,!1),r):l(n).local()}
function se(n){
return-Math.round(n._d.getTimezoneOffset()/15)*15}
function rv(n,t){
var r=this._offset||0,u;
return this.isValid()?n!=null?(typeof n=="string"?n=ee(wu,n):Math.abs(n)<16&&(n=n*60),!this._isUTC&&t&&(u=se(this)),this._offset=n,this._isUTC=!0,u!=null&&this.add(u,"m"),r!==n&&(!t||this._changeInProgress?oh(this,fi(n-r,"m"),1,!1):this._changeInProgress||(this._changeInProgress=!0,i.updateOffset(this,!0),this._changeInProgress=null)),this):this._isUTC?r:se(this):n!=null?this:NaN}
function uv(n,t){
return n!=null?(typeof n!="string"&&(n=-n),this.utcOffset(n,t),this):-this.utcOffset()}
function fv(n){
return this.utcOffset(0,n)}
function ev(n){
return this._isUTC&&(this.utcOffset(0,n),this._isUTC=!1,n&&this.subtract(se(this),"m")),this}
function ov(){
return this._tzm?this.utcOffset(this._tzm):typeof this._i=="string"&&this.utcOffset(ee(wl,this._i)),this}
function sv(n){
return this.isValid()?(n=n?l(n).utcOffset():0,(this.utcOffset()-n)%60==0):!1}
function hv(){
return this.utcOffset()>this.clone().month(0).utcOffset()||this.utcOffset()>this.clone().month(5).utcOffset()}
function cv(){
var n,t;
return w(this._isDSTShifted)?(n={
}
,hf(n,this),n=ys(n),n._a?(t=n._isUTC?lt(n._a):l(n._a),this._isDSTShifted=this.isValid()&&so(n._a,t.toArray())>0):this._isDSTShifted=!1,this._isDSTShifted):this._isDSTShifted}
function lv(){
return this.isValid()?!this._isUTC:!1}
function av(){
return this.isValid()?this._isUTC:!1}
function th(){
return this.isValid()?this._isUTC&&this._offset===0:!1}
function fi(n,t){
var i=n,r=null,u,f,e;
return fe(n)?i={
ms:n._milliseconds,d:n._days,M:n._months}
:typeof n=="number"?(i={
}
,t?i[t]=n:i.milliseconds=n):(r=ih.exec(n))?(u=r[1]==="-"?-1:1,i={
y:0,d:o(r[at])*u,h:o(r[y])*u,m:o(r[it])*u,s:o(r[dt])*u,ms:o(r[yi])*u}
):(r=rh.exec(n))?(u=r[1]==="-"?-1:1,i={
y:wi(r[2],u),M:wi(r[3],u),w:wi(r[4],u),d:wi(r[5],u),h:wi(r[6],u),m:wi(r[7],u),s:wi(r[8],u)}
):i==null?i={
}
:typeof i=="object"&&("from"in i||"to"in i)&&(e=vv(l(i.from),l(i.to)),i={
}
,i.ms=e.milliseconds,i.M=e.months),f=new nf(i),fe(n)&&b(n,"_locale")&&(f._locale=n._locale),f}
function wi(n,t){
var i=n&&parseFloat(n.replace(",","."));
return(isNaN(i)?0:i)*t}
function uh(n,t){
var i={
milliseconds:0,months:0}
;
return i.months=t.month()-n.month()+(t.year()-n.year())*12,n.clone().add(i.months,"M").isAfter(t)&&--i.months,i.milliseconds=+t-+n.clone().add(i.months,"M"),i}
function vv(n,t){
var i;
return(n.isValid()&&t.isValid())?(t=oe(t,n),n.isBefore(t)?i=uh(n,t):(i=uh(t,n),i.milliseconds=-i.milliseconds,i.months=-i.months),i):{
milliseconds:0,months:0}
}
function fh(n){
return n<0?Math.round(-1*n)*-1:Math.round(n)}
function eh(n,t){
return function(i,r){
var u,f;
return r===null||isNaN(+r)||(lf(t,"moment()."+t+"(period, number) is deprecated. Please use moment()."+t+"(number, period)."),f=i,i=r,r=f),i=typeof i=="string"?+i:i,u=fi(i,r),oh(this,u,n),this}
}
function oh(n,t,r,u){
var o=t._milliseconds,f=fh(t._days),e=fh(t._months);
n.isValid()&&(u=u==null?!0:u,o&&n._d.setTime(n._d.valueOf()+o*r),f&&wo(n,"Date",cu(n,"Date")+f*r),e&&es(n,cu(n,"Month")+e*r),u&&i.updateOffset(n,f||e))}
function yv(n,t){
var u=n||l(),f=oe(u,this).startOf("day"),i=this.diff(f,"days",!0),r=i<-6?"sameElse":i<-1?"lastWeek":i<0?"lastDay":i<1?"sameDay":i<2?"nextDay":i<7?"nextWeek":"sameElse",e=t&&(wt(t[r])?t[r]():t[r]);
return this.format(e||this.localeData().calendar(r,this,l(u)))}
function pv(){
return new ar(this)}
function wv(n,t){
var i=ri(n)?n:l(n);
return(this.isValid()&&i.isValid())?(t=nt(w(t)?"millisecond":t),t==="millisecond"?this.valueOf()>i.valueOf():i.valueOf()<this.clone().startOf(t).valueOf()):!1}
function bv(n,t){
var i=ri(n)?n:l(n);
return(this.isValid()&&i.isValid())?(t=nt(w(t)?"millisecond":t),t==="millisecond"?this.valueOf()<i.valueOf():this.clone().endOf(t).valueOf()<i.valueOf()):!1}
function kv(n,t,i,r){
return r=r||"()",(r[0]==="("?this.isAfter(n,i):!this.isBefore(n,i))&&(r[1]===")"?this.isBefore(t,i):!this.isAfter(t,i))}
function dv(n,t){
var i=ri(n)?n:l(n),r;
return(this.isValid()&&i.isValid())?(t=nt(t||"millisecond"),t==="millisecond"?this.valueOf()===i.valueOf():(r=i.valueOf(),this.clone().startOf(t).valueOf()<=r&&r<=this.clone().endOf(t).valueOf())):!1}
function gv(n,t){
return this.isSame(n,t)||this.isAfter(n,t)}
function ny(n,t){
return this.isSame(n,t)||this.isBefore(n,t)}
function ty(n,t,i){
var f,e,u,r;
return this.isValid()?(f=oe(n,this),!f.isValid())?NaN:(e=(f.utcOffset()-this.utcOffset())*6e4,t=nt(t),t==="year"||t==="month"||t==="quarter"?(r=iy(this,f),t==="quarter"?r=r/3:t==="year"&&(r=r/12)):(u=this-f,r=t==="second"?u/1e3:t==="minute"?u/6e4:t==="hour"?u/36e5:t==="day"?(u-e)/864e5:t==="week"?(u-e)/6048e5:u),i?r:k(r)):NaN}
function iy(n,t){
var r=(t.year()-n.year())*12+(t.month()-n.month()),i=n.clone().add(r,"months"),u,f;
return t-i<0?(u=n.clone().add(r-1,"months"),f=(t-i)/(i-u)):(u=n.clone().add(r+1,"months"),f=(t-i)/(u-i)),-(r+f)||0}
function ry(){
return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")}
function uy(){
var n=this.clone().utc();
return 0<n.year()&&n.year()<=9999?wt(Date.prototype.toISOString)?this.toDate().toISOString():pf(n,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"):pf(n,"YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]")}
function fy(n){
n||(n=this.isUtc()?i.defaultFormatUtc:i.defaultFormat);
var t=pf(this,n);
return this.localeData().postformat(t)}
function ey(n,t){
return this.isValid()&&(ri(n)&&n.isValid()||l(n).isValid())?fi({
to:this,from:n}
).locale(this.locale()).humanize(!t):this.localeData().invalidDate()}
function oy(n){
return this.from(l(),n)}
function sy(n,t){
return this.isValid()&&(ri(n)&&n.isValid()||l(n).isValid())?fi({
from:this,to:n}
).locale(this.locale()).humanize(!t):this.localeData().invalidDate()}
function hy(n){
return this.to(l(),n)}
function ch(n){
var t;
return n===undefined?this._locale._abbr:(t=ui(n),t!=null&&(this._locale=t),this)}
function lh(){
return this._locale}
function cy(n){
n=nt(n);
switch(n){
case"year":this.month(0);
case"quarter":case"month":this.date(1);
case"week":case"isoWeek":case"day":case"date":this.hours(0);
case"hour":this.minutes(0);
case"minute":this.seconds(0);
case"second":this.milliseconds(0)}
return n==="week"&&this.weekday(0),n==="isoWeek"&&this.isoWeekday(1),n==="quarter"&&this.month(Math.floor(this.month()/3)*3),this}
function ly(n){
return(n=nt(n),n===undefined||n==="millisecond")?this:(n==="date"&&(n="day"),this.startOf(n).add(1,n==="isoWeek"?"week":n).subtract(1,"ms"))}
function ay(){
return this._d.valueOf()-(this._offset||0)*6e4}
function vy(){
return Math.floor(this.valueOf()/1e3)}
function yy(){
return this._offset?new Date(this.valueOf()):this._d}
function py(){
var n=this;
return[n.year(),n.month(),n.date(),n.hour(),n.minute(),n.second(),n.millisecond()]}
function wy(){
var n=this;
return{
years:n.year(),months:n.month(),date:n.date(),hours:n.hours(),minutes:n.minutes(),seconds:n.seconds(),milliseconds:n.milliseconds()}
}
function by(){
return this.isValid()?this.toISOString():null}
function ky(){
return sf(this)}
function dy(){
return ai({
}
,e(this))}
function gy(){
return e(this).overflow}
function np(){
return{
input:this._i,format:this._f,locale:this._locale,isUTC:this._isUTC,strict:this._strict}
}
function tf(n,t){
u(0,[n,n.length],0,t)}
function tp(n){
return ah.call(this,n,this.week(),this.weekday(),this.localeData()._week.dow,this.localeData()._week.doy)}
function ip(n){
return ah.call(this,n,this.isoWeek(),this.isoWeekday(),1,4)}
function rp(){
return pi(this.year(),1,4)}
function up(){
var n=this.localeData()._week;
return pi(this.year(),n.dow,n.doy)}
function ah(n,t,i,r,u){
var f;
return n==null?wr(this,r,u).year:(f=pi(n,r,u),t>f&&(t=f),fp.call(this,n,t,i,r,u))}
function fp(n,t,i,r,u){
var e=vs(n,t,i,r,u),f=du(e.year,0,e.dayOfYear);
return this.year(f.getUTCFullYear()),this.month(f.getUTCMonth()),this.date(f.getUTCDate()),this}
function ep(n){
return n==null?Math.ceil((this.month()+1)/3):this.month((n-1)*3+this.month()%3)}
function op(n){
return wr(n,this._week.dow,this._week.doy).week}
function sp(){
return this._week.dow}
function hp(){
return this._week.doy}
function cp(n){
var t=this.localeData().week(this);
return n==null?t:this.add((n-t)*7,"d")}
function lp(n){
var t=wr(this,1,4).week;
return n==null?t:this.add((n-t)*7,"d")}
function ap(n,t){
return typeof n!="string"?n:isNaN(n)?(n=t.weekdaysParse(n),typeof n=="number")?n:null:parseInt(n,10)}
function vp(n,t){
return li(this._weekdays)?this._weekdays[n.day()]:this._weekdays[this._weekdays.isFormat.test(t)?"format":"standalone"][n.day()]}
function yp(n){
return this._weekdaysShort[n.day()]}
function pp(n){
return this._weekdaysMin[n.day()]}
function wp(n,t,i){
var f,r,e,u=n.toLocaleLowerCase();
if(!this._weekdaysParse)for(this._weekdaysParse=[],this._shortWeekdaysParse=[],this._minWeekdaysParse=[],f=0;
f<7;
++f)e=lt([2e3,1]).day(f),this._minWeekdaysParse[f]=this.weekdaysMin(e,"").toLocaleLowerCase(),this._shortWeekdaysParse[f]=this.weekdaysShort(e,"").toLocaleLowerCase(),this._weekdaysParse[f]=this.weekdays(e,"").toLocaleLowerCase();
return i?t==="dddd"?(r=v.call(this._weekdaysParse,u),r!==-1?r:null):t==="ddd"?(r=v.call(this._shortWeekdaysParse,u),r!==-1?r:null):(r=v.call(this._minWeekdaysParse,u),r!==-1?r:null):t==="dddd"?(r=v.call(this._weekdaysParse,u),r!==-1)?r:(r=v.call(this._shortWeekdaysParse,u),r!==-1)?r:(r=v.call(this._minWeekdaysParse,u),r!==-1?r:null):t==="ddd"?(r=v.call(this._shortWeekdaysParse,u),r!==-1)?r:(r=v.call(this._weekdaysParse,u),r!==-1)?r:(r=v.call(this._minWeekdaysParse,u),r!==-1?r:null):(r=v.call(this._minWeekdaysParse,u),r!==-1)?r:(r=v.call(this._weekdaysParse,u),r!==-1)?r:(r=v.call(this._shortWeekdaysParse,u),r!==-1?r:null)}
function bp(n,t,i){
var r,u,f;
if(this._weekdaysParseExact)return wp.call(this,n,t,i);
for(this._weekdaysParse||(this._weekdaysParse=[],this._minWeekdaysParse=[],this._shortWeekdaysParse=[],this._fullWeekdaysParse=[]),r=0;
r<7;
r++)if((u=lt([2e3,1]).day(r),i&&!this._fullWeekdaysParse[r]&&(this._fullWeekdaysParse[r]=new RegExp("^"+this.weekdays(u,"").replace(".",".?")+"$","i"),this._shortWeekdaysParse[r]=new RegExp("^"+this.weekdaysShort(u,"").replace(".",".?")+"$","i"),this._minWeekdaysParse[r]=new RegExp("^"+this.weekdaysMin(u,"").replace(".",".?")+"$","i")),this._weekdaysParse[r]||(f="^"+this.weekdays(u,"")+"|^"+this.weekdaysShort(u,"")+"|^"+this.weekdaysMin(u,""),this._weekdaysParse[r]=new RegExp(f.replace(".",""),"i")),i&&t==="dddd"&&this._fullWeekdaysParse[r].test(n))||i&&t==="ddd"&&this._shortWeekdaysParse[r].test(n)||i&&t==="dd"&&this._minWeekdaysParse[r].test(n)||!i&&this._weekdaysParse[r].test(n))return r}
function kp(n){
if(!this.isValid())return n!=null?this:NaN;
var t=this._isUTC?this._d.getUTCDay():this._d.getDay();
return n!=null?(n=ap(n,this.localeData()),this.add(n-t,"d")):t}
function dp(n){
if(!this.isValid())return n!=null?this:NaN;
var t=(this.day()+7-this.localeData()._week.dow)%7;
return n==null?t:this.add(n-t,"d")}
function gp(n){
return this.isValid()?n==null?this.day()||7:this.day(this.day()%7?n:n-7):n!=null?this:NaN}
function nw(n){
return this._weekdaysParseExact?(b(this,"_weekdaysRegex")||le.call(this),n?this._weekdaysStrictRegex:this._weekdaysRegex):this._weekdaysStrictRegex&&n?this._weekdaysStrictRegex:this._weekdaysRegex}
function tw(n){
return this._weekdaysParseExact?(b(this,"_weekdaysRegex")||le.call(this),n?this._weekdaysShortStrictRegex:this._weekdaysShortRegex):this._weekdaysShortStrictRegex&&n?this._weekdaysShortStrictRegex:this._weekdaysShortRegex}
function iw(n){
return this._weekdaysParseExact?(b(this,"_weekdaysRegex")||le.call(this),n?this._weekdaysMinStrictRegex:this._weekdaysMinRegex):this._weekdaysMinStrictRegex&&n?this._weekdaysMinStrictRegex:this._weekdaysMinRegex}
function le(){
function u(n,t){
return t.length-n.length}
for(var e=[],i=[],r=[],t=[],f,o,s,h,n=0;
n<7;
n++)f=lt([2e3,1]).day(n),o=this.weekdaysMin(f,""),s=this.weekdaysShort(f,""),h=this.weekdays(f,""),e.push(o),i.push(s),r.push(h),t.push(o),t.push(s),t.push(h);
for(e.sort(u),i.sort(u),r.sort(u),t.sort(u),n=0;
n<7;
n++)i[n]=vi(i[n]),r[n]=vi(r[n]),t[n]=vi(t[n]);
this._weekdaysRegex=new RegExp("^("+t.join("|")+")","i");
this._weekdaysShortRegex=this._weekdaysRegex;
this._weekdaysMinRegex=this._weekdaysRegex;
this._weekdaysStrictRegex=new RegExp("^("+r.join("|")+")","i");
this._weekdaysShortStrictRegex=new RegExp("^("+i.join("|")+")","i");
this._weekdaysMinStrictRegex=new RegExp("^("+e.join("|")+")","i")}
function rw(n){
var t=Math.round((this.clone().startOf("day")-this.clone().startOf("year"))/864e5)+1;
return n==null?t:this.add(n-t,"d")}
function ae(){
return this.hours()%12||12}
function uw(){
return this.hours()||24}
function gh(n,t){
u(n,0,0,
function(){
return this.localeData().meridiem(this.hours(),this.minutes(),t)}
)}
function nc(n,t){
return t._meridiemParse}
function fw(n){
return(n+"").toLowerCase().charAt(0)==="p"}
function ew(n,t,i){
return n>11?i?"pm":"PM":i?"am":"AM"}
function ow(n,t){
t[yi]=o(("0."+n)*1e3)}
function sw(){
return this._isUTC?"UTC":""}
function hw(){
return this._isUTC?"Coordinated Universal Time":""}
function cw(n){
return l(n*1e3)}
function lw(){
return l.apply(null,arguments).parseZone()}
function aw(n,t,i){
var r=this._calendar[n];
return wt(r)?r.call(t,i):r}
function vw(n){
var t=this._longDateFormat[n],i=this._longDateFormat[n.toUpperCase()];
return t||!i?t:(this._longDateFormat[n]=i.replace(/MMMM|MM|DD|dddd/g,
function(n){
return n.slice(1)}
),this._longDateFormat[n])}
function yw(){
return this._invalidDate}
function pw(n){
return this._ordinal.replace("%d",n)}
function lc(n){
return n}
function ww(n,t,i,r){
var u=this._relativeTime[i];
return wt(u)?u(n,t,i,r):u.replace(/%d/i,n)}
function bw(n,t){
var i=this._relativeTime[n>0?"future":"past"];
return wt(i)?i(t):i.replace(/%s/i,t)}
function rf(n,t,i,r){
var u=ui(),f=lt().set(r,t);
return u[i](f,n)}
function vc(n,t,i){
if(typeof n=="number"&&(t=n,n=undefined),n=n||"",t!=null)return rf(n,t,i,"month");
for(var u=[],r=0;
r<12;
r++)u[r]=rf(n,r,i,"month");
return u}
function ye(n,t,i,r){
var o,f,u,e;
if(typeof n=="boolean"?(typeof t=="number"&&(i=t,t=undefined),t=t||""):(t=n,i=t,n=!1,typeof t=="number"&&(i=t,t=undefined),t=t||""),o=ui(),f=n?o._week.dow:0,i!=null)return rf(t,(i+f)%7,r,"day");
for(e=[],u=0;
u<7;
u++)e[u]=rf(t,(u+f)%7,r,"day");
return e}
function kw(n,t){
return vc(n,t,"months")}
function dw(n,t){
return vc(n,t,"monthsShort")}
function gw(n,t,i){
return ye(n,t,i,"weekdays")}
function nb(n,t,i){
return ye(n,t,i,"weekdaysShort")}
function tb(n,t,i){
return ye(n,t,i,"weekdaysMin")}
function ib(){
var n=this._data;
return this._milliseconds=vt(this._milliseconds),this._days=vt(this._days),this._months=vt(this._months),n.milliseconds=vt(n.milliseconds),n.seconds=vt(n.seconds),n.minutes=vt(n.minutes),n.hours=vt(n.hours),n.months=vt(n.months),n.years=vt(n.years),this}
function yc(n,t,i,r){
var u=fi(t,i);
return n._milliseconds+=r*u._milliseconds,n._days+=r*u._days,n._months+=r*u._months,n._bubble()}
function rb(n,t){
return yc(this,n,t,1)}
function ub(n,t){
return yc(this,n,t,-1)}
function pc(n){
return n<0?Math.floor(n):Math.ceil(n)}
function fb(){
var r=this._milliseconds,n=this._days,t=this._months,i=this._data,u,f,e,s,o;
return r>=0&&n>=0&&t>=0||r<=0&&n<=0&&t<=0||(r+=pc(pe(t)+n)*864e5,n=0,t=0),i.milliseconds=r%1e3,u=k(r/1e3),i.seconds=u%60,f=k(u/60),i.minutes=f%60,e=k(f/60),i.hours=e%24,n+=k(e/24),o=k(wc(n)),t+=o,n-=pc(pe(o)),s=k(t/12),t%=12,i.days=n,i.months=t,i.years=s,this}
function wc(n){
return n*4800/146097}
function pe(n){
return n*146097/4800}
function eb(n){
var t,r,i=this._milliseconds;
if(n=nt(n),n==="month"||n==="year")return t=this._days+i/864e5,r=this._months+wc(t),n==="month"?r:r/12;
t=this._days+Math.round(pe(this._months));
switch(n){
case"week":return t/7+i/6048e5;
case"day":return t+i/864e5;
case"hour":return t*24+i/36e5;
case"minute":return t*1440+i/6e4;
case"second":return t*86400+i/1e3;
case"millisecond":return Math.floor(t*864e5)+i;
default:throw new Error("Unknown unit "+n);
}
}
function ob(){
return this._milliseconds+this._days*864e5+this._months%12*2592e6+o(this._months/12)*31536e6}
function oi(n){
return function(){
return this.as(n)}
}
function wb(n){
return n=nt(n),this[n+"s"]()}
function bi(n){
return function(){
return this._data[n]}
}
function rk(){
return k(this.days()/7)}
function uk(n,t,i,r,u){
return u.relativeTime(t||1,!!i,n,r)}
function fk(n,t,i){
var r=fi(n).abs(),h=ki(r.as("s")),f=ki(r.as("m")),e=ki(r.as("h")),o=ki(r.as("d")),s=ki(r.as("M")),c=ki(r.as("y")),u=h<gt.s&&["s",h]||f<=1&&["m"]||f<gt.m&&["mm",f]||e<=1&&["h"]||e<gt.h&&["hh",e]||o<=1&&["d"]||o<gt.d&&["dd",o]||s<=1&&["M"]||s<gt.M&&["MM",s]||c<=1&&["y"]||["yy",c];
return u[2]=t,u[3]=+n>0,u[4]=i,uk.apply(null,u)}
function ek(n,t){
return gt[n]===undefined?!1:t===undefined?gt[n]:(gt[n]=t,!0)}
function ok(n){
var t=this.localeData(),i=fk(this,!n,t);
return n&&(i=t.pastFuture(+this,i)),t.postformat(i)}
function ff(){
var t=uf(this._milliseconds)/1e3,a=uf(this._days),i=uf(this._months),n,e,o;
n=k(t/60);
e=k(n/60);
t%=60;
n%=60;
o=k(i/12);
i%=12;
var s=o,h=i,c=a,r=e,u=n,f=t,l=this.asSeconds();
return l?(l<0?"-":"")+"P"+(s?s+"Y":"")+(h?h+"M":"")+(c?c+"D":"")+(r||u||f?"T":"")+(r?r+"H":"")+(u?u+"M":"")+(f?f+"S":""):"P0D"}
function vk(n,t){
var i=n.split("_");
return t%10==1&&t%100!=11?i[0]:t%10>=2&&t%10<=4&&(t%100<10||t%100>=20)?i[1]:i[2]}
function di(n,t,i){
var r={
mm:t?"хвіліна_хвіліны_хвілін":"хвіліну_хвіліны_хвілін",hh:t?"гадзіна_гадзіны_гадзін":"гадзіну_гадзіны_гадзін",dd:"дзень_дні_дзён",MM:"месяц_месяцы_месяцаў",yy:"год_гады_гадоў"}
;
return i==="m"?t?"хвіліна":"хвіліну":i==="h"?t?"гадзіна":"гадзіну":n+" "+vk(r[i],+n)}
function be(n,t,i){
return n+" "+dk({
mm:"munutenn",MM:"miz",dd:"devezh"}
[i],n)}
function kk(n){
switch(dc(n)){
case 1:case 3:case 4:case 5:case 9:return n+" bloaz";
default:return n+" vloaz"}
}
function dc(n){
return n>9?dc(n%10):n}
function dk(n,t){
return t===2?gk(n):n}
function gk(n){
var t={
m:"v",b:"v",d:"z"}
;
return t[n.charAt(0)]===undefined?n:t[n.charAt(0)]+n.substring(1)}
function gi(n,t,i){
var r=n+" ";
switch(i){
case"m":return t?"jedna minuta":"jedne minute";
case"mm":return r+(n===1?"minuta":n===2||n===3||n===4?"minute":"minuta");
case"h":return t?"jedan sat":"jednog sata";
case"hh":return r+(n===1?"sat":n===2||n===3||n===4?"sata":"sati");
case"dd":return r+(n===1?"dan":"dana");
case"MM":return r+(n===1?"mjesec":n===2||n===3||n===4?"mjeseca":"mjeseci");
case"yy":return r+(n===1?"godina":n===2||n===3||n===4?"godine":"godina")}
}
function br(n){
return n>1&&n<5&&~~(n/10)!=1}
function ut(n,t,i,r){
var u=n+" ";
switch(i){
case"s":return t||r?"pár sekund":"pár sekundami";
case"m":return t?"minuta":r?"minutu":"minutou";
case"mm":return t||r?u+(br(n)?"minuty":"minut"):u+"minutami";
case"h":return t?"hodina":r?"hodinu":"hodinou";
case"hh":return t||r?u+(br(n)?"hodiny":"hodin"):u+"hodinami";
case"d":return t||r?"den":"dnem";
case"dd":return t||r?u+(br(n)?"dny":"dní"):u+"dny";
case"M":return t||r?"měsíc":"měsícem";
case"MM":return t||r?u+(br(n)?"měsíce":"měsíců"):u+"měsíci";
case"y":return t||r?"rok":"rokem";
case"yy":return t||r?u+(br(n)?"roky":"let"):u+"lety"}
}
function si(n,t,i){
var r={
m:["eine Minute","einer Minute"],h:["eine Stunde","einer Stunde"],d:["ein Tag","einem Tag"],dd:[n+" Tage",n+" Tagen"],M:["ein Monat","einem Monat"],MM:[n+" Monate",n+" Monaten"],y:["ein Jahr","einem Jahr"],yy:[n+" Jahre",n+" Jahren"]}
;
return t?r[i][0]:r[i][1]}
function hi(n,t,i){
var r={
m:["eine Minute","einer Minute"],h:["eine Stunde","einer Stunde"],d:["ein Tag","einem Tag"],dd:[n+" Tage",n+" Tagen"],M:["ein Monat","einem Monat"],MM:[n+" Monate",n+" Monaten"],y:["ein Jahr","einem Jahr"],yy:[n+" Jahre",n+" Jahren"]}
;
return t?r[i][0]:r[i][1]}
function yt(n,t,i,r){
var u={
s:["mõne sekundi","mõni sekund","paar sekundit"],m:["ühe minuti","üks minut"],mm:[n+" minuti",n+" minutit"],h:["ühe tunni","tund aega","üks tund"],hh:[n+" tunni",n+" tundi"],d:["ühe päeva","üks päev"],M:["kuu aja","kuu aega","üks kuu"],MM:[n+" kuu",n+" kuud"],y:["ühe aasta","aasta","üks aasta"],yy:[n+" aasta",n+" aastat"]}
;
return t?u[i][2]?u[i][2]:u[i][1]:r?u[i][0]:u[i][1]}
function ft(n,t,i,r){
var u="";
switch(i){
case"s":return r?"muutaman sekunnin":"muutama sekunti";
case"m":return r?"minuutin":"minuutti";
case"mm":u=r?"minuutin":"minuuttia";
break;
case"h":return r?"tunnin":"tunti";
case"hh":u=r?"tunnin":"tuntia";
break;
case"d":return r?"päivän":"päivä";
case"dd":u=r?"päivän":"päivää";
break;
case"M":return r?"kuukauden":"kuukausi";
case"MM":u=r?"kuukauden":"kuukautta";
break;
case"y":return r?"vuoden":"vuosi";
case"yy":u=r?"vuoden":"vuotta"}
return od(n,r)+" "+u}
function od(n,t){
return n<10?t?ed[n]:ef[n]:n}
function nr(n,t,i){
var r=n+" ";
switch(i){
case"m":return t?"jedna minuta":"jedne minute";
case"mm":return r+(n===1?"minuta":n===2||n===3||n===4?"minute":"minuta");
case"h":return t?"jedan sat":"jednog sata";
case"hh":return r+(n===1?"sat":n===2||n===3||n===4?"sata":"sati");
case"dd":return r+(n===1?"dan":"dana");
case"MM":return r+(n===1?"mjesec":n===2||n===3||n===4?"mjeseca":"mjeseci");
case"yy":return r+(n===1?"godina":n===2||n===3||n===4?"godine":"godina")}
}
function et(n,t,i,r){
var u=n;
switch(i){
case"s":return r||t?"néhány másodperc":"néhány másodperce";
case"m":return"egy"+(r||t?" perc":" perce");
case"mm":return u+(r||t?" perc":" perce");
case"h":return"egy"+(r||t?" óra":" órája");
case"hh":return u+(r||t?" óra":" órája");
case"d":return"egy"+(r||t?" nap":" napja");
case"dd":return u+(r||t?" nap":" napja");
case"M":return"egy"+(r||t?" hónap":" hónapja");
case"MM":return u+(r||t?" hónap":" hónapja");
case"y":return"egy"+(r||t?" év":" éve");
case"yy":return u+(r||t?" év":" éve")}
return""}
function il(n){
return(n?"":"[múlt] ")+"["+tl[this.day()]+"] LT[-kor]"}
function kr(n){
return n%100==11?!0:n%10==1?!1:!0}
function pt(n,t,i,r){
var u=n+" ";
switch(i){
case"s":return t||r?"nokkrar sekúndur":"nokkrum sekúndum";
case"m":return t?"mínúta":"mínútu";
case"mm":return kr(n)?u+(t||r?"mínútur":"mínútum"):t?u+"mínúta":u+"mínútu";
case"hh":return kr(n)?u+(t||r?"klukkustundir":"klukkustundum"):u+"klukkustund";
case"d":return t?"dagur":r?"dag":"degi";
case"dd":return kr(n)?t?u+"dagar":u+(r?"daga":"dögum"):t?u+"dagur":u+(r?"dag":"degi");
case"M":return t?"mánuður":r?"mánuð":"mánuði";
case"MM":return kr(n)?t?u+"mánuðir":u+(r?"mánuði":"mánuðum"):t?u+"mánuður":u+(r?"mánuð":"mánuði");
case"y":return t||r?"ár":"ári";
case"yy":return kr(n)?u+(t||r?"ár":"árum"):u+(t||r?"ár":"ári")}
}
function dr(n,t,i){
var r={
m:["eng Minutt","enger Minutt"],h:["eng Stonn","enger Stonn"],d:["een Dag","engem Dag"],M:["ee Mount","engem Mount"],y:["ee Joer","engem Joer"]}
;
return t?r[i][0]:r[i][1]}
function vd(n){
var t=n.substr(0,n.indexOf(" "));
return er(t)?"a "+n:"an "+n}
function yd(n){
var t=n.substr(0,n.indexOf(" "));
return er(t)?"viru "+n:"virun "+n}
function er(n){
if(n=parseInt(n,10),isNaN(n))return!1;
if(n<0)return!0;
if(n<10)return 4<=n&&n<=7?!0:!1;
if(n<100){
var t=n%10,i=n/10;
return t===0?er(i):er(t)}
if(n<1e4){
while(n>=10)n=n/10;
return er(n)}
return n=n/1e3,er(n)}
function wd(n,t,i,r){
return t?"kelios sekundės":r?"kelių sekundžių":"kelias sekundes"}
function or(n,t,i,r){
return t?ci(i)[0]:r?ci(i)[1]:ci(i)[2]}
function rl(n){
return n%10==0||n>10&&n<20}
function ci(n){
return pd[n].split("_")}
function gr(n,t,i,r){
var u=n+" ";
return n===1?u+or(n,t,i[0],r):t?u+(rl(n)?ci(i)[1]:ci(i)[0]):r?u+ci(i)[1]:u+(rl(n)?ci(i)[1]:ci(i)[2])}
function ul(n,t,i){
return i?t%10==1&&t!==11?n[2]:n[3]:t%10==1&&t!==11?n[0]:n[1]}
function nu(n,t,i){
return n+" "+ul(to[i],n,t)}
function tu(n,t,i){
return ul(to[i],n,t)}
function kd(n,t){
return t?"dažas sekundes":"dažām sekundēm"}
function ot(n,t,i){
var r="";
if(t)switch(i){
case"s":r="काही सेकंद";
break;
case"m":r="एक मिनिट";
break;
case"mm":r="%d मिनिटे";
break;
case"h":r="एक तास";
break;
case"hh":r="%d तास";
break;
case"d":r="एक दिवस";
break;
case"dd":r="%d दिवस";
break;
case"M":r="एक महिना";
break;
case"MM":r="%d महिने";
break;
case"y":r="एक वर्ष";
break;
case"yy":r="%d वर्षे"}
else switch(i){
case"s":r="काही सेकंदां";
break;
case"m":r="एका मिनिटा";
break;
case"mm":r="%d मिनिटां";
break;
case"h":r="एका तासा";
break;
case"hh":r="%d तासां";
break;
case"d":r="एका दिवसा";
break;
case"dd":r="%d दिवसां";
break;
case"M":r="एका महिन्या";
break;
case"MM":r="%d महिन्यां";
break;
case"y":r="एका वर्षा";
break;
case"yy":r="%d वर्षां"}
return r.replace(/%d/i,n)}
function of(n){
return n%10<5&&n%10>1&&~~(n/10)%10!=1}
function sr(n,t,i){
var r=n+" ";
switch(i){
case"m":return t?"minuta":"minutę";
case"mm":return r+(of(n)?"minuty":"minut");
case"h":return t?"godzina":"godzinę";
case"hh":return r+(of(n)?"godziny":"godzin");
case"MM":return r+(of(n)?"miesiące":"miesięcy");
case"yy":return r+(of(n)?"lata":"lat")}
}
function iu(n,t,i){
var r=" ";
return(n%100>=20||n>=100&&n%100==0)&&(r=" de "),n+r+{
mm:"minute",hh:"ore",dd:"zile",MM:"luni",yy:"ani"}
[i]}
function hg(n,t){
var i=n.split("_");
return t%10==1&&t%100!=11?i[0]:t%10>=2&&t%10<=4&&(t%100<10||t%100>=20)?i[1]:i[2]}
function hr(n,t,i){
var r={
mm:t?"минута_минуты_минут":"минуту_минуты_минут",hh:"час_часа_часов",dd:"день_дня_дней",MM:"месяц_месяца_месяцев",yy:"год_года_лет"}
;
return i==="m"?t?"минута":"минуту":n+" "+hg(r[i],+n)}
function ru(n){
return n>1&&n<5}
function st(n,t,i,r){
var u=n+" ";
switch(i){
case"s":return t||r?"pár sekúnd":"pár sekundami";
case"m":return t?"minúta":r?"minútu":"minútou";
case"mm":return t||r?u+(ru(n)?"minúty":"minút"):u+"minútami";
case"h":return t?"hodina":r?"hodinu":"hodinou";
case"hh":return t||r?u+(ru(n)?"hodiny":"hodín"):u+"hodinami";
case"d":return t||r?"deň":"dňom";
case"dd":return t||r?u+(ru(n)?"dni":"dní"):u+"dňami";
case"M":return t||r?"mesiac":"mesiacom";
case"MM":return t||r?u+(ru(n)?"mesiace":"mesiacov"):u+"mesiacmi";
case"y":return t||r?"rok":"rokom";
case"yy":return t||r?u+(ru(n)?"roky":"rokov"):u+"rokmi"}
}
function ht(n,t,i,r){
var u=n+" ";
switch(i){
case"s":return t||r?"nekaj sekund":"nekaj sekundami";
case"m":return t?"ena minuta":"eno minuto";
case"mm":return u+(n===1?t?"minuta":"minuto":n===2?t||r?"minuti":"minutama":n<5?t||r?"minute":"minutami":t||r?"minut":"minutami");
case"h":return t?"ena ura":"eno uro";
case"hh":return u+(n===1?t?"ura":"uro":n===2?t||r?"uri":"urama":n<5?t||r?"ure":"urami":t||r?"ur":"urami");
case"d":return t||r?"en dan":"enim dnem";
case"dd":return u+(n===1?t||r?"dan":"dnem":n===2?t||r?"dni":"dnevoma":t||r?"dni":"dnevi");
case"M":return t||r?"en mesec":"enim mesecem";
case"MM":return u+(n===1?t||r?"mesec":"mesecem":n===2?t||r?"meseca":"mesecema":n<5?t||r?"mesece":"meseci":t||r?"mesecev":"meseci");
case"y":return t||r?"eno leto":"enim letom";
case"yy":return u+(n===1?t||r?"leto":"letom":n===2?t||r?"leti":"letoma":n<5?t||r?"leta":"leti":t||r?"let":"leti")}
}
function pg(n){
var t=n;
return n.indexOf("jaj")!==-1?t.slice(0,-3)+"leS":n.indexOf("jar")!==-1?t.slice(0,-3)+"waQ":n.indexOf("DIS")!==-1?t.slice(0,-3)+"nem":t+" pIq"}
function wg(n){
var t=n;
return n.indexOf("jaj")!==-1?t.slice(0,-3)+"Hu’":n.indexOf("jar")!==-1?t.slice(0,-3)+"wen":n.indexOf("DIS")!==-1?t.slice(0,-3)+"ben":t+" ret"}
function uu(n,t,i){
var r=bg(n);
switch(i){
case"mm":return r+" tup";
case"hh":return r+" rep";
case"dd":return r+" jaj";
case"MM":return r+" jar";
case"yy":return r+" DIS"}
}
function bg(n){
var i=Math.floor(n%1e3/100),r=Math.floor(n%100/10),u=n%10,t="";
return i>0&&(t+=ro[i]+"vatlh"),r>0&&(t+=(t!==""?" ":"")+ro[r]+"maH"),u>0&&(t+=(t!==""?" ":"")+ro[u]),t===""?"pagh":t}
function ct(n,t,i,r){
var u={
s:["viensas secunds","'iensas secunds"],m:["'n míut","'iens míut"],mm:[n+" míuts",""+n+" míuts"],h:["'n þora","'iensa þora"],hh:[n+" þoras",""+n+" þoras"],d:["'n ziua","'iensa ziua"],dd:[n+" ziuas",""+n+" ziuas"],M:["'n mes","'iens mes"],MM:[n+" mesen",""+n+" mesen"],y:["'n ar","'iens ar"],yy:[n+" ars",""+n+" ars"]}
;
return r?u[i][0]:t?u[i][0]:u[i][1]}
function gg(n,t){
var i=n.split("_");
return t%10==1&&t%100!=11?i[0]:t%10>=2&&t%10<=4&&(t%100<10||t%100>=20)?i[1]:i[2]}
function cr(n,t,i){
var r={
mm:t?"хвилина_хвилини_хвилин":"хвилину_хвилини_хвилин",hh:t?"година_години_годин":"годину_години_годин",dd:"день_дні_днів",MM:"місяць_місяці_місяців",yy:"рік_роки_років"}
;
return i==="m"?t?"хвилина":"хвилину":i==="h"?t?"година":"годину":n+" "+gg(r[i],+n)}
function nn(n,t){
var i={
nominative:"неділя_понеділок_вівторок_середа_четвер_п’ятниця_субота".split("_"),accusative:"неділю_понеділок_вівторок_середу_четвер_п’ятницю_суботу".split("_"),genitive:"неділі_понеділка_вівторка_середи_четверга_п’ятниці_суботи".split("_")}
,r=/(\[[ВвУу]\]) ?dddd/.test(t)?"accusative":/\[?(?:минулої|наступної)? ?\] ?dddd/.test(t)?"genitive":"nominative";
return i[r][n.day()]}
function lr(n){
return function(){
return n+"о"+(this.hours()===11?"б":"")+"] LT"}
}
var fo,oo,ou,su,cf,lo,a,hu,ir,bu,gf,us,fs,ss,hs,ie,ws,bs,ds,nh,ih,rh,sh,hh,he,vh,ce,yh,ph,wh,bh,kh,dh,tc,ic,rc,uc,ei,fc,t,ve,ec,oc,sc,hc,cc,ac,f,vt,ki,gt,uf,s,nd,td,ad,tl,bd,to,sg,ag,kg,dg;
oo=Array.prototype.some?Array.prototype.some:function(n){
for(var i=Object(this),r=i.length>>>0,t=0;
t<r;
t++)if(t in i&&n.call(this,i[t],t,i))return!0;
return!1}
;
ou=i.momentProperties=[];
su=!1;
cf={
}
;
i.suppressDeprecationWarnings=!1;
i.deprecationHandler=null;
lo=Object.keys?Object.keys:function(n){
var t,i=[];
for(t in n)b(n,t)&&i.push(t);
return i}
;
a={
}
;
ir={
}
;
var ko=/(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{
1,9}
|x|X|zz?|ZZ?|.)/g,lu=/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{
1,4}
)/g,yf={
}
,ur={
}
;
var ns=/\d/,d=/\d\d/,ts=/\d{
3}
/,wf=/\d{
4}
/,au=/[+-]?\d{
6}
/,c=/\d\d?/,is=/\d\d\d\d?/,rs=/\d\d\d\d\d\d?/,vu=/\d{
1,3}
/,bf=/\d{
1,4}
/,yu=/[+-]?\d{
1,6}
/,pu=/[+-]?\d+/,wl=/Z|[+-]\d\d:?\d\d/gi,wu=/Z|[+-]\d\d(?::?\d\d)?/gi,vr=/[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){
1,2}
/i,kf={
}
;
bu={
}
;
var tt=0,kt=1,at=2,y=3,it=4,dt=5,yi=6,gl=7,na=8,v;
v=Array.prototype.indexOf?Array.prototype.indexOf:function(n){
for(var t=0;
t<this.length;
++t)if(this[t]===n)return t;
return-1}
;
u("M",["MM",2],"Mo",
function(){
return this.month()+1}
);
u("MMM",0,0,
function(n){
return this.localeData().monthsShort(this,n)}
);
u("MMMM",0,0,
function(n){
return this.localeData().months(this,n)}
);
p("month","M");
r("M",c);
r("MM",c,d);
r("MMM",
function(n,t){
return t.monthsShortRegex(n)}
);
r("MMMM",
function(n,t){
return t.monthsRegex(n)}
);
h(["M","MM"],
function(n,t){
t[kt]=o(n)-1}
);
h(["MMM","MMMM"],
function(n,t,i,r){
var u=i._locale.monthsParse(n,r,i._strict);
u!=null?t[kt]=u:e(i).invalidMonth=n}
);
gf=/D[oD]?(\[[^\[\]]*\]|\s+)+MMMM?/;
us="January_February_March_April_May_June_July_August_September_October_November_December".split("_");
fs="Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_");
ss=vr;
hs=vr;
var sa=/^\s*((?:[+-]\d{
6}
|\d{
4}
)-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/,ha=/^\s*((?:[+-]\d{
6}
|\d{
4}
)(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/,ca=/Z|[+-]\d\d(?::?\d\d)?/,ku=[["YYYYYY-MM-DD",/[+-]\d{
6}
-\d\d-\d\d/],["YYYY-MM-DD",/\d{
4}
-\d\d-\d\d/],["GGGG-[W]WW-E",/\d{
4}
-W\d\d-\d/],["GGGG-[W]WW",/\d{
4}
-W\d\d/,!1],["YYYY-DDD",/\d{
4}
-\d{
3}
/],["YYYY-MM",/\d{
4}
-\d\d/,!1],["YYYYYYMMDD",/[+-]\d{
10}
/],["YYYYMMDD",/\d{
8}
/],["GGGG[W]WWE",/\d{
4}
W\d{
3}
/],["GGGG[W]WW",/\d{
4}
W\d{
2}
/,!1],["YYYYDDD",/\d{
7}
/]],te=[["HH:mm:ss.SSSS",/\d\d:\d\d:\d\d\.\d+/],["HH:mm:ss,SSSS",/\d\d:\d\d:\d\d,\d+/],["HH:mm:ss",/\d\d:\d\d:\d\d/],["HH:mm",/\d\d:\d\d/],["HHmmss.SSSS",/\d\d\d\d\d\d\.\d+/],["HHmmss,SSSS",/\d\d\d\d\d\d,\d+/],["HHmmss",/\d\d\d\d\d\d/],["HHmm",/\d\d\d\d/],["HH",/\d\d/]],la=/^\/?Date\((\-?\d+)/i;
for(i.createFromInputFallback=g("moment construction falls back to js Date. This is discouraged and will be removed in upcoming major release. Please refer to https://github.com/moment/moment/issues/1407 for more info.",
function(n){
n._d=new Date(n._i+(n._useUTC?" UTC":""))}
),u("Y",0,0,
function(){
var n=this.year();
return n<=9999?""+n:"+"+n}
),u(0,["YY",2],0,
function(){
return this.year()%100}
),u(0,["YYYY",4],0,"year"),u(0,["YYYYY",5],0,"year"),u(0,["YYYYYY",6,!0],0,"year"),p("year","y"),r("Y",pu),r("YY",c,d),r("YYYY",bf,wf),r("YYYYY",yu,au),r("YYYYYY",yu,au),h(["YYYYY","YYYYYY"],tt),h("YYYY",
function(n,t){
t[tt]=n.length===2?i.parseTwoDigitYear(n):o(n)}
),h("YY",
function(n,t){
t[tt]=i.parseTwoDigitYear(n)}
),h("Y",
function(n,t){
t[tt]=parseInt(n,10)}
),i.parseTwoDigitYear=function(n){
return o(n)+(o(n)>68?1900:2e3)}
,ie=rr("FullYear",!0),i.ISO_8601=function(){
}
,ws=g("moment().min is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548",
function(){
var n=l.apply(null,arguments);
return this.isValid()&&n.isValid()?n<this?this:n:eu()}
),bs=g("moment().max is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548",
function(){
var n=l.apply(null,arguments);
return this.isValid()&&n.isValid()?n>this?this:n:eu()}
),ds=function(){
return Date.now?Date.now():+new Date}
,gs("Z",":"),gs("ZZ",""),r("Z",wu),r("ZZ",wu),h(["Z","ZZ"],
function(n,t,i){
i._useUTC=!0;
i._tzm=ee(wu,n)}
),nh=/([\+\-]|\d\d)/gi,i.updateOffset=function(){
}
,ih=/^(\-)?(?:(\d*)[. ])?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{
3}
)?\d*)?$/,rh=/^(-)?P(?:(-?[0-9,.]*)Y)?(?:(-?[0-9,.]*)M)?(?:(-?[0-9,.]*)W)?(?:(-?[0-9,.]*)D)?(?:T(?:(-?[0-9,.]*)H)?(?:(-?[0-9,.]*)M)?(?:(-?[0-9,.]*)S)?)?$/,fi.fn=nf.prototype,sh=eh(1,"add"),hh=eh(-1,"subtract"),i.defaultFormat="YYYY-MM-DDTHH:mm:ssZ",i.defaultFormatUtc="YYYY-MM-DDTHH:mm:ss[Z]",he=g("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.",
function(n){
return n===undefined?this.localeData():this.locale(n)}
),u(0,["gg",2],0,
function(){
return this.weekYear()%100}
),u(0,["GG",2],0,
function(){
return this.isoWeekYear()%100}
),tf("gggg","weekYear"),tf("ggggg","weekYear"),tf("GGGG","isoWeekYear"),tf("GGGGG","isoWeekYear"),p("weekYear","gg"),p("isoWeekYear","GG"),r("G",pu),r("g",pu),r("GG",c,d),r("gg",c,d),r("GGGG",bf,wf),r("gggg",bf,wf),r("GGGGG",yu,au),r("ggggg",yu,au),yr(["gggg","ggggg","GGGG","GGGGG"],
function(n,t,i,r){
t[r.substr(0,2)]=o(n)}
),yr(["gg","GG"],
function(n,t,r,u){
t[u]=i.parseTwoDigitYear(n)}
),u("Q",0,"Qo","quarter"),p("quarter","Q"),r("Q",ns),h("Q",
function(n,t){
t[kt]=(o(n)-1)*3}
),u("w",["ww",2],"wo","week"),u("W",["WW",2],"Wo","isoWeek"),p("week","w"),p("isoWeek","W"),r("w",c),r("ww",c,d),r("W",c),r("WW",c,d),yr(["w","ww","W","WW"],
function(n,t,i,r){
t[r.substr(0,1)]=o(n)}
),vh={
dow:0,doy:6}
,u("D",["DD",2],"Do","date"),p("date","D"),r("D",c),r("DD",c,d),r("Do",
function(n,t){
return n?t._ordinalParse:t._ordinalParseLenient}
),h(["D","DD"],at),h("Do",
function(n,t){
t[at]=o(n.match(c)[0],10)}
),ce=rr("Date",!0),u("d",0,"do","day"),u("dd",0,0,
function(n){
return this.localeData().weekdaysMin(this,n)}
),u("ddd",0,0,
function(n){
return this.localeData().weekdaysShort(this,n)}
),u("dddd",0,0,
function(n){
return this.localeData().weekdays(this,n)}
),u("e",0,0,"weekday"),u("E",0,0,"isoWeekday"),p("day","d"),p("weekday","e"),p("isoWeekday","E"),r("d",c),r("e",c),r("E",c),r("dd",
function(n,t){
return t.weekdaysMinRegex(n)}
),r("ddd",
function(n,t){
return t.weekdaysShortRegex(n)}
),r("dddd",
function(n,t){
return t.weekdaysRegex(n)}
),yr(["dd","ddd","dddd"],
function(n,t,i,r){
var u=i._locale.weekdaysParse(n,r,i._strict);
u!=null?t.d=u:e(i).invalidWeekday=n}
),yr(["d","e","E"],
function(n,t,i,r){
t[r]=o(n)}
),yh="Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),ph="Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),wh="Su_Mo_Tu_We_Th_Fr_Sa".split("_"),bh=vr,kh=vr,dh=vr,u("DDD",["DDDD",3],"DDDo","dayOfYear"),p("dayOfYear","DDD"),r("DDD",vu),r("DDDD",ts),h(["DDD","DDDD"],
function(n,t,i){
i._dayOfYear=o(n)}
),u("H",["HH",2],0,"hour"),u("h",["hh",2],0,ae),u("k",["kk",2],0,uw),u("hmm",0,0,
function(){
return""+ae.apply(this)+bt(this.minutes(),2)}
),u("hmmss",0,0,
function(){
return""+ae.apply(this)+bt(this.minutes(),2)+bt(this.seconds(),2)}
),u("Hmm",0,0,
function(){
return""+this.hours()+bt(this.minutes(),2)}
),u("Hmmss",0,0,
function(){
return""+this.hours()+bt(this.minutes(),2)+bt(this.seconds(),2)}
),gh("a",!0),gh("A",!1),p("hour","h"),r("a",nc),r("A",nc),r("H",c),r("h",c),r("HH",c,d),r("hh",c,d),r("hmm",is),r("hmmss",rs),r("Hmm",is),r("Hmmss",rs),h(["H","HH"],y),h(["a","A"],
function(n,t,i){
i._isPm=i._locale.isPM(n);
i._meridiem=n}
),h(["h","hh"],
function(n,t,i){
t[y]=o(n);
e(i).bigHour=!0}
),h("hmm",
function(n,t,i){
var r=n.length-2;
t[y]=o(n.substr(0,r));
t[it]=o(n.substr(r));
e(i).bigHour=!0}
),h("hmmss",
function(n,t,i){
var r=n.length-4,u=n.length-2;
t[y]=o(n.substr(0,r));
t[it]=o(n.substr(r,2));
t[dt]=o(n.substr(u));
e(i).bigHour=!0}
),h("Hmm",
function(n,t){
var i=n.length-2;
t[y]=o(n.substr(0,i));
t[it]=o(n.substr(i))}
),h("Hmmss",
function(n,t){
var i=n.length-4,r=n.length-2;
t[y]=o(n.substr(0,i));
t[it]=o(n.substr(i,2));
t[dt]=o(n.substr(r))}
),tc=/[ap]\.?m?\.?/i,ic=rr("Hours",!0),u("m",["mm",2],0,"minute"),p("minute","m"),r("m",c),r("mm",c,d),h(["m","mm"],it),rc=rr("Minutes",!1),u("s",["ss",2],0,"second"),p("second","s"),r("s",c),r("ss",c,d),h(["s","ss"],dt),uc=rr("Seconds",!1),u("S",0,0,
function(){
return~~(this.millisecond()/100)}
),u(0,["SS",2],0,
function(){
return~~(this.millisecond()/10)}
),u(0,["SSS",3],0,"millisecond"),u(0,["SSSS",4],0,
function(){
return this.millisecond()*10}
),u(0,["SSSSS",5],0,
function(){
return this.millisecond()*100}
),u(0,["SSSSSS",6],0,
function(){
return this.millisecond()*1e3}
),u(0,["SSSSSSS",7],0,
function(){
return this.millisecond()*1e4}
),u(0,["SSSSSSSS",8],0,
function(){
return this.millisecond()*1e5}
),u(0,["SSSSSSSSS",9],0,
function(){
return this.millisecond()*1e6}
),p("millisecond","ms"),r("S",vu,ns),r("SS",vu,d),r("SSS",vu,ts),ei="SSSS";
ei.length<=9;
ei+="S")r(ei,/\d+/);
for(ei="S";
ei.length<=9;
ei+="S")h(ei,ow);
fc=rr("Milliseconds",!1);
u("z",0,0,"zoneAbbr");
u("zz",0,0,"zoneName");
t=ar.prototype;
t.add=sh;
t.calendar=yv;
t.clone=pv;
t.diff=ty;
t.endOf=ly;
t.format=fy;
t.from=ey;
t.fromNow=oy;
t.to=sy;
t.toNow=hy;
t.get=bo;
t.invalidAt=gy;
t.isAfter=wv;
t.isBefore=bv;
t.isBetween=kv;
t.isSame=dv;
t.isSameOrAfter=gv;
t.isSameOrBefore=ny;
t.isValid=ky;
t.lang=he;
t.locale=ch;
t.localeData=lh;
t.max=bs;
t.min=ws;
t.parsingFlags=dy;
t.set=bo;
t.startOf=cy;
t.subtract=hh;
t.toArray=py;
t.toObject=wy;
t.toDate=yy;
t.toISOString=uy;
t.toJSON=by;
t.toString=ry;
t.unix=vy;
t.valueOf=ay;
t.creationData=np;
t.year=ie;
t.isLeapYear=ya;
t.weekYear=tp;
t.isoWeekYear=ip;
t.quarter=t.quarters=ep;
t.month=os;
t.daysInMonth=fa;
t.week=t.weeks=cp;
t.isoWeek=t.isoWeeks=lp;
t.weeksInYear=up;
t.isoWeeksInYear=rp;
t.date=ce;
t.day=t.days=kp;
t.weekday=dp;
t.isoWeekday=gp;
t.dayOfYear=rw;
t.hour=t.hours=ic;
t.minute=t.minutes=rc;
t.second=t.seconds=uc;
t.millisecond=t.milliseconds=fc;
t.utcOffset=rv;
t.utc=fv;
t.local=ev;
t.parseZone=ov;
t.hasAlignedHourOffset=sv;
t.isDST=hv;
t.isDSTShifted=cv;
t.isLocal=lv;
t.isUtcOffset=av;
t.isUtc=th;
t.isUTC=th;
t.zoneAbbr=sw;
t.zoneName=hw;
t.dates=g("dates accessor is deprecated. Use date instead.",ce);
t.months=g("months accessor is deprecated. Use month instead",os);
t.years=g("years accessor is deprecated. Use year instead",ie);
t.zone=g("moment().zone is deprecated, use moment().utcOffset instead. https://github.com/moment/moment/issues/1779",uv);
ve=t;
ec={
sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"}
;
oc={
LTS:"h:mm:ss A",LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"}
;
sc="Invalid date";
hc="%d";
cc=/\d{
1,2}
/;
ac={
future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"}
;
f=vf.prototype;
f._calendar=ec;
f.calendar=aw;
f._longDateFormat=oc;
f.longDateFormat=vw;
f._invalidDate=sc;
f.invalidDate=yw;
f._ordinal=hc;
f.ordinal=pw;
f._ordinalParse=cc;
f.preparse=lc;
f.postformat=lc;
f._relativeTime=ac;
f.relativeTime=ww;
f.pastFuture=bw;
f.set=cl;
f.months=ta;
f._months=us;
f.monthsShort=ia;
f._monthsShort=fs;
f.monthsParse=ua;
f._monthsRegex=hs;
f.monthsRegex=oa;
f._monthsShortRegex=ss;
f.monthsShortRegex=ea;
f.week=op;
f._week=vh;
f.firstDayOfYear=hp;
f.firstDayOfWeek=sp;
f.weekdays=vp;
f._weekdays=yh;
f.weekdaysMin=pp;
f._weekdaysMin=wh;
f.weekdaysShort=yp;
f._weekdaysShort=ph;
f.weekdaysParse=bp;
f._weekdaysRegex=bh;
f.weekdaysRegex=nw;
f._weekdaysShortRegex=kh;
f.weekdaysShortRegex=tw;
f._weekdaysMinRegex=dh;
f.weekdaysMinRegex=iw;
f.isPM=fw;
f._meridiemParse=tc;
f.meridiem=ew;
tr("en",{
ordinalParse:/\d{
1,2}
(th|st|nd|rd)/,ordinal:function(n){
var t=n%10,i=o(n%100/10)===1?"th":t===1?"st":t===2?"nd":t===3?"rd":"th";
return n+i}
}
);
i.lang=g("moment.lang is deprecated. Use moment.locale instead.",tr);
i.langData=g("moment.langData is deprecated. Use moment.localeData instead.",ui);
vt=Math.abs;
var sb=oi("ms"),hb=oi("s"),cb=oi("m"),lb=oi("h"),ab=oi("d"),vb=oi("w"),yb=oi("M"),pb=oi("y");
var bb=bi("milliseconds"),kb=bi("seconds"),db=bi("minutes"),gb=bi("hours"),nk=bi("days"),tk=bi("months"),ik=bi("years");
ki=Math.round;
gt={
s:45,m:45,h:22,d:26,M:11}
;
uf=Math.abs;
s=nf.prototype;
s.abs=ib;
s.add=rb;
s.subtract=ub;
s.as=eb;
s.asMilliseconds=sb;
s.asSeconds=hb;
s.asMinutes=cb;
s.asHours=lb;
s.asDays=ab;
s.asWeeks=vb;
s.asMonths=yb;
s.asYears=pb;
s.valueOf=ob;
s._bubble=fb;
s.get=wb;
s.milliseconds=bb;
s.seconds=kb;
s.minutes=db;
s.hours=gb;
s.days=nk;
s.weeks=rk;
s.months=tk;
s.years=ik;
s.humanize=ok;
s.toISOString=ff;
s.toString=ff;
s.toJSON=ff;
s.locale=ch;
s.localeData=lh;
s.toIsoString=g("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)",ff);
s.lang=he;
u("X",0,0,"unix");
u("x",0,0,"valueOf");
r("x",pu);
r("X",/[+-]?\d+(\.\d{
1,3}
)?/);
h("X",
function(n,t,i){
i._d=new Date(parseFloat(n,10)*1e3)}
);
h("x",
function(n,t,i){
i._d=new Date(o(n))}
);
i.version="2.13.0";
sl(l);
i.fn=ve;
i.min=tv;
i.max=iv;
i.now=ds;
i.utc=lt;
i.unix=cw;
i.months=kw;
i.isDate=fu;
i.locale=tr;
i.invalid=eu;
i.duration=fi;
i.isMoment=ri;
i.weekdays=gw;
i.parseZone=lw;
i.localeData=ui;
i.isDuration=fe;
i.monthsShort=dw;
i.weekdaysMin=tb;
i.defineLocale=yo;
i.updateLocale=al;
i.locales=vl;
i.weekdaysShort=nb;
i.normalizeUnits=nt;
i.relativeTimeThreshold=ek;
i.prototype=ve;
var n=i,tn=n.defineLocale("af",{
months:"Januarie_Februarie_Maart_April_Mei_Junie_Julie_Augustus_September_Oktober_November_Desember".split("_"),monthsShort:"Jan_Feb_Mar_Apr_Mei_Jun_Jul_Aug_Sep_Okt_Nov_Des".split("_"),weekdays:"Sondag_Maandag_Dinsdag_Woensdag_Donderdag_Vrydag_Saterdag".split("_"),weekdaysShort:"Son_Maa_Din_Woe_Don_Vry_Sat".split("_"),weekdaysMin:"So_Ma_Di_Wo_Do_Vr_Sa".split("_"),meridiemParse:/vm|nm/i,isPM:function(n){
return/^nm$/i.test(n)}
,meridiem:function(n,t,i){
return n<12?i?"vm":"VM":i?"nm":"NM"}
,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Vandag om] LT",nextDay:"[Môre om] LT",nextWeek:"dddd [om] LT",lastDay:"[Gister om] LT",lastWeek:"[Laas] dddd [om] LT",sameElse:"L"}
,relativeTime:{
future:"oor %s",past:"%s gelede",s:"'n paar sekondes",m:"'n minuut",mm:"%d minute",h:"'n uur",hh:"%d ure",d:"'n dag",dd:"%d dae",M:"'n maand",MM:"%d maande",y:"'n jaar",yy:"%d jaar"}
,ordinalParse:/\d{
1,2}
(ste|de)/,ordinal:function(n){
return n+(n===1||n===8||n>=20?"ste":"de")}
,week:{
dow:1,doy:4}
}
),rn=n.defineLocale("ar-ma",{
months:"يناير_فبراير_مارس_أبريل_ماي_يونيو_يوليوز_غشت_شتنبر_أكتوبر_نونبر_دجنبر".split("_"),monthsShort:"يناير_فبراير_مارس_أبريل_ماي_يونيو_يوليوز_غشت_شتنبر_أكتوبر_نونبر_دجنبر".split("_"),weekdays:"الأحد_الإتنين_الثلاثاء_الأربعاء_الخميس_الجمعة_السبت".split("_"),weekdaysShort:"احد_اتنين_ثلاثاء_اربعاء_خميس_جمعة_سبت".split("_"),weekdaysMin:"ح_ن_ث_ر_خ_ج_س".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[اليوم على الساعة] LT",nextDay:"[غدا على الساعة] LT",nextWeek:"dddd [على الساعة] LT",lastDay:"[أمس على الساعة] LT",lastWeek:"dddd [على الساعة] LT",sameElse:"L"}
,relativeTime:{
future:"في %s",past:"منذ %s",s:"ثوان",m:"دقيقة",mm:"%d دقائق",h:"ساعة",hh:"%d ساعات",d:"يوم",dd:"%d أيام",M:"شهر",MM:"%d أشهر",y:"سنة",yy:"%d سنوات"}
,week:{
dow:6,doy:12}
}
),sk={
"1":"١","2":"٢","3":"٣","4":"٤","5":"٥","6":"٦","7":"٧","8":"٨","9":"٩","0":"٠"}
,hk={
"١":"1","٢":"2","٣":"3","٤":"4","٥":"5","٦":"6","٧":"7","٨":"8","٩":"9","٠":"0"}
,un=n.defineLocale("ar-sa",{
months:"يناير_فبراير_مارس_أبريل_مايو_يونيو_يوليو_أغسطس_سبتمبر_أكتوبر_نوفمبر_ديسمبر".split("_"),monthsShort:"يناير_فبراير_مارس_أبريل_مايو_يونيو_يوليو_أغسطس_سبتمبر_أكتوبر_نوفمبر_ديسمبر".split("_"),weekdays:"الأحد_الإثنين_الثلاثاء_الأربعاء_الخميس_الجمعة_السبت".split("_"),weekdaysShort:"أحد_إثنين_ثلاثاء_أربعاء_خميس_جمعة_سبت".split("_"),weekdaysMin:"ح_ن_ث_ر_خ_ج_س".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,meridiemParse:/ص|م/,isPM:function(n){
return"م"===n}
,meridiem:function(n){
return n<12?"ص":"م"}
,calendar:{
sameDay:"[اليوم على الساعة] LT",nextDay:"[غدا على الساعة] LT",nextWeek:"dddd [على الساعة] LT",lastDay:"[أمس على الساعة] LT",lastWeek:"dddd [على الساعة] LT",sameElse:"L"}
,relativeTime:{
future:"في %s",past:"منذ %s",s:"ثوان",m:"دقيقة",mm:"%d دقائق",h:"ساعة",hh:"%d ساعات",d:"يوم",dd:"%d أيام",M:"شهر",MM:"%d أشهر",y:"سنة",yy:"%d سنوات"}
,preparse:function(n){
return n.replace(/[١٢٣٤٥٦٧٨٩٠]/g,
function(n){
return hk[n]}
).replace(/،/g,",")}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return sk[n]}
).replace(/,/g,"،")}
,week:{
dow:6,doy:12}
}
),fn=n.defineLocale("ar-tn",{
months:"جانفي_فيفري_مارس_أفريل_ماي_جوان_جويلية_أوت_سبتمبر_أكتوبر_نوفمبر_ديسمبر".split("_"),monthsShort:"جانفي_فيفري_مارس_أفريل_ماي_جوان_جويلية_أوت_سبتمبر_أكتوبر_نوفمبر_ديسمبر".split("_"),weekdays:"الأحد_الإثنين_الثلاثاء_الأربعاء_الخميس_الجمعة_السبت".split("_"),weekdaysShort:"أحد_إثنين_ثلاثاء_أربعاء_خميس_جمعة_سبت".split("_"),weekdaysMin:"ح_ن_ث_ر_خ_ج_س".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[اليوم على الساعة] LT",nextDay:"[غدا على الساعة] LT",nextWeek:"dddd [على الساعة] LT",lastDay:"[أمس على الساعة] LT",lastWeek:"dddd [على الساعة] LT",sameElse:"L"}
,relativeTime:{
future:"في %s",past:"منذ %s",s:"ثوان",m:"دقيقة",mm:"%d دقائق",h:"ساعة",hh:"%d ساعات",d:"يوم",dd:"%d أيام",M:"شهر",MM:"%d أشهر",y:"سنة",yy:"%d سنوات"}
,week:{
dow:1,doy:4}
}
),ck={
"1":"١","2":"٢","3":"٣","4":"٤","5":"٥","6":"٦","7":"٧","8":"٨","9":"٩","0":"٠"}
,lk={
"١":"1","٢":"2","٣":"3","٤":"4","٥":"5","٦":"6","٧":"7","٨":"8","٩":"9","٠":"0"}
,bc=function(n){
return n===0?0:n===1?1:n===2?2:n%100>=3&&n%100<=10?3:n%100>=11?4:5}
,ak={
s:["أقل من ثانية","ثانية واحدة",["ثانيتان","ثانيتين"],"%d ثوان","%d ثانية","%d ثانية"],m:["أقل من دقيقة","دقيقة واحدة",["دقيقتان","دقيقتين"],"%d دقائق","%d دقيقة","%d دقيقة"],h:["أقل من ساعة","ساعة واحدة",["ساعتان","ساعتين"],"%d ساعات","%d ساعة","%d ساعة"],d:["أقل من يوم","يوم واحد",["يومان","يومين"],"%d أيام","%d يومًا","%d يوم"],M:["أقل من شهر","شهر واحد",["شهران","شهرين"],"%d أشهر","%d شهرا","%d شهر"],y:["أقل من عام","عام واحد",["عامان","عامين"],"%d أعوام","%d عامًا","%d عام"]}
,rt=function(n){
return function(t,i){
var u=bc(t),r=ak[n][bc(t)];
return u===2&&(r=r[i?0:1]),r.replace(/%d/i,t)}
}
,kc=["كانون الثاني يناير","شباط فبراير","آذار مارس","نيسان أبريل","أيار مايو","حزيران يونيو","تموز يوليو","آب أغسطس","أيلول سبتمبر","تشرين الأول أكتوبر","تشرين الثاني نوفمبر","كانون الأول ديسمبر"],en=n.defineLocale("ar",{
months:kc,monthsShort:kc,weekdays:"الأحد_الإثنين_الثلاثاء_الأربعاء_الخميس_الجمعة_السبت".split("_"),weekdaysShort:"أحد_إثنين_ثلاثاء_أربعاء_خميس_جمعة_سبت".split("_"),weekdaysMin:"ح_ن_ث_ر_خ_ج_س".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"D/‏M/‏YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,meridiemParse:/ص|م/,isPM:function(n){
return"م"===n}
,meridiem:function(n){
return n<12?"ص":"م"}
,calendar:{
sameDay:"[اليوم عند الساعة] LT",nextDay:"[غدًا عند الساعة] LT",nextWeek:"dddd [عند الساعة] LT",lastDay:"[أمس عند الساعة] LT",lastWeek:"dddd [عند الساعة] LT",sameElse:"L"}
,relativeTime:{
future:"بعد %s",past:"منذ %s",s:rt("s"),m:rt("m"),mm:rt("m"),h:rt("h"),hh:rt("h"),d:rt("d"),dd:rt("d"),M:rt("M"),MM:rt("M"),y:rt("y"),yy:rt("y")}
,preparse:function(n){
return n.replace(/\u200f/g,"").replace(/[١٢٣٤٥٦٧٨٩٠]/g,
function(n){
return lk[n]}
).replace(/،/g,",")}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return ck[n]}
).replace(/,/g,"،")}
,week:{
dow:6,doy:12}
}
),we={
1:"-inci",5:"-inci",8:"-inci",70:"-inci",80:"-inci",2:"-nci",7:"-nci",20:"-nci",50:"-nci",3:"-üncü",4:"-üncü",100:"-üncü",6:"-ncı",9:"-uncu",10:"-uncu",30:"-uncu",60:"-ıncı",90:"-ıncı"}
,on=n.defineLocale("az",{
months:"yanvar_fevral_mart_aprel_may_iyun_iyul_avqust_sentyabr_oktyabr_noyabr_dekabr".split("_"),monthsShort:"yan_fev_mar_apr_may_iyn_iyl_avq_sen_okt_noy_dek".split("_"),weekdays:"Bazar_Bazar ertəsi_Çərşənbə axşamı_Çərşənbə_Cümə axşamı_Cümə_Şənbə".split("_"),weekdaysShort:"Baz_BzE_ÇAx_Çər_CAx_Cüm_Şən".split("_"),weekdaysMin:"Bz_BE_ÇA_Çə_CA_Cü_Şə".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[bugün saat] LT",nextDay:"[sabah saat] LT",nextWeek:"[gələn həftə] dddd [saat] LT",lastDay:"[dünən] LT",lastWeek:"[keçən həftə] dddd [saat] LT",sameElse:"L"}
,relativeTime:{
future:"%s sonra",past:"%s əvvəl",s:"birneçə saniyyə",m:"bir dəqiqə",mm:"%d dəqiqə",h:"bir saat",hh:"%d saat",d:"bir gün",dd:"%d gün",M:"bir ay",MM:"%d ay",y:"bir il",yy:"%d il"}
,meridiemParse:/gecə|səhər|gündüz|axşam/,isPM:function(n){
return/^(gündüz|axşam)$/.test(n)}
,meridiem:function(n){
return n<4?"gecə":n<12?"səhər":n<17?"gündüz":"axşam"}
,ordinalParse:/\d{
1,2}
-(ıncı|inci|nci|üncü|ncı|uncu)/,ordinal:function(n){
if(n===0)return n+"-ıncı";
var t=n%10,i=n%100-t,r=n>=100?100:null;
return n+(we[t]||we[i]||we[r])}
,week:{
dow:1,doy:7}
}
);
var sn=n.defineLocale("be",{
months:{
format:"студзеня_лютага_сакавіка_красавіка_траўня_чэрвеня_ліпеня_жніўня_верасня_кастрычніка_лістапада_снежня".split("_"),standalone:"студзень_люты_сакавік_красавік_травень_чэрвень_ліпень_жнівень_верасень_кастрычнік_лістапад_снежань".split("_")}
,monthsShort:"студ_лют_сак_крас_трав_чэрв_ліп_жнів_вер_каст_ліст_снеж".split("_"),weekdays:{
format:"нядзелю_панядзелак_аўторак_сераду_чацвер_пятніцу_суботу".split("_"),standalone:"нядзеля_панядзелак_аўторак_серада_чацвер_пятніца_субота".split("_"),isFormat:/\[ ?[Вв] ?(?:мінулую|наступную)? ?\] ?dddd/}
,weekdaysShort:"нд_пн_ат_ср_чц_пт_сб".split("_"),weekdaysMin:"нд_пн_ат_ср_чц_пт_сб".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY г.",LLL:"D MMMM YYYY г., HH:mm",LLLL:"dddd, D MMMM YYYY г., HH:mm"}
,calendar:{
sameDay:"[Сёння ў] LT",nextDay:"[Заўтра ў] LT",lastDay:"[Учора ў] LT",nextWeek:function(){
return"[У] dddd [ў] LT"}
,lastWeek:function(){
switch(this.day()){
case 0:case 3:case 5:case 6:return"[У мінулую] dddd [ў] LT";
case 1:case 2:case 4:return"[У мінулы] dddd [ў] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"праз %s",past:"%s таму",s:"некалькі секунд",m:di,mm:di,h:di,hh:di,d:"дзень",dd:di,M:"месяц",MM:di,y:"год",yy:di}
,meridiemParse:/ночы|раніцы|дня|вечара/,isPM:function(n){
return/^(дня|вечара)$/.test(n)}
,meridiem:function(n){
return n<4?"ночы":n<12?"раніцы":n<17?"дня":"вечара"}
,ordinalParse:/\d{
1,2}
-(і|ы|га)/,ordinal:function(n,t){
switch(t){
case"M":case"d":case"DDD":case"w":case"W":return(n%10==2||n%10==3)&&n%100!=12&&n%100!=13?n+"-і":n+"-ы";
case"D":return n+"-га";
default:return n}
}
,week:{
dow:1,doy:7}
}
),hn=n.defineLocale("bg",{
months:"януари_февруари_март_април_май_юни_юли_август_септември_октомври_ноември_декември".split("_"),monthsShort:"янр_фев_мар_апр_май_юни_юли_авг_сеп_окт_ное_дек".split("_"),weekdays:"неделя_понеделник_вторник_сряда_четвъртък_петък_събота".split("_"),weekdaysShort:"нед_пон_вто_сря_чет_пет_съб".split("_"),weekdaysMin:"нд_пн_вт_ср_чт_пт_сб".split("_"),longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"D.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY H:mm",LLLL:"dddd, D MMMM YYYY H:mm"}
,calendar:{
sameDay:"[Днес в] LT",nextDay:"[Утре в] LT",nextWeek:"dddd [в] LT",lastDay:"[Вчера в] LT",lastWeek:function(){
switch(this.day()){
case 0:case 3:case 6:return"[В изминалата] dddd [в] LT";
case 1:case 2:case 4:case 5:return"[В изминалия] dddd [в] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"след %s",past:"преди %s",s:"няколко секунди",m:"минута",mm:"%d минути",h:"час",hh:"%d часа",d:"ден",dd:"%d дни",M:"месец",MM:"%d месеца",y:"година",yy:"%d години"}
,ordinalParse:/\d{
1,2}
-(ев|ен|ти|ви|ри|ми)/,ordinal:function(n){
var t=n%10,i=n%100;
return n===0?n+"-ев":i===0?n+"-ен":i>10&&i<20?n+"-ти":t===1?n+"-ви":t===2?n+"-ри":t===7||t===8?n+"-ми":n+"-ти"}
,week:{
dow:1,doy:7}
}
),yk={
"1":"১","2":"২","3":"৩","4":"৪","5":"৫","6":"৬","7":"৭","8":"৮","9":"৯","0":"০"}
,pk={
"১":"1","২":"2","৩":"3","৪":"4","৫":"5","৬":"6","৭":"7","৮":"8","৯":"9","০":"0"}
,cn=n.defineLocale("bn",{
months:"জানুয়ারী_ফেবুয়ারী_মার্চ_এপ্রিল_মে_জুন_জুলাই_অগাস্ট_সেপ্টেম্বর_অক্টোবর_নভেম্বর_ডিসেম্বর".split("_"),monthsShort:"জানু_ফেব_মার্চ_এপর_মে_জুন_জুল_অগ_সেপ্ট_অক্টো_নভ_ডিসেম্".split("_"),weekdays:"রবিবার_সোমবার_মঙ্গলবার_বুধবার_বৃহস্পত্তিবার_শুক্রবার_শনিবার".split("_"),weekdaysShort:"রবি_সোম_মঙ্গল_বুধ_বৃহস্পত্তি_শুক্র_শনি".split("_"),weekdaysMin:"রব_সম_মঙ্গ_বু_ব্রিহ_শু_শনি".split("_"),longDateFormat:{
LT:"A h:mm সময়",LTS:"A h:mm:ss সময়",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, A h:mm সময়",LLLL:"dddd, D MMMM YYYY, A h:mm সময়"}
,calendar:{
sameDay:"[আজ] LT",nextDay:"[আগামীকাল] LT",nextWeek:"dddd, LT",lastDay:"[গতকাল] LT",lastWeek:"[গত] dddd, LT",sameElse:"L"}
,relativeTime:{
future:"%s পরে",past:"%s আগে",s:"কয়েক সেকেন্ড",m:"এক মিনিট",mm:"%d মিনিট",h:"এক ঘন্টা",hh:"%d ঘন্টা",d:"এক দিন",dd:"%d দিন",M:"এক মাস",MM:"%d মাস",y:"এক বছর",yy:"%d বছর"}
,preparse:function(n){
return n.replace(/[১২৩৪৫৬৭৮৯০]/g,
function(n){
return pk[n]}
)}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return yk[n]}
)}
,meridiemParse:/রাত|সকাল|দুপুর|বিকাল|রাত/,meridiemHour:function(n,t){
return n===12&&(n=0),t==="রাত"&&n>=4||t==="দুপুর"&&n<5||t==="বিকাল"?n+12:n}
,meridiem:function(n){
return n<4?"রাত":n<10?"সকাল":n<17?"দুপুর":n<20?"বিকাল":"রাত"}
,week:{
dow:0,doy:6}
}
),wk={
"1":"༡","2":"༢","3":"༣","4":"༤","5":"༥","6":"༦","7":"༧","8":"༨","9":"༩","0":"༠"}
,bk={
"༡":"1","༢":"2","༣":"3","༤":"4","༥":"5","༦":"6","༧":"7","༨":"8","༩":"9","༠":"0"}
,ln=n.defineLocale("bo",{
months:"ཟླ་བ་དང་པོ_ཟླ་བ་གཉིས་པ_ཟླ་བ་གསུམ་པ_ཟླ་བ་བཞི་པ_ཟླ་བ་ལྔ་པ_ཟླ་བ་དྲུག་པ_ཟླ་བ་བདུན་པ_ཟླ་བ་བརྒྱད་པ_ཟླ་བ་དགུ་པ_ཟླ་བ་བཅུ་པ_ཟླ་བ་བཅུ་གཅིག་པ_ཟླ་བ་བཅུ་གཉིས་པ".split("_"),monthsShort:"ཟླ་བ་དང་པོ_ཟླ་བ་གཉིས་པ_ཟླ་བ་གསུམ་པ_ཟླ་བ་བཞི་པ_ཟླ་བ་ལྔ་པ_ཟླ་བ་དྲུག་པ_ཟླ་བ་བདུན་པ_ཟླ་བ་བརྒྱད་པ_ཟླ་བ་དགུ་པ_ཟླ་བ་བཅུ་པ_ཟླ་བ་བཅུ་གཅིག་པ_ཟླ་བ་བཅུ་གཉིས་པ".split("_"),weekdays:"གཟའ་ཉི་མ་_གཟའ་ཟླ་བ་_གཟའ་མིག་དམར་_གཟའ་ལྷག་པ་_གཟའ་ཕུར་བུ_གཟའ་པ་སངས་_གཟའ་སྤེན་པ་".split("_"),weekdaysShort:"ཉི་མ་_ཟླ་བ་_མིག་དམར་_ལྷག་པ་_ཕུར་བུ_པ་སངས་_སྤེན་པ་".split("_"),weekdaysMin:"ཉི་མ་_ཟླ་བ་_མིག་དམར་_ལྷག་པ་_ཕུར་བུ_པ་སངས་_སྤེན་པ་".split("_"),longDateFormat:{
LT:"A h:mm",LTS:"A h:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, A h:mm",LLLL:"dddd, D MMMM YYYY, A h:mm"}
,calendar:{
sameDay:"[དི་རིང] LT",nextDay:"[སང་ཉིན] LT",nextWeek:"[བདུན་ཕྲག་རྗེས་མ], LT",lastDay:"[ཁ་སང] LT",lastWeek:"[བདུན་ཕྲག་མཐའ་མ] dddd, LT",sameElse:"L"}
,relativeTime:{
future:"%s ལ་",past:"%s སྔན་ལ",s:"ལམ་སང",m:"སྐར་མ་གཅིག",mm:"%d སྐར་མ",h:"ཆུ་ཚོད་གཅིག",hh:"%d ཆུ་ཚོད",d:"ཉིན་གཅིག",dd:"%d ཉིན་",M:"ཟླ་བ་གཅིག",MM:"%d ཟླ་བ",y:"ལོ་གཅིག",yy:"%d ལོ"}
,preparse:function(n){
return n.replace(/[༡༢༣༤༥༦༧༨༩༠]/g,
function(n){
return bk[n]}
)}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return wk[n]}
)}
,meridiemParse:/མཚན་མོ|ཞོགས་ཀས|ཉིན་གུང|དགོང་དག|མཚན་མོ/,meridiemHour:function(n,t){
return n===12&&(n=0),t==="མཚན་མོ"&&n>=4||t==="ཉིན་གུང"&&n<5||t==="དགོང་དག"?n+12:n}
,meridiem:function(n){
return n<4?"མཚན་མོ":n<10?"ཞོགས་ཀས":n<17?"ཉིན་གུང":n<20?"དགོང་དག":"མཚན་མོ"}
,week:{
dow:0,doy:6}
}
);
nd=n.defineLocale("br",{
months:"Genver_C'hwevrer_Meurzh_Ebrel_Mae_Mezheven_Gouere_Eost_Gwengolo_Here_Du_Kerzu".split("_"),monthsShort:"Gen_C'hwe_Meu_Ebr_Mae_Eve_Gou_Eos_Gwe_Her_Du_Ker".split("_"),weekdays:"Sul_Lun_Meurzh_Merc'her_Yaou_Gwener_Sadorn".split("_"),weekdaysShort:"Sul_Lun_Meu_Mer_Yao_Gwe_Sad".split("_"),weekdaysMin:"Su_Lu_Me_Mer_Ya_Gw_Sa".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"h[e]mm A",LTS:"h[e]mm:ss A",L:"DD/MM/YYYY",LL:"D [a viz] MMMM YYYY",LLL:"D [a viz] MMMM YYYY h[e]mm A",LLLL:"dddd, D [a viz] MMMM YYYY h[e]mm A"}
,calendar:{
sameDay:"[Hiziv da] LT",nextDay:"[Warc'hoazh da] LT",nextWeek:"dddd [da] LT",lastDay:"[Dec'h da] LT",lastWeek:"dddd [paset da] LT",sameElse:"L"}
,relativeTime:{
future:"a-benn %s",past:"%s 'zo",s:"un nebeud segondennoù",m:"ur vunutenn",mm:be,h:"un eur",hh:"%d eur",d:"un devezh",dd:be,M:"ur miz",MM:be,y:"ur bloaz",yy:kk}
,ordinalParse:/\d{
1,2}
(añ|vet)/,ordinal:function(n){
var t=n===1?"añ":"vet";
return n+t}
,week:{
dow:1,doy:4}
}
);
var an=n.defineLocale("bs",{
months:"januar_februar_mart_april_maj_juni_juli_august_septembar_oktobar_novembar_decembar".split("_"),monthsShort:"jan._feb._mar._apr._maj._jun._jul._aug._sep._okt._nov._dec.".split("_"),monthsParseExact:!0,weekdays:"nedjelja_ponedjeljak_utorak_srijeda_četvrtak_petak_subota".split("_"),weekdaysShort:"ned._pon._uto._sri._čet._pet._sub.".split("_"),weekdaysMin:"ne_po_ut_sr_če_pe_su".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD. MM. YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd, D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[danas u] LT",nextDay:"[sutra u] LT",nextWeek:function(){
switch(this.day()){
case 0:return"[u] [nedjelju] [u] LT";
case 3:return"[u] [srijedu] [u] LT";
case 6:return"[u] [subotu] [u] LT";
case 1:case 2:case 4:case 5:return"[u] dddd [u] LT"}
}
,lastDay:"[jučer u] LT",lastWeek:function(){
switch(this.day()){
case 0:case 3:return"[prošlu] dddd [u] LT";
case 6:return"[prošle] [subote] [u] LT";
case 1:case 2:case 4:case 5:return"[prošli] dddd [u] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"za %s",past:"prije %s",s:"par sekundi",m:gi,mm:gi,h:gi,hh:gi,d:"dan",dd:gi,M:"mjesec",MM:gi,y:"godinu",yy:gi}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:7}
}
),vn=n.defineLocale("ca",{
months:"gener_febrer_març_abril_maig_juny_juliol_agost_setembre_octubre_novembre_desembre".split("_"),monthsShort:"gen._febr._mar._abr._mai._jun._jul._ag._set._oct._nov._des.".split("_"),monthsParseExact:!0,weekdays:"diumenge_dilluns_dimarts_dimecres_dijous_divendres_dissabte".split("_"),weekdaysShort:"dg._dl._dt._dc._dj._dv._ds.".split("_"),weekdaysMin:"Dg_Dl_Dt_Dc_Dj_Dv_Ds".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY H:mm",LLLL:"dddd D MMMM YYYY H:mm"}
,calendar:{
sameDay:function(){
return"[avui a "+(this.hours()!==1?"les":"la")+"] LT"}
,nextDay:function(){
return"[demà a "+(this.hours()!==1?"les":"la")+"] LT"}
,nextWeek:function(){
return"dddd [a "+(this.hours()!==1?"les":"la")+"] LT"}
,lastDay:function(){
return"[ahir a "+(this.hours()!==1?"les":"la")+"] LT"}
,lastWeek:function(){
return"[el] dddd [passat a "+(this.hours()!==1?"les":"la")+"] LT"}
,sameElse:"L"}
,relativeTime:{
future:"en %s",past:"fa %s",s:"uns segons",m:"un minut",mm:"%d minuts",h:"una hora",hh:"%d hores",d:"un dia",dd:"%d dies",M:"un mes",MM:"%d mesos",y:"un any",yy:"%d anys"}
,ordinalParse:/\d{
1,2}
(r|n|t|è|a)/,ordinal:function(n,t){
var i=n===1?"r":n===2?"n":n===3?"r":n===4?"t":"è";
return(t==="w"||t==="W")&&(i="a"),n+i}
,week:{
dow:1,doy:4}
}
),ke="leden_únor_březen_duben_květen_červen_červenec_srpen_září_říjen_listopad_prosinec".split("_"),de="led_úno_bře_dub_kvě_čvn_čvc_srp_zář_říj_lis_pro".split("_");
var yn=n.defineLocale("cs",{
months:ke,monthsShort:de,monthsParse:function(n,t){
for(var r=[],i=0;
i<12;
i++)r[i]=new RegExp("^"+n[i]+"$|^"+t[i]+"$","i");
return r}
(ke,de),shortMonthsParse:function(n){
for(var i=[],t=0;
t<12;
t++)i[t]=new RegExp("^"+n[t]+"$","i");
return i}
(de),longMonthsParse:function(n){
for(var i=[],t=0;
t<12;
t++)i[t]=new RegExp("^"+n[t]+"$","i");
return i}
(ke),weekdays:"neděle_pondělí_úterý_středa_čtvrtek_pátek_sobota".split("_"),weekdaysShort:"ne_po_út_st_čt_pá_so".split("_"),weekdaysMin:"ne_po_út_st_čt_pá_so".split("_"),longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[dnes v] LT",nextDay:"[zítra v] LT",nextWeek:function(){
switch(this.day()){
case 0:return"[v neděli v] LT";
case 1:case 2:return"[v] dddd [v] LT";
case 3:return"[ve středu v] LT";
case 4:return"[ve čtvrtek v] LT";
case 5:return"[v pátek v] LT";
case 6:return"[v sobotu v] LT"}
}
,lastDay:"[včera v] LT",lastWeek:function(){
switch(this.day()){
case 0:return"[minulou neděli v] LT";
case 1:case 2:return"[minulé] dddd [v] LT";
case 3:return"[minulou středu v] LT";
case 4:case 5:return"[minulý] dddd [v] LT";
case 6:return"[minulou sobotu v] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"za %s",past:"před %s",s:ut,m:ut,mm:ut,h:ut,hh:ut,d:ut,dd:ut,M:ut,MM:ut,y:ut,yy:ut}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),pn=n.defineLocale("cv",{
months:"кӑрлач_нарӑс_пуш_ака_май_ҫӗртме_утӑ_ҫурла_авӑн_юпа_чӳк_раштав".split("_"),monthsShort:"кӑр_нар_пуш_ака_май_ҫӗр_утӑ_ҫур_авн_юпа_чӳк_раш".split("_"),weekdays:"вырсарникун_тунтикун_ытларикун_юнкун_кӗҫнерникун_эрнекун_шӑматкун".split("_"),weekdaysShort:"выр_тун_ытл_юн_кӗҫ_эрн_шӑм".split("_"),weekdaysMin:"вр_тн_ыт_юн_кҫ_эр_шм".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD-MM-YYYY",LL:"YYYY [ҫулхи] MMMM [уйӑхӗн] D[-мӗшӗ]",LLL:"YYYY [ҫулхи] MMMM [уйӑхӗн] D[-мӗшӗ], HH:mm",LLLL:"dddd, YYYY [ҫулхи] MMMM [уйӑхӗн] D[-мӗшӗ], HH:mm"}
,calendar:{
sameDay:"[Паян] LT [сехетре]",nextDay:"[Ыран] LT [сехетре]",lastDay:"[Ӗнер] LT [сехетре]",nextWeek:"[Ҫитес] dddd LT [сехетре]",lastWeek:"[Иртнӗ] dddd LT [сехетре]",sameElse:"L"}
,relativeTime:{
future:function(n){
var t=/сехет$/i.exec(n)?"рен":/ҫул$/i.exec(n)?"тан":"ран";
return n+t}
,past:"%s каялла",s:"пӗр-ик ҫеккунт",m:"пӗр минут",mm:"%d минут",h:"пӗр сехет",hh:"%d сехет",d:"пӗр кун",dd:"%d кун",M:"пӗр уйӑх",MM:"%d уйӑх",y:"пӗр ҫул",yy:"%d ҫул"}
,ordinalParse:/\d{
1,2}
-мӗш/,ordinal:"%d-мӗш",week:{
dow:1,doy:7}
}
),wn=n.defineLocale("cy",{
months:"Ionawr_Chwefror_Mawrth_Ebrill_Mai_Mehefin_Gorffennaf_Awst_Medi_Hydref_Tachwedd_Rhagfyr".split("_"),monthsShort:"Ion_Chwe_Maw_Ebr_Mai_Meh_Gor_Aws_Med_Hyd_Tach_Rhag".split("_"),weekdays:"Dydd Sul_Dydd Llun_Dydd Mawrth_Dydd Mercher_Dydd Iau_Dydd Gwener_Dydd Sadwrn".split("_"),weekdaysShort:"Sul_Llun_Maw_Mer_Iau_Gwe_Sad".split("_"),weekdaysMin:"Su_Ll_Ma_Me_Ia_Gw_Sa".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Heddiw am] LT",nextDay:"[Yfory am] LT",nextWeek:"dddd [am] LT",lastDay:"[Ddoe am] LT",lastWeek:"dddd [diwethaf am] LT",sameElse:"L"}
,relativeTime:{
future:"mewn %s",past:"%s yn ôl",s:"ychydig eiliadau",m:"munud",mm:"%d munud",h:"awr",hh:"%d awr",d:"diwrnod",dd:"%d diwrnod",M:"mis",MM:"%d mis",y:"blwyddyn",yy:"%d flynedd"}
,ordinalParse:/\d{
1,2}
(fed|ain|af|il|ydd|ed|eg)/,ordinal:function(n){
var t=n,i="";
return t>20?i=t===40||t===50||t===60||t===80||t===100?"fed":"ain":t>0&&(i=["","af","il","ydd","ydd","ed","ed","ed","fed","fed","fed","eg","fed","eg","eg","fed","eg","eg","fed","eg","fed"][t]),n+i}
,week:{
dow:1,doy:4}
}
),bn=n.defineLocale("da",{
months:"januar_februar_marts_april_maj_juni_juli_august_september_oktober_november_december".split("_"),monthsShort:"jan_feb_mar_apr_maj_jun_jul_aug_sep_okt_nov_dec".split("_"),weekdays:"søndag_mandag_tirsdag_onsdag_torsdag_fredag_lørdag".split("_"),weekdaysShort:"søn_man_tir_ons_tor_fre_lør".split("_"),weekdaysMin:"sø_ma_ti_on_to_fr_lø".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY HH:mm",LLLL:"dddd [d.] D. MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[I dag kl.] LT",nextDay:"[I morgen kl.] LT",nextWeek:"dddd [kl.] LT",lastDay:"[I går kl.] LT",lastWeek:"[sidste] dddd [kl] LT",sameElse:"L"}
,relativeTime:{
future:"om %s",past:"%s siden",s:"få sekunder",m:"et minut",mm:"%d minutter",h:"en time",hh:"%d timer",d:"en dag",dd:"%d dage",M:"en måned",MM:"%d måneder",y:"et år",yy:"%d år"}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
);
td=n.defineLocale("de-at",{
months:"Jänner_Februar_März_April_Mai_Juni_Juli_August_September_Oktober_November_Dezember".split("_"),monthsShort:"Jän._Febr._Mrz._Apr._Mai_Jun._Jul._Aug._Sept._Okt._Nov._Dez.".split("_"),monthsParseExact:!0,weekdays:"Sonntag_Montag_Dienstag_Mittwoch_Donnerstag_Freitag_Samstag".split("_"),weekdaysShort:"So._Mo._Di._Mi._Do._Fr._Sa.".split("_"),weekdaysMin:"So_Mo_Di_Mi_Do_Fr_Sa".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY HH:mm",LLLL:"dddd, D. MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[heute um] LT [Uhr]",sameElse:"L",nextDay:"[morgen um] LT [Uhr]",nextWeek:"dddd [um] LT [Uhr]",lastDay:"[gestern um] LT [Uhr]",lastWeek:"[letzten] dddd [um] LT [Uhr]"}
,relativeTime:{
future:"in %s",past:"vor %s",s:"ein paar Sekunden",m:si,mm:"%d Minuten",h:si,hh:"%d Stunden",d:si,dd:si,M:si,MM:si,y:si,yy:si}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
);
var kn=n.defineLocale("de",{
months:"Januar_Februar_März_April_Mai_Juni_Juli_August_September_Oktober_November_Dezember".split("_"),monthsShort:"Jan._Febr._Mrz._Apr._Mai_Jun._Jul._Aug._Sept._Okt._Nov._Dez.".split("_"),monthsParseExact:!0,weekdays:"Sonntag_Montag_Dienstag_Mittwoch_Donnerstag_Freitag_Samstag".split("_"),weekdaysShort:"So._Mo._Di._Mi._Do._Fr._Sa.".split("_"),weekdaysMin:"So_Mo_Di_Mi_Do_Fr_Sa".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY HH:mm",LLLL:"dddd, D. MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[heute um] LT [Uhr]",sameElse:"L",nextDay:"[morgen um] LT [Uhr]",nextWeek:"dddd [um] LT [Uhr]",lastDay:"[gestern um] LT [Uhr]",lastWeek:"[letzten] dddd [um] LT [Uhr]"}
,relativeTime:{
future:"in %s",past:"vor %s",s:"ein paar Sekunden",m:hi,mm:"%d Minuten",h:hi,hh:"%d Stunden",d:hi,dd:hi,M:hi,MM:hi,y:hi,yy:hi}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),gc=["ޖެނުއަރީ","ފެބްރުއަރީ","މާރިޗު","އޭޕްރީލު","މޭ","ޖޫން","ޖުލައި","އޯގަސްޓު","ސެޕްޓެމްބަރު","އޮކްޓޯބަރު","ނޮވެމްބަރު","ޑިސެމްބަރު"],nl=["އާދިއްތަ","ހޯމަ","އަންގާރަ","ބުދަ","ބުރާސްފަތި","ހުކުރު","ހޮނިހިރު"],dn=n.defineLocale("dv",{
months:gc,monthsShort:gc,weekdays:nl,weekdaysShort:nl,weekdaysMin:"އާދި_ހޯމަ_އަން_ބުދަ_ބުރާ_ހުކު_ހޮނި".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"D/M/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,meridiemParse:/މކ|މފ/,isPM:function(n){
return"މފ"===n}
,meridiem:function(n){
return n<12?"މކ":"މފ"}
,calendar:{
sameDay:"[މިއަދު] LT",nextDay:"[މާދަމާ] LT",nextWeek:"dddd LT",lastDay:"[އިއްޔެ] LT",lastWeek:"[ފާއިތުވި] dddd LT",sameElse:"L"}
,relativeTime:{
future:"ތެރޭގައި %s",past:"ކުރިން %s",s:"ސިކުންތުކޮޅެއް",m:"މިނިޓެއް",mm:"މިނިޓު %d",h:"ގަޑިއިރެއް",hh:"ގަޑިއިރު %d",d:"ދުވަހެއް",dd:"ދުވަސް %d",M:"މަހެއް",MM:"މަސް %d",y:"އަހަރެއް",yy:"އަހަރު %d"}
,preparse:function(n){
return n.replace(/،/g,",")}
,postformat:function(n){
return n.replace(/,/g,"،")}
,week:{
dow:7,doy:12}
}
),gn=n.defineLocale("el",{
monthsNominativeEl:"Ιανουάριος_Φεβρουάριος_Μάρτιος_Απρίλιος_Μάιος_Ιούνιος_Ιούλιος_Αύγουστος_Σεπτέμβριος_Οκτώβριος_Νοέμβριος_Δεκέμβριος".split("_"),monthsGenitiveEl:"Ιανουαρίου_Φεβρουαρίου_Μαρτίου_Απριλίου_Μαΐου_Ιουνίου_Ιουλίου_Αυγούστου_Σεπτεμβρίου_Οκτωβρίου_Νοεμβρίου_Δεκεμβρίου".split("_"),months:function(n,t){
return/D/.test(t.substring(0,t.indexOf("MMMM")))?this._monthsGenitiveEl[n.month()]:this._monthsNominativeEl[n.month()]}
,monthsShort:"Ιαν_Φεβ_Μαρ_Απρ_Μαϊ_Ιουν_Ιουλ_Αυγ_Σεπ_Οκτ_Νοε_Δεκ".split("_"),weekdays:"Κυριακή_Δευτέρα_Τρίτη_Τετάρτη_Πέμπτη_Παρασκευή_Σάββατο".split("_"),weekdaysShort:"Κυρ_Δευ_Τρι_Τετ_Πεμ_Παρ_Σαβ".split("_"),weekdaysMin:"Κυ_Δε_Τρ_Τε_Πε_Πα_Σα".split("_"),meridiem:function(n,t,i){
return n>11?i?"μμ":"ΜΜ":i?"πμ":"ΠΜ"}
,isPM:function(n){
return(n+"").toLowerCase()[0]==="μ"}
,meridiemParse:/[ΠΜ]\.?Μ?\.?/i,longDateFormat:{
LT:"h:mm A",LTS:"h:mm:ss A",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY h:mm A",LLLL:"dddd, D MMMM YYYY h:mm A"}
,calendarEl:{
sameDay:"[Σήμερα {
}
] LT",nextDay:"[Αύριο {
}
] LT",nextWeek:"dddd [{
}
] LT",lastDay:"[Χθες {
}
] LT",lastWeek:function(){
switch(this.day()){
case 6:return"[το προηγούμενο] dddd [{
}
] LT";
default:return"[την προηγούμενη] dddd [{
}
] LT"}
}
,sameElse:"L"}
,calendar:function(n,t){
var i=this._calendarEl[n],r=t&&t.hours();
return wt(i)&&(i=i.apply(t)),i.replace("{
}
",r%12==1?"στη":"στις")}
,relativeTime:{
future:"σε %s",past:"%s πριν",s:"λίγα δευτερόλεπτα",m:"ένα λεπτό",mm:"%d λεπτά",h:"μία ώρα",hh:"%d ώρες",d:"μία μέρα",dd:"%d μέρες",M:"ένας μήνας",MM:"%d μήνες",y:"ένας χρόνος",yy:"%d χρόνια"}
,ordinalParse:/\d{
1,2}
η/,ordinal:"%dη",week:{
dow:1,doy:4}
}
),ntt=n.defineLocale("en-au",{
months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),monthsShort:"Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),weekdaysShort:"Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),weekdaysMin:"Su_Mo_Tu_We_Th_Fr_Sa".split("_"),longDateFormat:{
LT:"h:mm A",LTS:"h:mm:ss A",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY h:mm A",LLLL:"dddd, D MMMM YYYY h:mm A"}
,calendar:{
sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"}
,relativeTime:{
future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"}
,ordinalParse:/\d{
1,2}
(st|nd|rd|th)/,ordinal:function(n){
var t=n%10,i=~~(n%100/10)==1?"th":t===1?"st":t===2?"nd":t===3?"rd":"th";
return n+i}
,week:{
dow:1,doy:4}
}
),ttt=n.defineLocale("en-ca",{
months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),monthsShort:"Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),weekdaysShort:"Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),weekdaysMin:"Su_Mo_Tu_We_Th_Fr_Sa".split("_"),longDateFormat:{
LT:"h:mm A",LTS:"h:mm:ss A",L:"YYYY-MM-DD",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"}
,calendar:{
sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"}
,relativeTime:{
future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"}
,ordinalParse:/\d{
1,2}
(st|nd|rd|th)/,ordinal:function(n){
var t=n%10,i=~~(n%100/10)==1?"th":t===1?"st":t===2?"nd":t===3?"rd":"th";
return n+i}
}
),itt=n.defineLocale("en-gb",{
months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),monthsShort:"Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),weekdaysShort:"Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),weekdaysMin:"Su_Mo_Tu_We_Th_Fr_Sa".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"}
,relativeTime:{
future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"}
,ordinalParse:/\d{
1,2}
(st|nd|rd|th)/,ordinal:function(n){
var t=n%10,i=~~(n%100/10)==1?"th":t===1?"st":t===2?"nd":t===3?"rd":"th";
return n+i}
,week:{
dow:1,doy:4}
}
),rtt=n.defineLocale("en-ie",{
months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),monthsShort:"Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),weekdaysShort:"Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),weekdaysMin:"Su_Mo_Tu_We_Th_Fr_Sa".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD-MM-YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"}
,relativeTime:{
future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"}
,ordinalParse:/\d{
1,2}
(st|nd|rd|th)/,ordinal:function(n){
var t=n%10,i=~~(n%100/10)==1?"th":t===1?"st":t===2?"nd":t===3?"rd":"th";
return n+i}
,week:{
dow:1,doy:4}
}
),utt=n.defineLocale("en-nz",{
months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),monthsShort:"Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),weekdaysShort:"Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),weekdaysMin:"Su_Mo_Tu_We_Th_Fr_Sa".split("_"),longDateFormat:{
LT:"h:mm A",LTS:"h:mm:ss A",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY h:mm A",LLLL:"dddd, D MMMM YYYY h:mm A"}
,calendar:{
sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"}
,relativeTime:{
future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"}
,ordinalParse:/\d{
1,2}
(st|nd|rd|th)/,ordinal:function(n){
var t=n%10,i=~~(n%100/10)==1?"th":t===1?"st":t===2?"nd":t===3?"rd":"th";
return n+i}
,week:{
dow:1,doy:4}
}
),ftt=n.defineLocale("eo",{
months:"januaro_februaro_marto_aprilo_majo_junio_julio_aŭgusto_septembro_oktobro_novembro_decembro".split("_"),monthsShort:"jan_feb_mar_apr_maj_jun_jul_aŭg_sep_okt_nov_dec".split("_"),weekdays:"Dimanĉo_Lundo_Mardo_Merkredo_Ĵaŭdo_Vendredo_Sabato".split("_"),weekdaysShort:"Dim_Lun_Mard_Merk_Ĵaŭ_Ven_Sab".split("_"),weekdaysMin:"Di_Lu_Ma_Me_Ĵa_Ve_Sa".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"YYYY-MM-DD",LL:"D[-an de] MMMM, YYYY",LLL:"D[-an de] MMMM, YYYY HH:mm",LLLL:"dddd, [la] D[-an de] MMMM, YYYY HH:mm"}
,meridiemParse:/[ap]\.t\.m/i,isPM:function(n){
return n.charAt(0).toLowerCase()==="p"}
,meridiem:function(n,t,i){
return n>11?i?"p.t.m.":"P.T.M.":i?"a.t.m.":"A.T.M."}
,calendar:{
sameDay:"[Hodiaŭ je] LT",nextDay:"[Morgaŭ je] LT",nextWeek:"dddd [je] LT",lastDay:"[Hieraŭ je] LT",lastWeek:"[pasinta] dddd [je] LT",sameElse:"L"}
,relativeTime:{
future:"je %s",past:"antaŭ %s",s:"sekundoj",m:"minuto",mm:"%d minutoj",h:"horo",hh:"%d horoj",d:"tago",dd:"%d tagoj",M:"monato",MM:"%d monatoj",y:"jaro",yy:"%d jaroj"}
,ordinalParse:/\d{
1,2}
a/,ordinal:"%da",week:{
dow:1,doy:7}
}
),id="ene._feb._mar._abr._may._jun._jul._ago._sep._oct._nov._dic.".split("_"),rd="ene_feb_mar_abr_may_jun_jul_ago_sep_oct_nov_dic".split("_"),ett=n.defineLocale("es",{
months:"enero_febrero_marzo_abril_mayo_junio_julio_agosto_septiembre_octubre_noviembre_diciembre".split("_"),monthsShort:function(n,t){
return/-MMM-/.test(t)?rd[n.month()]:id[n.month()]}
,monthsParseExact:!0,weekdays:"domingo_lunes_martes_miércoles_jueves_viernes_sábado".split("_"),weekdaysShort:"dom._lun._mar._mié._jue._vie._sáb.".split("_"),weekdaysMin:"do_lu_ma_mi_ju_vi_sá".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD/MM/YYYY",LL:"D [de] MMMM [de] YYYY",LLL:"D [de] MMMM [de] YYYY H:mm",LLLL:"dddd, D [de] MMMM [de] YYYY H:mm"}
,calendar:{
sameDay:function(){
return"[hoy a la"+(this.hours()!==1?"s":"")+"] LT"}
,nextDay:function(){
return"[mañana a la"+(this.hours()!==1?"s":"")+"] LT"}
,nextWeek:function(){
return"dddd [a la"+(this.hours()!==1?"s":"")+"] LT"}
,lastDay:function(){
return"[ayer a la"+(this.hours()!==1?"s":"")+"] LT"}
,lastWeek:function(){
return"[el] dddd [pasado a la"+(this.hours()!==1?"s":"")+"] LT"}
,sameElse:"L"}
,relativeTime:{
future:"en %s",past:"hace %s",s:"unos segundos",m:"un minuto",mm:"%d minutos",h:"una hora",hh:"%d horas",d:"un día",dd:"%d días",M:"un mes",MM:"%d meses",y:"un año",yy:"%d años"}
,ordinalParse:/\d{
1,2}
º/,ordinal:"%dº",week:{
dow:1,doy:4}
}
);
var ott=n.defineLocale("et",{
months:"jaanuar_veebruar_märts_aprill_mai_juuni_juuli_august_september_oktoober_november_detsember".split("_"),monthsShort:"jaan_veebr_märts_apr_mai_juuni_juuli_aug_sept_okt_nov_dets".split("_"),weekdays:"pühapäev_esmaspäev_teisipäev_kolmapäev_neljapäev_reede_laupäev".split("_"),weekdaysShort:"P_E_T_K_N_R_L".split("_"),weekdaysMin:"P_E_T_K_N_R_L".split("_"),longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd, D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[Täna,] LT",nextDay:"[Homme,] LT",nextWeek:"[Järgmine] dddd LT",lastDay:"[Eile,] LT",lastWeek:"[Eelmine] dddd LT",sameElse:"L"}
,relativeTime:{
future:"%s pärast",past:"%s tagasi",s:yt,m:yt,mm:yt,h:yt,hh:yt,d:yt,dd:"%d päeva",M:yt,MM:yt,y:yt,yy:yt}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),stt=n.defineLocale("eu",{
months:"urtarrila_otsaila_martxoa_apirila_maiatza_ekaina_uztaila_abuztua_iraila_urria_azaroa_abendua".split("_"),monthsShort:"urt._ots._mar._api._mai._eka._uzt._abu._ira._urr._aza._abe.".split("_"),monthsParseExact:!0,weekdays:"igandea_astelehena_asteartea_asteazkena_osteguna_ostirala_larunbata".split("_"),weekdaysShort:"ig._al._ar._az._og._ol._lr.".split("_"),weekdaysMin:"ig_al_ar_az_og_ol_lr".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"YYYY-MM-DD",LL:"YYYY[ko] MMMM[ren] D[a]",LLL:"YYYY[ko] MMMM[ren] D[a] HH:mm",LLLL:"dddd, YYYY[ko] MMMM[ren] D[a] HH:mm",l:"YYYY-M-D",ll:"YYYY[ko] MMM D[a]",lll:"YYYY[ko] MMM D[a] HH:mm",llll:"ddd, YYYY[ko] MMM D[a] HH:mm"}
,calendar:{
sameDay:"[gaur] LT[etan]",nextDay:"[bihar] LT[etan]",nextWeek:"dddd LT[etan]",lastDay:"[atzo] LT[etan]",lastWeek:"[aurreko] dddd LT[etan]",sameElse:"L"}
,relativeTime:{
future:"%s barru",past:"duela %s",s:"segundo batzuk",m:"minutu bat",mm:"%d minutu",h:"ordu bat",hh:"%d ordu",d:"egun bat",dd:"%d egun",M:"hilabete bat",MM:"%d hilabete",y:"urte bat",yy:"%d urte"}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:7}
}
),ud={
"1":"۱","2":"۲","3":"۳","4":"۴","5":"۵","6":"۶","7":"۷","8":"۸","9":"۹","0":"۰"}
,fd={
"۱":"1","۲":"2","۳":"3","۴":"4","۵":"5","۶":"6","۷":"7","۸":"8","۹":"9","۰":"0"}
,htt=n.defineLocale("fa",{
months:"ژانویه_فوریه_مارس_آوریل_مه_ژوئن_ژوئیه_اوت_سپتامبر_اکتبر_نوامبر_دسامبر".split("_"),monthsShort:"ژانویه_فوریه_مارس_آوریل_مه_ژوئن_ژوئیه_اوت_سپتامبر_اکتبر_نوامبر_دسامبر".split("_"),weekdays:"یک‌شنبه_دوشنبه_سه‌شنبه_چهارشنبه_پنج‌شنبه_جمعه_شنبه".split("_"),weekdaysShort:"یک‌شنبه_دوشنبه_سه‌شنبه_چهارشنبه_پنج‌شنبه_جمعه_شنبه".split("_"),weekdaysMin:"ی_د_س_چ_پ_ج_ش".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,meridiemParse:/قبل از ظهر|بعد از ظهر/,isPM:function(n){
return/بعد از ظهر/.test(n)}
,meridiem:function(n){
return n<12?"قبل از ظهر":"بعد از ظهر"}
,calendar:{
sameDay:"[امروز ساعت] LT",nextDay:"[فردا ساعت] LT",nextWeek:"dddd [ساعت] LT",lastDay:"[دیروز ساعت] LT",lastWeek:"dddd [پیش] [ساعت] LT",sameElse:"L"}
,relativeTime:{
future:"در %s",past:"%s پیش",s:"چندین ثانیه",m:"یک دقیقه",mm:"%d دقیقه",h:"یک ساعت",hh:"%d ساعت",d:"یک روز",dd:"%d روز",M:"یک ماه",MM:"%d ماه",y:"یک سال",yy:"%d سال"}
,preparse:function(n){
return n.replace(/[۰-۹]/g,
function(n){
return fd[n]}
).replace(/،/g,",")}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return ud[n]}
).replace(/,/g,"،")}
,ordinalParse:/\d{
1,2}
م/,ordinal:"%dم",week:{
dow:6,doy:12}
}
),ef="nolla yksi kaksi kolme neljä viisi kuusi seitsemän kahdeksan yhdeksän".split(" "),ed=["nolla","yhden","kahden","kolmen","neljän","viiden","kuuden",ef[7],ef[8],ef[9]];
var ctt=n.defineLocale("fi",{
months:"tammikuu_helmikuu_maaliskuu_huhtikuu_toukokuu_kesäkuu_heinäkuu_elokuu_syyskuu_lokakuu_marraskuu_joulukuu".split("_"),monthsShort:"tammi_helmi_maalis_huhti_touko_kesä_heinä_elo_syys_loka_marras_joulu".split("_"),weekdays:"sunnuntai_maanantai_tiistai_keskiviikko_torstai_perjantai_lauantai".split("_"),weekdaysShort:"su_ma_ti_ke_to_pe_la".split("_"),weekdaysMin:"su_ma_ti_ke_to_pe_la".split("_"),longDateFormat:{
LT:"HH.mm",LTS:"HH.mm.ss",L:"DD.MM.YYYY",LL:"Do MMMM[ta] YYYY",LLL:"Do MMMM[ta] YYYY, [klo] HH.mm",LLLL:"dddd, Do MMMM[ta] YYYY, [klo] HH.mm",l:"D.M.YYYY",ll:"Do MMM YYYY",lll:"Do MMM YYYY, [klo] HH.mm",llll:"ddd, Do MMM YYYY, [klo] HH.mm"}
,calendar:{
sameDay:"[tänään] [klo] LT",nextDay:"[huomenna] [klo] LT",nextWeek:"dddd [klo] LT",lastDay:"[eilen] [klo] LT",lastWeek:"[viime] dddd[na] [klo] LT",sameElse:"L"}
,relativeTime:{
future:"%s päästä",past:"%s sitten",s:ft,m:ft,mm:ft,h:ft,hh:ft,d:ft,dd:ft,M:ft,MM:ft,y:ft,yy:ft}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),ltt=n.defineLocale("fo",{
months:"januar_februar_mars_apríl_mai_juni_juli_august_september_oktober_november_desember".split("_"),monthsShort:"jan_feb_mar_apr_mai_jun_jul_aug_sep_okt_nov_des".split("_"),weekdays:"sunnudagur_mánadagur_týsdagur_mikudagur_hósdagur_fríggjadagur_leygardagur".split("_"),weekdaysShort:"sun_mán_týs_mik_hós_frí_ley".split("_"),weekdaysMin:"su_má_tý_mi_hó_fr_le".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D. MMMM, YYYY HH:mm"}
,calendar:{
sameDay:"[Í dag kl.] LT",nextDay:"[Í morgin kl.] LT",nextWeek:"dddd [kl.] LT",lastDay:"[Í gjár kl.] LT",lastWeek:"[síðstu] dddd [kl] LT",sameElse:"L"}
,relativeTime:{
future:"um %s",past:"%s síðani",s:"fá sekund",m:"ein minutt",mm:"%d minuttir",h:"ein tími",hh:"%d tímar",d:"ein dagur",dd:"%d dagar",M:"ein mánaði",MM:"%d mánaðir",y:"eitt ár",yy:"%d ár"}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),att=n.defineLocale("fr-ca",{
months:"janvier_février_mars_avril_mai_juin_juillet_août_septembre_octobre_novembre_décembre".split("_"),monthsShort:"janv._févr._mars_avr._mai_juin_juil._août_sept._oct._nov._déc.".split("_"),monthsParseExact:!0,weekdays:"dimanche_lundi_mardi_mercredi_jeudi_vendredi_samedi".split("_"),weekdaysShort:"dim._lun._mar._mer._jeu._ven._sam.".split("_"),weekdaysMin:"Di_Lu_Ma_Me_Je_Ve_Sa".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"YYYY-MM-DD",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Aujourd'hui à] LT",nextDay:"[Demain à] LT",nextWeek:"dddd [à] LT",lastDay:"[Hier à] LT",lastWeek:"dddd [dernier à] LT",sameElse:"L"}
,relativeTime:{
future:"dans %s",past:"il y a %s",s:"quelques secondes",m:"une minute",mm:"%d minutes",h:"une heure",hh:"%d heures",d:"un jour",dd:"%d jours",M:"un mois",MM:"%d mois",y:"un an",yy:"%d ans"}
,ordinalParse:/\d{
1,2}
(er|e)/,ordinal:function(n){
return n+(n===1?"er":"e")}
}
),vtt=n.defineLocale("fr-ch",{
months:"janvier_février_mars_avril_mai_juin_juillet_août_septembre_octobre_novembre_décembre".split("_"),monthsShort:"janv._févr._mars_avr._mai_juin_juil._août_sept._oct._nov._déc.".split("_"),monthsParseExact:!0,weekdays:"dimanche_lundi_mardi_mercredi_jeudi_vendredi_samedi".split("_"),weekdaysShort:"dim._lun._mar._mer._jeu._ven._sam.".split("_"),weekdaysMin:"Di_Lu_Ma_Me_Je_Ve_Sa".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Aujourd'hui à] LT",nextDay:"[Demain à] LT",nextWeek:"dddd [à] LT",lastDay:"[Hier à] LT",lastWeek:"dddd [dernier à] LT",sameElse:"L"}
,relativeTime:{
future:"dans %s",past:"il y a %s",s:"quelques secondes",m:"une minute",mm:"%d minutes",h:"une heure",hh:"%d heures",d:"un jour",dd:"%d jours",M:"un mois",MM:"%d mois",y:"un an",yy:"%d ans"}
,ordinalParse:/\d{
1,2}
(er|e)/,ordinal:function(n){
return n+(n===1?"er":"e")}
,week:{
dow:1,doy:4}
}
),ytt=n.defineLocale("fr",{
months:"janvier_février_mars_avril_mai_juin_juillet_août_septembre_octobre_novembre_décembre".split("_"),monthsShort:"janv._févr._mars_avr._mai_juin_juil._août_sept._oct._nov._déc.".split("_"),monthsParseExact:!0,weekdays:"dimanche_lundi_mardi_mercredi_jeudi_vendredi_samedi".split("_"),weekdaysShort:"dim._lun._mar._mer._jeu._ven._sam.".split("_"),weekdaysMin:"Di_Lu_Ma_Me_Je_Ve_Sa".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Aujourd'hui à] LT",nextDay:"[Demain à] LT",nextWeek:"dddd [à] LT",lastDay:"[Hier à] LT",lastWeek:"dddd [dernier à] LT",sameElse:"L"}
,relativeTime:{
future:"dans %s",past:"il y a %s",s:"quelques secondes",m:"une minute",mm:"%d minutes",h:"une heure",hh:"%d heures",d:"un jour",dd:"%d jours",M:"un mois",MM:"%d mois",y:"un an",yy:"%d ans"}
,ordinalParse:/\d{
1,2}
(er|)/,ordinal:function(n){
return n+(n===1?"er":"")}
,week:{
dow:1,doy:4}
}
),sd="jan._feb._mrt._apr._mai_jun._jul._aug._sep._okt._nov._des.".split("_"),hd="jan_feb_mrt_apr_mai_jun_jul_aug_sep_okt_nov_des".split("_"),ptt=n.defineLocale("fy",{
months:"jannewaris_febrewaris_maart_april_maaie_juny_july_augustus_septimber_oktober_novimber_desimber".split("_"),monthsShort:function(n,t){
return/-MMM-/.test(t)?hd[n.month()]:sd[n.month()]}
,monthsParseExact:!0,weekdays:"snein_moandei_tiisdei_woansdei_tongersdei_freed_sneon".split("_"),weekdaysShort:"si._mo._ti._wo._to._fr._so.".split("_"),weekdaysMin:"Si_Mo_Ti_Wo_To_Fr_So".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD-MM-YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[hjoed om] LT",nextDay:"[moarn om] LT",nextWeek:"dddd [om] LT",lastDay:"[juster om] LT",lastWeek:"[ôfrûne] dddd [om] LT",sameElse:"L"}
,relativeTime:{
future:"oer %s",past:"%s lyn",s:"in pear sekonden",m:"ien minút",mm:"%d minuten",h:"ien oere",hh:"%d oeren",d:"ien dei",dd:"%d dagen",M:"ien moanne",MM:"%d moannen",y:"ien jier",yy:"%d jierren"}
,ordinalParse:/\d{
1,2}
(ste|de)/,ordinal:function(n){
return n+(n===1||n===8||n>=20?"ste":"de")}
,week:{
dow:1,doy:4}
}
),wtt=n.defineLocale("gd",{
months:["Am Faoilleach","An Gearran","Am Màrt","An Giblean","An Cèitean","An t-Ògmhios","An t-Iuchar","An Lùnastal","An t-Sultain","An Dàmhair","An t-Samhain","An Dùbhlachd"],monthsShort:["Faoi","Gear","Màrt","Gibl","Cèit","Ògmh","Iuch","Lùn","Sult","Dàmh","Samh","Dùbh"],monthsParseExact:!0,weekdays:["Didòmhnaich","Diluain","Dimàirt","Diciadain","Diardaoin","Dihaoine","Disathairne"],weekdaysShort:["Did","Dil","Dim","Dic","Dia","Dih","Dis"],weekdaysMin:["Dò","Lu","Mà","Ci","Ar","Ha","Sa"],longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[An-diugh aig] LT",nextDay:"[A-màireach aig] LT",nextWeek:"dddd [aig] LT",lastDay:"[An-dè aig] LT",lastWeek:"dddd [seo chaidh] [aig] LT",sameElse:"L"}
,relativeTime:{
future:"ann an %s",past:"bho chionn %s",s:"beagan diogan",m:"mionaid",mm:"%d mionaidean",h:"uair",hh:"%d uairean",d:"latha",dd:"%d latha",M:"mìos",MM:"%d mìosan",y:"bliadhna",yy:"%d bliadhna"}
,ordinalParse:/\d{
1,2}
(d|na|mh)/,ordinal:function(n){
var t=n===1?"d":n%10==2?"na":"mh";
return n+t}
,week:{
dow:1,doy:4}
}
),btt=n.defineLocale("gl",{
months:"Xaneiro_Febreiro_Marzo_Abril_Maio_Xuño_Xullo_Agosto_Setembro_Outubro_Novembro_Decembro".split("_"),monthsShort:"Xan._Feb._Mar._Abr._Mai._Xuñ._Xul._Ago._Set._Out._Nov._Dec.".split("_"),monthsParseExact:!0,weekdays:"Domingo_Luns_Martes_Mércores_Xoves_Venres_Sábado".split("_"),weekdaysShort:"Dom._Lun._Mar._Mér._Xov._Ven._Sáb.".split("_"),weekdaysMin:"Do_Lu_Ma_Mé_Xo_Ve_Sá".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY H:mm",LLLL:"dddd D MMMM YYYY H:mm"}
,calendar:{
sameDay:function(){
return"[hoxe "+(this.hours()!==1?"ás":"á")+"] LT"}
,nextDay:function(){
return"[mañá "+(this.hours()!==1?"ás":"á")+"] LT"}
,nextWeek:function(){
return"dddd ["+(this.hours()!==1?"ás":"a")+"] LT"}
,lastDay:function(){
return"[onte "+(this.hours()!==1?"á":"a")+"] LT"}
,lastWeek:function(){
return"[o] dddd [pasado "+(this.hours()!==1?"ás":"a")+"] LT"}
,sameElse:"L"}
,relativeTime:{
future:function(n){
return n==="uns segundos"?"nuns segundos":"en "+n}
,past:"hai %s",s:"uns segundos",m:"un minuto",mm:"%d minutos",h:"unha hora",hh:"%d horas",d:"un día",dd:"%d días",M:"un mes",MM:"%d meses",y:"un ano",yy:"%d anos"}
,ordinalParse:/\d{
1,2}
º/,ordinal:"%dº",week:{
dow:1,doy:7}
}
),ktt=n.defineLocale("he",{
months:"ינואר_פברואר_מרץ_אפריל_מאי_יוני_יולי_אוגוסט_ספטמבר_אוקטובר_נובמבר_דצמבר".split("_"),monthsShort:"ינו׳_פבר׳_מרץ_אפר׳_מאי_יוני_יולי_אוג׳_ספט׳_אוק׳_נוב׳_דצמ׳".split("_"),weekdays:"ראשון_שני_שלישי_רביעי_חמישי_שישי_שבת".split("_"),weekdaysShort:"א׳_ב׳_ג׳_ד׳_ה׳_ו׳_ש׳".split("_"),weekdaysMin:"א_ב_ג_ד_ה_ו_ש".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D [ב]MMMM YYYY",LLL:"D [ב]MMMM YYYY HH:mm",LLLL:"dddd, D [ב]MMMM YYYY HH:mm",l:"D/M/YYYY",ll:"D MMM YYYY",lll:"D MMM YYYY HH:mm",llll:"ddd, D MMM YYYY HH:mm"}
,calendar:{
sameDay:"[היום ב־]LT",nextDay:"[מחר ב־]LT",nextWeek:"dddd [בשעה] LT",lastDay:"[אתמול ב־]LT",lastWeek:"[ביום] dddd [האחרון בשעה] LT",sameElse:"L"}
,relativeTime:{
future:"בעוד %s",past:"לפני %s",s:"מספר שניות",m:"דקה",mm:"%d דקות",h:"שעה",hh:function(n){
return n===2?"שעתיים":n+" שעות"}
,d:"יום",dd:function(n){
return n===2?"יומיים":n+" ימים"}
,M:"חודש",MM:function(n){
return n===2?"חודשיים":n+" חודשים"}
,y:"שנה",yy:function(n){
return n===2?"שנתיים":n%10==0&&n!==10?n+" שנה":n+" שנים"}
}
,meridiemParse:/אחה"צ|לפנה"צ|אחרי הצהריים|לפני הצהריים|לפנות בוקר|בבוקר|בערב/i,isPM:function(n){
return/^(אחה"צ|אחרי הצהריים|בערב)$/.test(n)}
,meridiem:function(n,t,i){
return n<5?"לפנות בוקר":n<10?"בבוקר":n<12?i?'לפנה"צ':"לפני הצהריים":n<18?i?'אחה"צ':"אחרי הצהריים":"בערב"}
}
),cd={
"1":"१","2":"२","3":"३","4":"४","5":"५","6":"६","7":"७","8":"८","9":"९","0":"०"}
,ld={
"१":"1","२":"2","३":"3","४":"4","५":"5","६":"6","७":"7","८":"8","९":"9","०":"0"}
,dtt=n.defineLocale("hi",{
months:"जनवरी_फ़रवरी_मार्च_अप्रैल_मई_जून_जुलाई_अगस्त_सितम्बर_अक्टूबर_नवम्बर_दिसम्बर".split("_"),monthsShort:"जन._फ़र._मार्च_अप्रै._मई_जून_जुल._अग._सित._अक्टू._नव._दिस.".split("_"),monthsParseExact:!0,weekdays:"रविवार_सोमवार_मंगलवार_बुधवार_गुरूवार_शुक्रवार_शनिवार".split("_"),weekdaysShort:"रवि_सोम_मंगल_बुध_गुरू_शुक्र_शनि".split("_"),weekdaysMin:"र_सो_मं_बु_गु_शु_श".split("_"),longDateFormat:{
LT:"A h:mm बजे",LTS:"A h:mm:ss बजे",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, A h:mm बजे",LLLL:"dddd, D MMMM YYYY, A h:mm बजे"}
,calendar:{
sameDay:"[आज] LT",nextDay:"[कल] LT",nextWeek:"dddd, LT",lastDay:"[कल] LT",lastWeek:"[पिछले] dddd, LT",sameElse:"L"}
,relativeTime:{
future:"%s में",past:"%s पहले",s:"कुछ ही क्षण",m:"एक मिनट",mm:"%d मिनट",h:"एक घंटा",hh:"%d घंटे",d:"एक दिन",dd:"%d दिन",M:"एक महीने",MM:"%d महीने",y:"एक वर्ष",yy:"%d वर्ष"}
,preparse:function(n){
return n.replace(/[१२३४५६७८९०]/g,
function(n){
return ld[n]}
)}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return cd[n]}
)}
,meridiemParse:/रात|सुबह|दोपहर|शाम/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="रात")?n<4?n:n+12:t==="सुबह"?n:t==="दोपहर"?n>=10?n:n+12:t==="शाम"?n+12:void 0}
,meridiem:function(n){
return n<4?"रात":n<10?"सुबह":n<17?"दोपहर":n<20?"शाम":"रात"}
,week:{
dow:0,doy:6}
}
);
ad=n.defineLocale("hr",{
months:{
format:"siječnja_veljače_ožujka_travnja_svibnja_lipnja_srpnja_kolovoza_rujna_listopada_studenoga_prosinca".split("_"),standalone:"siječanj_veljača_ožujak_travanj_svibanj_lipanj_srpanj_kolovoz_rujan_listopad_studeni_prosinac".split("_")}
,monthsShort:"sij._velj._ožu._tra._svi._lip._srp._kol._ruj._lis._stu._pro.".split("_"),monthsParseExact:!0,weekdays:"nedjelja_ponedjeljak_utorak_srijeda_četvrtak_petak_subota".split("_"),weekdaysShort:"ned._pon._uto._sri._čet._pet._sub.".split("_"),weekdaysMin:"ne_po_ut_sr_če_pe_su".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD. MM. YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd, D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[danas u] LT",nextDay:"[sutra u] LT",nextWeek:function(){
switch(this.day()){
case 0:return"[u] [nedjelju] [u] LT";
case 3:return"[u] [srijedu] [u] LT";
case 6:return"[u] [subotu] [u] LT";
case 1:case 2:case 4:case 5:return"[u] dddd [u] LT"}
}
,lastDay:"[jučer u] LT",lastWeek:function(){
switch(this.day()){
case 0:case 3:return"[prošlu] dddd [u] LT";
case 6:return"[prošle] [subote] [u] LT";
case 1:case 2:case 4:case 5:return"[prošli] dddd [u] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"za %s",past:"prije %s",s:"par sekundi",m:nr,mm:nr,h:nr,hh:nr,d:"dan",dd:nr,M:"mjesec",MM:nr,y:"godinu",yy:nr}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:7}
}
);
tl="vasárnap hétfőn kedden szerdán csütörtökön pénteken szombaton".split(" ");
var gtt=n.defineLocale("hu",{
months:"január_február_március_április_május_június_július_augusztus_szeptember_október_november_december".split("_"),monthsShort:"jan_feb_márc_ápr_máj_jún_júl_aug_szept_okt_nov_dec".split("_"),weekdays:"vasárnap_hétfő_kedd_szerda_csütörtök_péntek_szombat".split("_"),weekdaysShort:"vas_hét_kedd_sze_csüt_pén_szo".split("_"),weekdaysMin:"v_h_k_sze_cs_p_szo".split("_"),longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"YYYY.MM.DD.",LL:"YYYY. MMMM D.",LLL:"YYYY. MMMM D. H:mm",LLLL:"YYYY. MMMM D., dddd H:mm"}
,meridiemParse:/de|du/i,isPM:function(n){
return n.charAt(1).toLowerCase()==="u"}
,meridiem:function(n,t,i){
return n<12?i===!0?"de":"DE":i===!0?"du":"DU"}
,calendar:{
sameDay:"[ma] LT[-kor]",nextDay:"[holnap] LT[-kor]",nextWeek:function(){
return il.call(this,!0)}
,lastDay:"[tegnap] LT[-kor]",lastWeek:function(){
return il.call(this,!1)}
,sameElse:"L"}
,relativeTime:{
future:"%s múlva",past:"%s",s:et,m:et,mm:et,h:et,hh:et,d:et,dd:et,M:et,MM:et,y:et,yy:et}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:7}
}
),nit=n.defineLocale("hy-am",{
months:{
format:"հունվարի_փետրվարի_մարտի_ապրիլի_մայիսի_հունիսի_հուլիսի_օգոստոսի_սեպտեմբերի_հոկտեմբերի_նոյեմբերի_դեկտեմբերի".split("_"),standalone:"հունվար_փետրվար_մարտ_ապրիլ_մայիս_հունիս_հուլիս_օգոստոս_սեպտեմբեր_հոկտեմբեր_նոյեմբեր_դեկտեմբեր".split("_")}
,monthsShort:"հնվ_փտր_մրտ_ապր_մյս_հնս_հլս_օգս_սպտ_հկտ_նմբ_դկտ".split("_"),weekdays:"կիրակի_երկուշաբթի_երեքշաբթի_չորեքշաբթի_հինգշաբթի_ուրբաթ_շաբաթ".split("_"),weekdaysShort:"կրկ_երկ_երք_չրք_հնգ_ուրբ_շբթ".split("_"),weekdaysMin:"կրկ_երկ_երք_չրք_հնգ_ուրբ_շբթ".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY թ.",LLL:"D MMMM YYYY թ., HH:mm",LLLL:"dddd, D MMMM YYYY թ., HH:mm"}
,calendar:{
sameDay:"[այսօր] LT",nextDay:"[վաղը] LT",lastDay:"[երեկ] LT",nextWeek:function(){
return"dddd [օրը ժամը] LT"}
,lastWeek:function(){
return"[անցած] dddd [օրը ժամը] LT"}
,sameElse:"L"}
,relativeTime:{
future:"%s հետո",past:"%s առաջ",s:"մի քանի վայրկյան",m:"րոպե",mm:"%d րոպե",h:"ժամ",hh:"%d ժամ",d:"օր",dd:"%d օր",M:"ամիս",MM:"%d ամիս",y:"տարի",yy:"%d տարի"}
,meridiemParse:/գիշերվա|առավոտվա|ցերեկվա|երեկոյան/,isPM:function(n){
return/^(ցերեկվա|երեկոյան)$/.test(n)}
,meridiem:function(n){
return n<4?"գիշերվա":n<12?"առավոտվա":n<17?"ցերեկվա":"երեկոյան"}
,ordinalParse:/\d{
1,2}
|\d{
1,2}
-(ին|րդ)/,ordinal:function(n,t){
switch(t){
case"DDD":case"w":case"W":case"DDDo":return n===1?n+"-ին":n+"-րդ";
default:return n}
}
,week:{
dow:1,doy:7}
}
),tit=n.defineLocale("id",{
months:"Januari_Februari_Maret_April_Mei_Juni_Juli_Agustus_September_Oktober_November_Desember".split("_"),monthsShort:"Jan_Feb_Mar_Apr_Mei_Jun_Jul_Ags_Sep_Okt_Nov_Des".split("_"),weekdays:"Minggu_Senin_Selasa_Rabu_Kamis_Jumat_Sabtu".split("_"),weekdaysShort:"Min_Sen_Sel_Rab_Kam_Jum_Sab".split("_"),weekdaysMin:"Mg_Sn_Sl_Rb_Km_Jm_Sb".split("_"),longDateFormat:{
LT:"HH.mm",LTS:"HH.mm.ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY [pukul] HH.mm",LLLL:"dddd, D MMMM YYYY [pukul] HH.mm"}
,meridiemParse:/pagi|siang|sore|malam/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="pagi")?n:t==="siang"?n>=11?n:n+12:t==="sore"||t==="malam"?n+12:void 0}
,meridiem:function(n){
return n<11?"pagi":n<15?"siang":n<19?"sore":"malam"}
,calendar:{
sameDay:"[Hari ini pukul] LT",nextDay:"[Besok pukul] LT",nextWeek:"dddd [pukul] LT",lastDay:"[Kemarin pukul] LT",lastWeek:"dddd [lalu pukul] LT",sameElse:"L"}
,relativeTime:{
future:"dalam %s",past:"%s yang lalu",s:"beberapa detik",m:"semenit",mm:"%d menit",h:"sejam",hh:"%d jam",d:"sehari",dd:"%d hari",M:"sebulan",MM:"%d bulan",y:"setahun",yy:"%d tahun"}
,week:{
dow:1,doy:7}
}
);
var iit=n.defineLocale("is",{
months:"janúar_febrúar_mars_apríl_maí_júní_júlí_ágúst_september_október_nóvember_desember".split("_"),monthsShort:"jan_feb_mar_apr_maí_jún_júl_ágú_sep_okt_nóv_des".split("_"),weekdays:"sunnudagur_mánudagur_þriðjudagur_miðvikudagur_fimmtudagur_föstudagur_laugardagur".split("_"),weekdaysShort:"sun_mán_þri_mið_fim_fös_lau".split("_"),weekdaysMin:"Su_Má_Þr_Mi_Fi_Fö_La".split("_"),longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY [kl.] H:mm",LLLL:"dddd, D. MMMM YYYY [kl.] H:mm"}
,calendar:{
sameDay:"[í dag kl.] LT",nextDay:"[á morgun kl.] LT",nextWeek:"dddd [kl.] LT",lastDay:"[í gær kl.] LT",lastWeek:"[síðasta] dddd [kl.] LT",sameElse:"L"}
,relativeTime:{
future:"eftir %s",past:"fyrir %s síðan",s:pt,m:pt,mm:pt,h:"klukkustund",hh:pt,d:pt,dd:pt,M:pt,MM:pt,y:pt,yy:pt}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),rit=n.defineLocale("it",{
months:"gennaio_febbraio_marzo_aprile_maggio_giugno_luglio_agosto_settembre_ottobre_novembre_dicembre".split("_"),monthsShort:"gen_feb_mar_apr_mag_giu_lug_ago_set_ott_nov_dic".split("_"),weekdays:"Domenica_Lunedì_Martedì_Mercoledì_Giovedì_Venerdì_Sabato".split("_"),weekdaysShort:"Dom_Lun_Mar_Mer_Gio_Ven_Sab".split("_"),weekdaysMin:"Do_Lu_Ma_Me_Gi_Ve_Sa".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Oggi alle] LT",nextDay:"[Domani alle] LT",nextWeek:"dddd [alle] LT",lastDay:"[Ieri alle] LT",lastWeek:function(){
switch(this.day()){
case 0:return"[la scorsa] dddd [alle] LT";
default:return"[lo scorso] dddd [alle] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:function(n){
return(/^[0-9].+$/.test(n)?"tra":"in")+" "+n}
,past:"%s fa",s:"alcuni secondi",m:"un minuto",mm:"%d minuti",h:"un'ora",hh:"%d ore",d:"un giorno",dd:"%d giorni",M:"un mese",MM:"%d mesi",y:"un anno",yy:"%d anni"}
,ordinalParse:/\d{
1,2}
º/,ordinal:"%dº",week:{
dow:1,doy:4}
}
),uit=n.defineLocale("ja",{
months:"1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月".split("_"),monthsShort:"1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月".split("_"),weekdays:"日曜日_月曜日_火曜日_水曜日_木曜日_金曜日_土曜日".split("_"),weekdaysShort:"日_月_火_水_木_金_土".split("_"),weekdaysMin:"日_月_火_水_木_金_土".split("_"),longDateFormat:{
LT:"Ah時m分",LTS:"Ah時m分s秒",L:"YYYY/MM/DD",LL:"YYYY年M月D日",LLL:"YYYY年M月D日Ah時m分",LLLL:"YYYY年M月D日Ah時m分 dddd"}
,meridiemParse:/午前|午後/i,isPM:function(n){
return n==="午後"}
,meridiem:function(n){
return n<12?"午前":"午後"}
,calendar:{
sameDay:"[今日] LT",nextDay:"[明日] LT",nextWeek:"[来週]dddd LT",lastDay:"[昨日] LT",lastWeek:"[前週]dddd LT",sameElse:"L"}
,ordinalParse:/\d{
1,2}
日/,ordinal:function(n,t){
switch(t){
case"d":case"D":case"DDD":return n+"日";
default:return n}
}
,relativeTime:{
future:"%s後",past:"%s前",s:"数秒",m:"1分",mm:"%d分",h:"1時間",hh:"%d時間",d:"1日",dd:"%d日",M:"1ヶ月",MM:"%dヶ月",y:"1年",yy:"%d年"}
}
),fit=n.defineLocale("jv",{
months:"Januari_Februari_Maret_April_Mei_Juni_Juli_Agustus_September_Oktober_Nopember_Desember".split("_"),monthsShort:"Jan_Feb_Mar_Apr_Mei_Jun_Jul_Ags_Sep_Okt_Nop_Des".split("_"),weekdays:"Minggu_Senen_Seloso_Rebu_Kemis_Jemuwah_Septu".split("_"),weekdaysShort:"Min_Sen_Sel_Reb_Kem_Jem_Sep".split("_"),weekdaysMin:"Mg_Sn_Sl_Rb_Km_Jm_Sp".split("_"),longDateFormat:{
LT:"HH.mm",LTS:"HH.mm.ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY [pukul] HH.mm",LLLL:"dddd, D MMMM YYYY [pukul] HH.mm"}
,meridiemParse:/enjing|siyang|sonten|ndalu/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="enjing")?n:t==="siyang"?n>=11?n:n+12:t==="sonten"||t==="ndalu"?n+12:void 0}
,meridiem:function(n){
return n<11?"enjing":n<15?"siyang":n<19?"sonten":"ndalu"}
,calendar:{
sameDay:"[Dinten puniko pukul] LT",nextDay:"[Mbenjang pukul] LT",nextWeek:"dddd [pukul] LT",lastDay:"[Kala wingi pukul] LT",lastWeek:"dddd [kepengker pukul] LT",sameElse:"L"}
,relativeTime:{
future:"wonten ing %s",past:"%s ingkang kepengker",s:"sawetawis detik",m:"setunggal menit",mm:"%d menit",h:"setunggal jam",hh:"%d jam",d:"sedinten",dd:"%d dinten",M:"sewulan",MM:"%d wulan",y:"setaun",yy:"%d taun"}
,week:{
dow:1,doy:7}
}
),eit=n.defineLocale("ka",{
months:{
standalone:"იანვარი_თებერვალი_მარტი_აპრილი_მაისი_ივნისი_ივლისი_აგვისტო_სექტემბერი_ოქტომბერი_ნოემბერი_დეკემბერი".split("_"),format:"იანვარს_თებერვალს_მარტს_აპრილის_მაისს_ივნისს_ივლისს_აგვისტს_სექტემბერს_ოქტომბერს_ნოემბერს_დეკემბერს".split("_")}
,monthsShort:"იან_თებ_მარ_აპრ_მაი_ივნ_ივლ_აგვ_სექ_ოქტ_ნოე_დეკ".split("_"),weekdays:{
standalone:"კვირა_ორშაბათი_სამშაბათი_ოთხშაბათი_ხუთშაბათი_პარასკევი_შაბათი".split("_"),format:"კვირას_ორშაბათს_სამშაბათს_ოთხშაბათს_ხუთშაბათს_პარასკევს_შაბათს".split("_"),isFormat:/(წინა|შემდეგ)/}
,weekdaysShort:"კვი_ორშ_სამ_ოთხ_ხუთ_პარ_შაბ".split("_"),weekdaysMin:"კვ_ორ_სა_ოთ_ხუ_პა_შა".split("_"),longDateFormat:{
LT:"h:mm A",LTS:"h:mm:ss A",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY h:mm A",LLLL:"dddd, D MMMM YYYY h:mm A"}
,calendar:{
sameDay:"[დღეს] LT[-ზე]",nextDay:"[ხვალ] LT[-ზე]",lastDay:"[გუშინ] LT[-ზე]",nextWeek:"[შემდეგ] dddd LT[-ზე]",lastWeek:"[წინა] dddd LT-ზე",sameElse:"L"}
,relativeTime:{
future:function(n){
return/(წამი|წუთი|საათი|წელი)/.test(n)?n.replace(/ი$/,"ში"):n+"ში"}
,past:function(n){
return/(წამი|წუთი|საათი|დღე|თვე)/.test(n)?n.replace(/(ი|ე)$/,"ის წინ"):/წელი/.test(n)?n.replace(/წელი$/,"წლის წინ"):void 0}
,s:"რამდენიმე წამი",m:"წუთი",mm:"%d წუთი",h:"საათი",hh:"%d საათი",d:"დღე",dd:"%d დღე",M:"თვე",MM:"%d თვე",y:"წელი",yy:"%d წელი"}
,ordinalParse:/0|1-ლი|მე-\d{
1,2}
|\d{
1,2}
-ე/,ordinal:function(n){
return n===0?n:n===1?n+"-ლი":n<20||n<=100&&n%20==0||n%100==0?"მე-"+n:n+"-ე"}
,week:{
dow:1,doy:7}
}
),ge={
0:"-ші",1:"-ші",2:"-ші",3:"-ші",4:"-ші",5:"-ші",6:"-шы",7:"-ші",8:"-ші",9:"-шы",10:"-шы",20:"-шы",30:"-шы",40:"-шы",50:"-ші",60:"-шы",70:"-ші",80:"-ші",90:"-шы",100:"-ші"}
,oit=n.defineLocale("kk",{
months:"қаңтар_ақпан_наурыз_сәуір_мамыр_маусым_шілде_тамыз_қыркүйек_қазан_қараша_желтоқсан".split("_"),monthsShort:"қаң_ақп_нау_сәу_мам_мау_шіл_там_қыр_қаз_қар_жел".split("_"),weekdays:"жексенбі_дүйсенбі_сейсенбі_сәрсенбі_бейсенбі_жұма_сенбі".split("_"),weekdaysShort:"жек_дүй_сей_сәр_бей_жұм_сен".split("_"),weekdaysMin:"жк_дй_сй_ср_бй_жм_сн".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Бүгін сағат] LT",nextDay:"[Ертең сағат] LT",nextWeek:"dddd [сағат] LT",lastDay:"[Кеше сағат] LT",lastWeek:"[Өткен аптаның] dddd [сағат] LT",sameElse:"L"}
,relativeTime:{
future:"%s ішінде",past:"%s бұрын",s:"бірнеше секунд",m:"бір минут",mm:"%d минут",h:"бір сағат",hh:"%d сағат",d:"бір күн",dd:"%d күн",M:"бір ай",MM:"%d ай",y:"бір жыл",yy:"%d жыл"}
,ordinalParse:/\d{
1,2}
-(ші|шы)/,ordinal:function(n){
var t=n%10,i=n>=100?100:null;
return n+(ge[n]||ge[t]||ge[i])}
,week:{
dow:1,doy:7}
}
),sit=n.defineLocale("km",{
months:"មករា_កុម្ភៈ_មីនា_មេសា_ឧសភា_មិថុនា_កក្កដា_សីហា_កញ្ញា_តុលា_វិច្ឆិកា_ធ្នូ".split("_"),monthsShort:"មករា_កុម្ភៈ_មីនា_មេសា_ឧសភា_មិថុនា_កក្កដា_សីហា_កញ្ញា_តុលា_វិច្ឆិកា_ធ្នូ".split("_"),weekdays:"អាទិត្យ_ច័ន្ទ_អង្គារ_ពុធ_ព្រហស្បតិ៍_សុក្រ_សៅរ៍".split("_"),weekdaysShort:"អាទិត្យ_ច័ន្ទ_អង្គារ_ពុធ_ព្រហស្បតិ៍_សុក្រ_សៅរ៍".split("_"),weekdaysMin:"អាទិត្យ_ច័ន្ទ_អង្គារ_ពុធ_ព្រហស្បតិ៍_សុក្រ_សៅរ៍".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[ថ្ងៃនេះ ម៉ោង] LT",nextDay:"[ស្អែក ម៉ោង] LT",nextWeek:"dddd [ម៉ោង] LT",lastDay:"[ម្សិលមិញ ម៉ោង] LT",lastWeek:"dddd [សប្តាហ៍មុន] [ម៉ោង] LT",sameElse:"L"}
,relativeTime:{
future:"%sទៀត",past:"%sមុន",s:"ប៉ុន្មានវិនាទី",m:"មួយនាទី",mm:"%d នាទី",h:"មួយម៉ោង",hh:"%d ម៉ោង",d:"មួយថ្ងៃ",dd:"%d ថ្ងៃ",M:"មួយខែ",MM:"%d ខែ",y:"មួយឆ្នាំ",yy:"%d ឆ្នាំ"}
,week:{
dow:1,doy:4}
}
),hit=n.defineLocale("ko",{
months:"1월_2월_3월_4월_5월_6월_7월_8월_9월_10월_11월_12월".split("_"),monthsShort:"1월_2월_3월_4월_5월_6월_7월_8월_9월_10월_11월_12월".split("_"),weekdays:"일요일_월요일_화요일_수요일_목요일_금요일_토요일".split("_"),weekdaysShort:"일_월_화_수_목_금_토".split("_"),weekdaysMin:"일_월_화_수_목_금_토".split("_"),longDateFormat:{
LT:"A h시 m분",LTS:"A h시 m분 s초",L:"YYYY.MM.DD",LL:"YYYY년 MMMM D일",LLL:"YYYY년 MMMM D일 A h시 m분",LLLL:"YYYY년 MMMM D일 dddd A h시 m분"}
,calendar:{
sameDay:"오늘 LT",nextDay:"내일 LT",nextWeek:"dddd LT",lastDay:"어제 LT",lastWeek:"지난주 dddd LT",sameElse:"L"}
,relativeTime:{
future:"%s 후",past:"%s 전",s:"몇 초",ss:"%d초",m:"일분",mm:"%d분",h:"한 시간",hh:"%d시간",d:"하루",dd:"%d일",M:"한 달",MM:"%d달",y:"일 년",yy:"%d년"}
,ordinalParse:/\d{
1,2}
일/,ordinal:"%d일",meridiemParse:/오전|오후/,isPM:function(n){
return n==="오후"}
,meridiem:function(n){
return n<12?"오전":"오후"}
}
),no={
0:"-чү",1:"-чи",2:"-чи",3:"-чү",4:"-чү",5:"-чи",6:"-чы",7:"-чи",8:"-чи",9:"-чу",10:"-чу",20:"-чы",30:"-чу",40:"-чы",50:"-чү",60:"-чы",70:"-чи",80:"-чи",90:"-чу",100:"-чү"}
,cit=n.defineLocale("ky",{
months:"январь_февраль_март_апрель_май_июнь_июль_август_сентябрь_октябрь_ноябрь_декабрь".split("_"),monthsShort:"янв_фев_март_апр_май_июнь_июль_авг_сен_окт_ноя_дек".split("_"),weekdays:"Жекшемби_Дүйшөмбү_Шейшемби_Шаршемби_Бейшемби_Жума_Ишемби".split("_"),weekdaysShort:"Жек_Дүй_Шей_Шар_Бей_Жум_Ише".split("_"),weekdaysMin:"Жк_Дй_Шй_Шр_Бй_Жм_Иш".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Бүгүн саат] LT",nextDay:"[Эртең саат] LT",nextWeek:"dddd [саат] LT",lastDay:"[Кече саат] LT",lastWeek:"[Өткен аптанын] dddd [күнү] [саат] LT",sameElse:"L"}
,relativeTime:{
future:"%s ичинде",past:"%s мурун",s:"бирнече секунд",m:"бир мүнөт",mm:"%d мүнөт",h:"бир саат",hh:"%d саат",d:"бир күн",dd:"%d күн",M:"бир ай",MM:"%d ай",y:"бир жыл",yy:"%d жыл"}
,ordinalParse:/\d{
1,2}
-(чи|чы|чү|чу)/,ordinal:function(n){
var t=n%10,i=n>=100?100:null;
return n+(no[n]||no[t]||no[i])}
,week:{
dow:1,doy:7}
}
);
var lit=n.defineLocale("lb",{
months:"Januar_Februar_Mäerz_Abrëll_Mee_Juni_Juli_August_September_Oktober_November_Dezember".split("_"),monthsShort:"Jan._Febr._Mrz._Abr._Mee_Jun._Jul._Aug._Sept._Okt._Nov._Dez.".split("_"),monthsParseExact:!0,weekdays:"Sonndeg_Méindeg_Dënschdeg_Mëttwoch_Donneschdeg_Freideg_Samschdeg".split("_"),weekdaysShort:"So._Mé._Dë._Më._Do._Fr._Sa.".split("_"),weekdaysMin:"So_Mé_Dë_Më_Do_Fr_Sa".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm [Auer]",LTS:"H:mm:ss [Auer]",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm [Auer]",LLLL:"dddd, D. MMMM YYYY H:mm [Auer]"}
,calendar:{
sameDay:"[Haut um] LT",sameElse:"L",nextDay:"[Muer um] LT",nextWeek:"dddd [um] LT",lastDay:"[Gëschter um] LT",lastWeek:function(){
switch(this.day()){
case 2:case 4:return"[Leschten] dddd [um] LT";
default:return"[Leschte] dddd [um] LT"}
}
}
,relativeTime:{
future:vd,past:yd,s:"e puer Sekonnen",m:dr,mm:"%d Minutten",h:dr,hh:"%d Stonnen",d:dr,dd:"%d Deeg",M:dr,MM:"%d Méint",y:dr,yy:"%d Joer"}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),ait=n.defineLocale("lo",{
months:"ມັງກອນ_ກຸມພາ_ມີນາ_ເມສາ_ພຶດສະພາ_ມິຖຸນາ_ກໍລະກົດ_ສິງຫາ_ກັນຍາ_ຕຸລາ_ພະຈິກ_ທັນວາ".split("_"),monthsShort:"ມັງກອນ_ກຸມພາ_ມີນາ_ເມສາ_ພຶດສະພາ_ມິຖຸນາ_ກໍລະກົດ_ສິງຫາ_ກັນຍາ_ຕຸລາ_ພະຈິກ_ທັນວາ".split("_"),weekdays:"ອາທິດ_ຈັນ_ອັງຄານ_ພຸດ_ພະຫັດ_ສຸກ_ເສົາ".split("_"),weekdaysShort:"ທິດ_ຈັນ_ອັງຄານ_ພຸດ_ພະຫັດ_ສຸກ_ເສົາ".split("_"),weekdaysMin:"ທ_ຈ_ອຄ_ພ_ພຫ_ສກ_ສ".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"ວັນdddd D MMMM YYYY HH:mm"}
,meridiemParse:/ຕອນເຊົ້າ|ຕອນແລງ/,isPM:function(n){
return n==="ຕອນແລງ"}
,meridiem:function(n){
return n<12?"ຕອນເຊົ້າ":"ຕອນແລງ"}
,calendar:{
sameDay:"[ມື້ນີ້ເວລາ] LT",nextDay:"[ມື້ອື່ນເວລາ] LT",nextWeek:"[ວັນ]dddd[ໜ້າເວລາ] LT",lastDay:"[ມື້ວານນີ້ເວລາ] LT",lastWeek:"[ວັນ]dddd[ແລ້ວນີ້ເວລາ] LT",sameElse:"L"}
,relativeTime:{
future:"ອີກ %s",past:"%sຜ່ານມາ",s:"ບໍ່ເທົ່າໃດວິນາທີ",m:"1 ນາທີ",mm:"%d ນາທີ",h:"1 ຊົ່ວໂມງ",hh:"%d ຊົ່ວໂມງ",d:"1 ມື້",dd:"%d ມື້",M:"1 ເດືອນ",MM:"%d ເດືອນ",y:"1 ປີ",yy:"%d ປີ"}
,ordinalParse:/(ທີ່)\d{
1,2}
/,ordinal:function(n){
return"ທີ່"+n}
}
),pd={
m:"minutė_minutės_minutę",mm:"minutės_minučių_minutes",h:"valanda_valandos_valandą",hh:"valandos_valandų_valandas",d:"diena_dienos_dieną",dd:"dienos_dienų_dienas",M:"mėnuo_mėnesio_mėnesį",MM:"mėnesiai_mėnesių_mėnesius",y:"metai_metų_metus",yy:"metai_metų_metus"}
;
bd=n.defineLocale("lt",{
months:{
format:"sausio_vasario_kovo_balandžio_gegužės_birželio_liepos_rugpjūčio_rugsėjo_spalio_lapkričio_gruodžio".split("_"),standalone:"sausis_vasaris_kovas_balandis_gegužė_birželis_liepa_rugpjūtis_rugsėjis_spalis_lapkritis_gruodis".split("_")}
,monthsShort:"sau_vas_kov_bal_geg_bir_lie_rgp_rgs_spa_lap_grd".split("_"),weekdays:{
format:"sekmadienį_pirmadienį_antradienį_trečiadienį_ketvirtadienį_penktadienį_šeštadienį".split("_"),standalone:"sekmadienis_pirmadienis_antradienis_trečiadienis_ketvirtadienis_penktadienis_šeštadienis".split("_"),isFormat:/dddd HH:mm/}
,weekdaysShort:"Sek_Pir_Ant_Tre_Ket_Pen_Šeš".split("_"),weekdaysMin:"S_P_A_T_K_Pn_Š".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"YYYY-MM-DD",LL:"YYYY [m.] MMMM D [d.]",LLL:"YYYY [m.] MMMM D [d.], HH:mm [val.]",LLLL:"YYYY [m.] MMMM D [d.], dddd, HH:mm [val.]",l:"YYYY-MM-DD",ll:"YYYY [m.] MMMM D [d.]",lll:"YYYY [m.] MMMM D [d.], HH:mm [val.]",llll:"YYYY [m.] MMMM D [d.], ddd, HH:mm [val.]"}
,calendar:{
sameDay:"[Šiandien] LT",nextDay:"[Rytoj] LT",nextWeek:"dddd LT",lastDay:"[Vakar] LT",lastWeek:"[Praėjusį] dddd LT",sameElse:"L"}
,relativeTime:{
future:"po %s",past:"prieš %s",s:wd,m:or,mm:gr,h:or,hh:gr,d:or,dd:gr,M:or,MM:gr,y:or,yy:gr}
,ordinalParse:/\d{
1,2}
-oji/,ordinal:function(n){
return n+"-oji"}
,week:{
dow:1,doy:4}
}
);
to={
m:"minūtes_minūtēm_minūte_minūtes".split("_"),mm:"minūtes_minūtēm_minūte_minūtes".split("_"),h:"stundas_stundām_stunda_stundas".split("_"),hh:"stundas_stundām_stunda_stundas".split("_"),d:"dienas_dienām_diena_dienas".split("_"),dd:"dienas_dienām_diena_dienas".split("_"),M:"mēneša_mēnešiem_mēnesis_mēneši".split("_"),MM:"mēneša_mēnešiem_mēnesis_mēneši".split("_"),y:"gada_gadiem_gads_gadi".split("_"),yy:"gada_gadiem_gads_gadi".split("_")}
;
var vit=n.defineLocale("lv",{
months:"janvāris_februāris_marts_aprīlis_maijs_jūnijs_jūlijs_augusts_septembris_oktobris_novembris_decembris".split("_"),monthsShort:"jan_feb_mar_apr_mai_jūn_jūl_aug_sep_okt_nov_dec".split("_"),weekdays:"svētdiena_pirmdiena_otrdiena_trešdiena_ceturtdiena_piektdiena_sestdiena".split("_"),weekdaysShort:"Sv_P_O_T_C_Pk_S".split("_"),weekdaysMin:"Sv_P_O_T_C_Pk_S".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY.",LL:"YYYY. [gada] D. MMMM",LLL:"YYYY. [gada] D. MMMM, HH:mm",LLLL:"YYYY. [gada] D. MMMM, dddd, HH:mm"}
,calendar:{
sameDay:"[Šodien pulksten] LT",nextDay:"[Rīt pulksten] LT",nextWeek:"dddd [pulksten] LT",lastDay:"[Vakar pulksten] LT",lastWeek:"[Pagājušā] dddd [pulksten] LT",sameElse:"L"}
,relativeTime:{
future:"pēc %s",past:"pirms %s",s:kd,m:tu,mm:nu,h:tu,hh:nu,d:tu,dd:nu,M:tu,MM:nu,y:tu,yy:nu}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),ni={
words:{
m:["jedan minut","jednog minuta"],mm:["minut","minuta","minuta"],h:["jedan sat","jednog sata"],hh:["sat","sata","sati"],dd:["dan","dana","dana"],MM:["mjesec","mjeseca","mjeseci"],yy:["godina","godine","godina"]}
,correctGrammaticalCase:function(n,t){
return n===1?t[0]:n>=2&&n<=4?t[1]:t[2]}
,translate:function(n,t,i){
var r=ni.words[i];
return i.length===1?t?r[0]:r[1]:n+" "+ni.correctGrammaticalCase(n,r)}
}
,yit=n.defineLocale("me",{
months:"januar_februar_mart_april_maj_jun_jul_avgust_septembar_oktobar_novembar_decembar".split("_"),monthsShort:"jan._feb._mar._apr._maj_jun_jul_avg._sep._okt._nov._dec.".split("_"),monthsParseExact:!0,weekdays:"nedjelja_ponedjeljak_utorak_srijeda_četvrtak_petak_subota".split("_"),weekdaysShort:"ned._pon._uto._sri._čet._pet._sub.".split("_"),weekdaysMin:"ne_po_ut_sr_če_pe_su".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD. MM. YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd, D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[danas u] LT",nextDay:"[sjutra u] LT",nextWeek:function(){
switch(this.day()){
case 0:return"[u] [nedjelju] [u] LT";
case 3:return"[u] [srijedu] [u] LT";
case 6:return"[u] [subotu] [u] LT";
case 1:case 2:case 4:case 5:return"[u] dddd [u] LT"}
}
,lastDay:"[juče u] LT",lastWeek:function(){
return["[prošle] [nedjelje] [u] LT","[prošlog] [ponedjeljka] [u] LT","[prošlog] [utorka] [u] LT","[prošle] [srijede] [u] LT","[prošlog] [četvrtka] [u] LT","[prošlog] [petka] [u] LT","[prošle] [subote] [u] LT"][this.day()]}
,sameElse:"L"}
,relativeTime:{
future:"za %s",past:"prije %s",s:"nekoliko sekundi",m:ni.translate,mm:ni.translate,h:ni.translate,hh:ni.translate,d:"dan",dd:ni.translate,M:"mjesec",MM:ni.translate,y:"godinu",yy:ni.translate}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:7}
}
),pit=n.defineLocale("mk",{
months:"јануари_февруари_март_април_мај_јуни_јули_август_септември_октомври_ноември_декември".split("_"),monthsShort:"јан_фев_мар_апр_мај_јун_јул_авг_сеп_окт_ное_дек".split("_"),weekdays:"недела_понеделник_вторник_среда_четврток_петок_сабота".split("_"),weekdaysShort:"нед_пон_вто_сре_чет_пет_саб".split("_"),weekdaysMin:"нe_пo_вт_ср_че_пе_сa".split("_"),longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"D.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY H:mm",LLLL:"dddd, D MMMM YYYY H:mm"}
,calendar:{
sameDay:"[Денес во] LT",nextDay:"[Утре во] LT",nextWeek:"[Во] dddd [во] LT",lastDay:"[Вчера во] LT",lastWeek:function(){
switch(this.day()){
case 0:case 3:case 6:return"[Изминатата] dddd [во] LT";
case 1:case 2:case 4:case 5:return"[Изминатиот] dddd [во] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"после %s",past:"пред %s",s:"неколку секунди",m:"минута",mm:"%d минути",h:"час",hh:"%d часа",d:"ден",dd:"%d дена",M:"месец",MM:"%d месеци",y:"година",yy:"%d години"}
,ordinalParse:/\d{
1,2}
-(ев|ен|ти|ви|ри|ми)/,ordinal:function(n){
var t=n%10,i=n%100;
return n===0?n+"-ев":i===0?n+"-ен":i>10&&i<20?n+"-ти":t===1?n+"-ви":t===2?n+"-ри":t===7||t===8?n+"-ми":n+"-ти"}
,week:{
dow:1,doy:7}
}
),wit=n.defineLocale("ml",{
months:"ജനുവരി_ഫെബ്രുവരി_മാർച്ച്_ഏപ്രിൽ_മേയ്_ജൂൺ_ജൂലൈ_ഓഗസ്റ്റ്_സെപ്റ്റംബർ_ഒക്ടോബർ_നവംബർ_ഡിസംബർ".split("_"),monthsShort:"ജനു._ഫെബ്രു._മാർ._ഏപ്രി._മേയ്_ജൂൺ_ജൂലൈ._ഓഗ._സെപ്റ്റ._ഒക്ടോ._നവം._ഡിസം.".split("_"),monthsParseExact:!0,weekdays:"ഞായറാഴ്ച_തിങ്കളാഴ്ച_ചൊവ്വാഴ്ച_ബുധനാഴ്ച_വ്യാഴാഴ്ച_വെള്ളിയാഴ്ച_ശനിയാഴ്ച".split("_"),weekdaysShort:"ഞായർ_തിങ്കൾ_ചൊവ്വ_ബുധൻ_വ്യാഴം_വെള്ളി_ശനി".split("_"),weekdaysMin:"ഞാ_തി_ചൊ_ബു_വ്യാ_വെ_ശ".split("_"),longDateFormat:{
LT:"A h:mm -നു",LTS:"A h:mm:ss -നു",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, A h:mm -നു",LLLL:"dddd, D MMMM YYYY, A h:mm -നു"}
,calendar:{
sameDay:"[ഇന്ന്] LT",nextDay:"[നാളെ] LT",nextWeek:"dddd, LT",lastDay:"[ഇന്നലെ] LT",lastWeek:"[കഴിഞ്ഞ] dddd, LT",sameElse:"L"}
,relativeTime:{
future:"%s കഴിഞ്ഞ്",past:"%s മുൻപ്",s:"അൽപ നിമിഷങ്ങൾ",m:"ഒരു മിനിറ്റ്",mm:"%d മിനിറ്റ്",h:"ഒരു മണിക്കൂർ",hh:"%d മണിക്കൂർ",d:"ഒരു ദിവസം",dd:"%d ദിവസം",M:"ഒരു മാസം",MM:"%d മാസം",y:"ഒരു വർഷം",yy:"%d വർഷം"}
,meridiemParse:/രാത്രി|രാവിലെ|ഉച്ച കഴിഞ്ഞ്|വൈകുന്നേരം|രാത്രി/i,meridiemHour:function(n,t){
return n===12&&(n=0),t==="രാത്രി"&&n>=4||t==="ഉച്ച കഴിഞ്ഞ്"||t==="വൈകുന്നേരം"?n+12:n}
,meridiem:function(n){
return n<4?"രാത്രി":n<12?"രാവിലെ":n<17?"ഉച്ച കഴിഞ്ഞ്":n<20?"വൈകുന്നേരം":"രാത്രി"}
}
),dd={
"1":"१","2":"२","3":"३","4":"४","5":"५","6":"६","7":"७","8":"८","9":"९","0":"०"}
,gd={
"१":"1","२":"2","३":"3","४":"4","५":"5","६":"6","७":"7","८":"8","९":"9","०":"0"}
;
var bit=n.defineLocale("mr",{
months:"जानेवारी_फेब्रुवारी_मार्च_एप्रिल_मे_जून_जुलै_ऑगस्ट_सप्टेंबर_ऑक्टोबर_नोव्हेंबर_डिसेंबर".split("_"),monthsShort:"जाने._फेब्रु._मार्च._एप्रि._मे._जून._जुलै._ऑग._सप्टें._ऑक्टो._नोव्हें._डिसें.".split("_"),monthsParseExact:!0,weekdays:"रविवार_सोमवार_मंगळवार_बुधवार_गुरूवार_शुक्रवार_शनिवार".split("_"),weekdaysShort:"रवि_सोम_मंगळ_बुध_गुरू_शुक्र_शनि".split("_"),weekdaysMin:"र_सो_मं_बु_गु_शु_श".split("_"),longDateFormat:{
LT:"A h:mm वाजता",LTS:"A h:mm:ss वाजता",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, A h:mm वाजता",LLLL:"dddd, D MMMM YYYY, A h:mm वाजता"}
,calendar:{
sameDay:"[आज] LT",nextDay:"[उद्या] LT",nextWeek:"dddd, LT",lastDay:"[काल] LT",lastWeek:"[मागील] dddd, LT",sameElse:"L"}
,relativeTime:{
future:"%sमध्ये",past:"%sपूर्वी",s:ot,m:ot,mm:ot,h:ot,hh:ot,d:ot,dd:ot,M:ot,MM:ot,y:ot,yy:ot}
,preparse:function(n){
return n.replace(/[१२३४५६७८९०]/g,
function(n){
return gd[n]}
)}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return dd[n]}
)}
,meridiemParse:/रात्री|सकाळी|दुपारी|सायंकाळी/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="रात्री")?n<4?n:n+12:t==="सकाळी"?n:t==="दुपारी"?n>=10?n:n+12:t==="सायंकाळी"?n+12:void 0}
,meridiem:function(n){
return n<4?"रात्री":n<10?"सकाळी":n<17?"दुपारी":n<20?"सायंकाळी":"रात्री"}
,week:{
dow:0,doy:6}
}
),kit=n.defineLocale("ms-my",{
months:"Januari_Februari_Mac_April_Mei_Jun_Julai_Ogos_September_Oktober_November_Disember".split("_"),monthsShort:"Jan_Feb_Mac_Apr_Mei_Jun_Jul_Ogs_Sep_Okt_Nov_Dis".split("_"),weekdays:"Ahad_Isnin_Selasa_Rabu_Khamis_Jumaat_Sabtu".split("_"),weekdaysShort:"Ahd_Isn_Sel_Rab_Kha_Jum_Sab".split("_"),weekdaysMin:"Ah_Is_Sl_Rb_Km_Jm_Sb".split("_"),longDateFormat:{
LT:"HH.mm",LTS:"HH.mm.ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY [pukul] HH.mm",LLLL:"dddd, D MMMM YYYY [pukul] HH.mm"}
,meridiemParse:/pagi|tengahari|petang|malam/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="pagi")?n:t==="tengahari"?n>=11?n:n+12:t==="petang"||t==="malam"?n+12:void 0}
,meridiem:function(n){
return n<11?"pagi":n<15?"tengahari":n<19?"petang":"malam"}
,calendar:{
sameDay:"[Hari ini pukul] LT",nextDay:"[Esok pukul] LT",nextWeek:"dddd [pukul] LT",lastDay:"[Kelmarin pukul] LT",lastWeek:"dddd [lepas pukul] LT",sameElse:"L"}
,relativeTime:{
future:"dalam %s",past:"%s yang lepas",s:"beberapa saat",m:"seminit",mm:"%d minit",h:"sejam",hh:"%d jam",d:"sehari",dd:"%d hari",M:"sebulan",MM:"%d bulan",y:"setahun",yy:"%d tahun"}
,week:{
dow:1,doy:7}
}
),dit=n.defineLocale("ms",{
months:"Januari_Februari_Mac_April_Mei_Jun_Julai_Ogos_September_Oktober_November_Disember".split("_"),monthsShort:"Jan_Feb_Mac_Apr_Mei_Jun_Jul_Ogs_Sep_Okt_Nov_Dis".split("_"),weekdays:"Ahad_Isnin_Selasa_Rabu_Khamis_Jumaat_Sabtu".split("_"),weekdaysShort:"Ahd_Isn_Sel_Rab_Kha_Jum_Sab".split("_"),weekdaysMin:"Ah_Is_Sl_Rb_Km_Jm_Sb".split("_"),longDateFormat:{
LT:"HH.mm",LTS:"HH.mm.ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY [pukul] HH.mm",LLLL:"dddd, D MMMM YYYY [pukul] HH.mm"}
,meridiemParse:/pagi|tengahari|petang|malam/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="pagi")?n:t==="tengahari"?n>=11?n:n+12:t==="petang"||t==="malam"?n+12:void 0}
,meridiem:function(n){
return n<11?"pagi":n<15?"tengahari":n<19?"petang":"malam"}
,calendar:{
sameDay:"[Hari ini pukul] LT",nextDay:"[Esok pukul] LT",nextWeek:"dddd [pukul] LT",lastDay:"[Kelmarin pukul] LT",lastWeek:"dddd [lepas pukul] LT",sameElse:"L"}
,relativeTime:{
future:"dalam %s",past:"%s yang lepas",s:"beberapa saat",m:"seminit",mm:"%d minit",h:"sejam",hh:"%d jam",d:"sehari",dd:"%d hari",M:"sebulan",MM:"%d bulan",y:"setahun",yy:"%d tahun"}
,week:{
dow:1,doy:7}
}
),ng={
"1":"၁","2":"၂","3":"၃","4":"၄","5":"၅","6":"၆","7":"၇","8":"၈","9":"၉","0":"၀"}
,tg={
"၁":"1","၂":"2","၃":"3","၄":"4","၅":"5","၆":"6","၇":"7","၈":"8","၉":"9","၀":"0"}
,git=n.defineLocale("my",{
months:"ဇန်နဝါရီ_ဖေဖော်ဝါရီ_မတ်_ဧပြီ_မေ_ဇွန်_ဇူလိုင်_သြဂုတ်_စက်တင်ဘာ_အောက်တိုဘာ_နိုဝင်ဘာ_ဒီဇင်ဘာ".split("_"),monthsShort:"ဇန်_ဖေ_မတ်_ပြီ_မေ_ဇွန်_လိုင်_သြ_စက်_အောက်_နို_ဒီ".split("_"),weekdays:"တနင်္ဂနွေ_တနင်္လာ_အင်္ဂါ_ဗုဒ္ဓဟူး_ကြာသပတေး_သောကြာ_စနေ".split("_"),weekdaysShort:"နွေ_လာ_ဂါ_ဟူး_ကြာ_သော_နေ".split("_"),weekdaysMin:"နွေ_လာ_ဂါ_ဟူး_ကြာ_သော_နေ".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[ယနေ.] LT [မှာ]",nextDay:"[မနက်ဖြန်] LT [မှာ]",nextWeek:"dddd LT [မှာ]",lastDay:"[မနေ.က] LT [မှာ]",lastWeek:"[ပြီးခဲ့သော] dddd LT [မှာ]",sameElse:"L"}
,relativeTime:{
future:"လာမည့် %s မှာ",past:"လွန်ခဲ့သော %s က",s:"စက္ကန်.အနည်းငယ်",m:"တစ်မိနစ်",mm:"%d မိနစ်",h:"တစ်နာရီ",hh:"%d နာရီ",d:"တစ်ရက်",dd:"%d ရက်",M:"တစ်လ",MM:"%d လ",y:"တစ်နှစ်",yy:"%d နှစ်"}
,preparse:function(n){
return n.replace(/[၁၂၃၄၅၆၇၈၉၀]/g,
function(n){
return tg[n]}
)}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return ng[n]}
)}
,week:{
dow:1,doy:4}
}
),nrt=n.defineLocale("nb",{
months:"januar_februar_mars_april_mai_juni_juli_august_september_oktober_november_desember".split("_"),monthsShort:"jan._feb._mars_april_mai_juni_juli_aug._sep._okt._nov._des.".split("_"),monthsParseExact:!0,weekdays:"søndag_mandag_tirsdag_onsdag_torsdag_fredag_lørdag".split("_"),weekdaysShort:"sø._ma._ti._on._to._fr._lø.".split("_"),weekdaysMin:"sø_ma_ti_on_to_fr_lø".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY [kl.] HH:mm",LLLL:"dddd D. MMMM YYYY [kl.] HH:mm"}
,calendar:{
sameDay:"[i dag kl.] LT",nextDay:"[i morgen kl.] LT",nextWeek:"dddd [kl.] LT",lastDay:"[i går kl.] LT",lastWeek:"[forrige] dddd [kl.] LT",sameElse:"L"}
,relativeTime:{
future:"om %s",past:"%s siden",s:"noen sekunder",m:"ett minutt",mm:"%d minutter",h:"en time",hh:"%d timer",d:"en dag",dd:"%d dager",M:"en måned",MM:"%d måneder",y:"ett år",yy:"%d år"}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),ig={
"1":"१","2":"२","3":"३","4":"४","5":"५","6":"६","7":"७","8":"८","9":"९","0":"०"}
,rg={
"१":"1","२":"2","३":"3","४":"4","५":"5","६":"6","७":"7","८":"8","९":"9","०":"0"}
,trt=n.defineLocale("ne",{
months:"जनवरी_फेब्रुवरी_मार्च_अप्रिल_मई_जुन_जुलाई_अगष्ट_सेप्टेम्बर_अक्टोबर_नोभेम्बर_डिसेम्बर".split("_"),monthsShort:"जन._फेब्रु._मार्च_अप्रि._मई_जुन_जुलाई._अग._सेप्ट._अक्टो._नोभे._डिसे.".split("_"),monthsParseExact:!0,weekdays:"आइतबार_सोमबार_मङ्गलबार_बुधबार_बिहिबार_शुक्रबार_शनिबार".split("_"),weekdaysShort:"आइत._सोम._मङ्गल._बुध._बिहि._शुक्र._शनि.".split("_"),weekdaysMin:"आ._सो._मं._बु._बि._शु._श.".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"Aको h:mm बजे",LTS:"Aको h:mm:ss बजे",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, Aको h:mm बजे",LLLL:"dddd, D MMMM YYYY, Aको h:mm बजे"}
,preparse:function(n){
return n.replace(/[१२३४५६७८९०]/g,
function(n){
return rg[n]}
)}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return ig[n]}
)}
,meridiemParse:/राति|बिहान|दिउँसो|साँझ/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="राति")?n<4?n:n+12:t==="बिहान"?n:t==="दिउँसो"?n>=10?n:n+12:t==="साँझ"?n+12:void 0}
,meridiem:function(n){
return n<3?"राति":n<12?"बिहान":n<16?"दिउँसो":n<20?"साँझ":"राति"}
,calendar:{
sameDay:"[आज] LT",nextDay:"[भोलि] LT",nextWeek:"[आउँदो] dddd[,] LT",lastDay:"[हिजो] LT",lastWeek:"[गएको] dddd[,] LT",sameElse:"L"}
,relativeTime:{
future:"%sमा",past:"%s अगाडि",s:"केही क्षण",m:"एक मिनेट",mm:"%d मिनेट",h:"एक घण्टा",hh:"%d घण्टा",d:"एक दिन",dd:"%d दिन",M:"एक महिना",MM:"%d महिना",y:"एक बर्ष",yy:"%d बर्ष"}
,week:{
dow:0,doy:6}
}
),ug="jan._feb._mrt._apr._mei_jun._jul._aug._sep._okt._nov._dec.".split("_"),fg="jan_feb_mrt_apr_mei_jun_jul_aug_sep_okt_nov_dec".split("_"),irt=n.defineLocale("nl",{
months:"januari_februari_maart_april_mei_juni_juli_augustus_september_oktober_november_december".split("_"),monthsShort:function(n,t){
return/-MMM-/.test(t)?fg[n.month()]:ug[n.month()]}
,monthsParseExact:!0,weekdays:"zondag_maandag_dinsdag_woensdag_donderdag_vrijdag_zaterdag".split("_"),weekdaysShort:"zo._ma._di._wo._do._vr._za.".split("_"),weekdaysMin:"Zo_Ma_Di_Wo_Do_Vr_Za".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[vandaag om] LT",nextDay:"[morgen om] LT",nextWeek:"dddd [om] LT",lastDay:"[gisteren om] LT",lastWeek:"[afgelopen] dddd [om] LT",sameElse:"L"}
,relativeTime:{
future:"over %s",past:"%s geleden",s:"een paar seconden",m:"één minuut",mm:"%d minuten",h:"één uur",hh:"%d uur",d:"één dag",dd:"%d dagen",M:"één maand",MM:"%d maanden",y:"één jaar",yy:"%d jaar"}
,ordinalParse:/\d{
1,2}
(ste|de)/,ordinal:function(n){
return n+(n===1||n===8||n>=20?"ste":"de")}
,week:{
dow:1,doy:4}
}
),rrt=n.defineLocale("nn",{
months:"januar_februar_mars_april_mai_juni_juli_august_september_oktober_november_desember".split("_"),monthsShort:"jan_feb_mar_apr_mai_jun_jul_aug_sep_okt_nov_des".split("_"),weekdays:"sundag_måndag_tysdag_onsdag_torsdag_fredag_laurdag".split("_"),weekdaysShort:"sun_mån_tys_ons_tor_fre_lau".split("_"),weekdaysMin:"su_må_ty_on_to_fr_lø".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY [kl.] H:mm",LLLL:"dddd D. MMMM YYYY [kl.] HH:mm"}
,calendar:{
sameDay:"[I dag klokka] LT",nextDay:"[I morgon klokka] LT",nextWeek:"dddd [klokka] LT",lastDay:"[I går klokka] LT",lastWeek:"[Føregåande] dddd [klokka] LT",sameElse:"L"}
,relativeTime:{
future:"om %s",past:"%s sidan",s:"nokre sekund",m:"eit minutt",mm:"%d minutt",h:"ein time",hh:"%d timar",d:"ein dag",dd:"%d dagar",M:"ein månad",MM:"%d månader",y:"eit år",yy:"%d år"}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),eg={
"1":"੧","2":"੨","3":"੩","4":"੪","5":"੫","6":"੬","7":"੭","8":"੮","9":"੯","0":"੦"}
,og={
"੧":"1","੨":"2","੩":"3","੪":"4","੫":"5","੬":"6","੭":"7","੮":"8","੯":"9","੦":"0"}
,urt=n.defineLocale("pa-in",{
months:"ਜਨਵਰੀ_ਫ਼ਰਵਰੀ_ਮਾਰਚ_ਅਪ੍ਰੈਲ_ਮਈ_ਜੂਨ_ਜੁਲਾਈ_ਅਗਸਤ_ਸਤੰਬਰ_ਅਕਤੂਬਰ_ਨਵੰਬਰ_ਦਸੰਬਰ".split("_"),monthsShort:"ਜਨਵਰੀ_ਫ਼ਰਵਰੀ_ਮਾਰਚ_ਅਪ੍ਰੈਲ_ਮਈ_ਜੂਨ_ਜੁਲਾਈ_ਅਗਸਤ_ਸਤੰਬਰ_ਅਕਤੂਬਰ_ਨਵੰਬਰ_ਦਸੰਬਰ".split("_"),weekdays:"ਐਤਵਾਰ_ਸੋਮਵਾਰ_ਮੰਗਲਵਾਰ_ਬੁਧਵਾਰ_ਵੀਰਵਾਰ_ਸ਼ੁੱਕਰਵਾਰ_ਸ਼ਨੀਚਰਵਾਰ".split("_"),weekdaysShort:"ਐਤ_ਸੋਮ_ਮੰਗਲ_ਬੁਧ_ਵੀਰ_ਸ਼ੁਕਰ_ਸ਼ਨੀ".split("_"),weekdaysMin:"ਐਤ_ਸੋਮ_ਮੰਗਲ_ਬੁਧ_ਵੀਰ_ਸ਼ੁਕਰ_ਸ਼ਨੀ".split("_"),longDateFormat:{
LT:"A h:mm ਵਜੇ",LTS:"A h:mm:ss ਵਜੇ",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, A h:mm ਵਜੇ",LLLL:"dddd, D MMMM YYYY, A h:mm ਵਜੇ"}
,calendar:{
sameDay:"[ਅਜ] LT",nextDay:"[ਕਲ] LT",nextWeek:"dddd, LT",lastDay:"[ਕਲ] LT",lastWeek:"[ਪਿਛਲੇ] dddd, LT",sameElse:"L"}
,relativeTime:{
future:"%s ਵਿੱਚ",past:"%s ਪਿਛਲੇ",s:"ਕੁਝ ਸਕਿੰਟ",m:"ਇਕ ਮਿੰਟ",mm:"%d ਮਿੰਟ",h:"ਇੱਕ ਘੰਟਾ",hh:"%d ਘੰਟੇ",d:"ਇੱਕ ਦਿਨ",dd:"%d ਦਿਨ",M:"ਇੱਕ ਮਹੀਨਾ",MM:"%d ਮਹੀਨੇ",y:"ਇੱਕ ਸਾਲ",yy:"%d ਸਾਲ"}
,preparse:function(n){
return n.replace(/[੧੨੩੪੫੬੭੮੯੦]/g,
function(n){
return og[n]}
)}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return eg[n]}
)}
,meridiemParse:/ਰਾਤ|ਸਵੇਰ|ਦੁਪਹਿਰ|ਸ਼ਾਮ/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="ਰਾਤ")?n<4?n:n+12:t==="ਸਵੇਰ"?n:t==="ਦੁਪਹਿਰ"?n>=10?n:n+12:t==="ਸ਼ਾਮ"?n+12:void 0}
,meridiem:function(n){
return n<4?"ਰਾਤ":n<10?"ਸਵੇਰ":n<17?"ਦੁਪਹਿਰ":n<20?"ਸ਼ਾਮ":"ਰਾਤ"}
,week:{
dow:0,doy:6}
}
),fl="styczeń_luty_marzec_kwiecień_maj_czerwiec_lipiec_sierpień_wrzesień_październik_listopad_grudzień".split("_"),el="stycznia_lutego_marca_kwietnia_maja_czerwca_lipca_sierpnia_września_października_listopada_grudnia".split("_");
var frt=n.defineLocale("pl",{
months:function(n,t){
return t===""?"("+el[n.month()]+"|"+fl[n.month()]+")":/D MMMM/.test(t)?el[n.month()]:fl[n.month()]}
,monthsShort:"sty_lut_mar_kwi_maj_cze_lip_sie_wrz_paź_lis_gru".split("_"),weekdays:"niedziela_poniedziałek_wtorek_środa_czwartek_piątek_sobota".split("_"),weekdaysShort:"nie_pon_wt_śr_czw_pt_sb".split("_"),weekdaysMin:"Nd_Pn_Wt_Śr_Cz_Pt_So".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Dziś o] LT",nextDay:"[Jutro o] LT",nextWeek:"[W] dddd [o] LT",lastDay:"[Wczoraj o] LT",lastWeek:function(){
switch(this.day()){
case 0:return"[W zeszłą niedzielę o] LT";
case 3:return"[W zeszłą środę o] LT";
case 6:return"[W zeszłą sobotę o] LT";
default:return"[W zeszły] dddd [o] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"za %s",past:"%s temu",s:"kilka sekund",m:sr,mm:sr,h:sr,hh:sr,d:"1 dzień",dd:"%d dni",M:"miesiąc",MM:sr,y:"rok",yy:sr}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),ert=n.defineLocale("pt-br",{
months:"Janeiro_Fevereiro_Março_Abril_Maio_Junho_Julho_Agosto_Setembro_Outubro_Novembro_Dezembro".split("_"),monthsShort:"Jan_Fev_Mar_Abr_Mai_Jun_Jul_Ago_Set_Out_Nov_Dez".split("_"),weekdays:"Domingo_Segunda-feira_Terça-feira_Quarta-feira_Quinta-feira_Sexta-feira_Sábado".split("_"),weekdaysShort:"Dom_Seg_Ter_Qua_Qui_Sex_Sáb".split("_"),weekdaysMin:"Dom_2ª_3ª_4ª_5ª_6ª_Sáb".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D [de] MMMM [de] YYYY",LLL:"D [de] MMMM [de] YYYY [às] HH:mm",LLLL:"dddd, D [de] MMMM [de] YYYY [às] HH:mm"}
,calendar:{
sameDay:"[Hoje às] LT",nextDay:"[Amanhã às] LT",nextWeek:"dddd [às] LT",lastDay:"[Ontem às] LT",lastWeek:function(){
return this.day()===0||this.day()===6?"[Último] dddd [às] LT":"[Última] dddd [às] LT"}
,sameElse:"L"}
,relativeTime:{
future:"em %s",past:"%s atrás",s:"poucos segundos",m:"um minuto",mm:"%d minutos",h:"uma hora",hh:"%d horas",d:"um dia",dd:"%d dias",M:"um mês",MM:"%d meses",y:"um ano",yy:"%d anos"}
,ordinalParse:/\d{
1,2}
º/,ordinal:"%dº"}
),ort=n.defineLocale("pt",{
months:"Janeiro_Fevereiro_Março_Abril_Maio_Junho_Julho_Agosto_Setembro_Outubro_Novembro_Dezembro".split("_"),monthsShort:"Jan_Fev_Mar_Abr_Mai_Jun_Jul_Ago_Set_Out_Nov_Dez".split("_"),weekdays:"Domingo_Segunda-Feira_Terça-Feira_Quarta-Feira_Quinta-Feira_Sexta-Feira_Sábado".split("_"),weekdaysShort:"Dom_Seg_Ter_Qua_Qui_Sex_Sáb".split("_"),weekdaysMin:"Dom_2ª_3ª_4ª_5ª_6ª_Sáb".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D [de] MMMM [de] YYYY",LLL:"D [de] MMMM [de] YYYY HH:mm",LLLL:"dddd, D [de] MMMM [de] YYYY HH:mm"}
,calendar:{
sameDay:"[Hoje às] LT",nextDay:"[Amanhã às] LT",nextWeek:"dddd [às] LT",lastDay:"[Ontem às] LT",lastWeek:function(){
return this.day()===0||this.day()===6?"[Último] dddd [às] LT":"[Última] dddd [às] LT"}
,sameElse:"L"}
,relativeTime:{
future:"em %s",past:"há %s",s:"segundos",m:"um minuto",mm:"%d minutos",h:"uma hora",hh:"%d horas",d:"um dia",dd:"%d dias",M:"um mês",MM:"%d meses",y:"um ano",yy:"%d anos"}
,ordinalParse:/\d{
1,2}
º/,ordinal:"%dº",week:{
dow:1,doy:4}
}
);
sg=n.defineLocale("ro",{
months:"ianuarie_februarie_martie_aprilie_mai_iunie_iulie_august_septembrie_octombrie_noiembrie_decembrie".split("_"),monthsShort:"ian._febr._mart._apr._mai_iun._iul._aug._sept._oct._nov._dec.".split("_"),monthsParseExact:!0,weekdays:"duminică_luni_marți_miercuri_joi_vineri_sâmbătă".split("_"),weekdaysShort:"Dum_Lun_Mar_Mie_Joi_Vin_Sâm".split("_"),weekdaysMin:"Du_Lu_Ma_Mi_Jo_Vi_Sâ".split("_"),longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY H:mm",LLLL:"dddd, D MMMM YYYY H:mm"}
,calendar:{
sameDay:"[azi la] LT",nextDay:"[mâine la] LT",nextWeek:"dddd [la] LT",lastDay:"[ieri la] LT",lastWeek:"[fosta] dddd [la] LT",sameElse:"L"}
,relativeTime:{
future:"peste %s",past:"%s în urmă",s:"câteva secunde",m:"un minut",mm:iu,h:"o oră",hh:iu,d:"o zi",dd:iu,M:"o lună",MM:iu,y:"un an",yy:iu}
,week:{
dow:1,doy:7}
}
);
var io=[/^янв/i,/^фев/i,/^мар/i,/^апр/i,/^ма[йя]/i,/^июн/i,/^июл/i,/^авг/i,/^сен/i,/^окт/i,/^ноя/i,/^дек/i],srt=n.defineLocale("ru",{
months:{
format:"января_февраля_марта_апреля_мая_июня_июля_августа_сентября_октября_ноября_декабря".split("_"),standalone:"январь_февраль_март_апрель_май_июнь_июль_август_сентябрь_октябрь_ноябрь_декабрь".split("_")}
,monthsShort:{
format:"янв._февр._мар._апр._мая_июня_июля_авг._сент._окт._нояб._дек.".split("_"),standalone:"янв._февр._март_апр._май_июнь_июль_авг._сент._окт._нояб._дек.".split("_")}
,weekdays:{
standalone:"воскресенье_понедельник_вторник_среда_четверг_пятница_суббота".split("_"),format:"воскресенье_понедельник_вторник_среду_четверг_пятницу_субботу".split("_"),isFormat:/\[ ?[Вв] ?(?:прошлую|следующую|эту)? ?\] ?dddd/}
,weekdaysShort:"вс_пн_вт_ср_чт_пт_сб".split("_"),weekdaysMin:"вс_пн_вт_ср_чт_пт_сб".split("_"),monthsParse:io,longMonthsParse:io,shortMonthsParse:io,monthsRegex:/^(сентябр[яь]|октябр[яь]|декабр[яь]|феврал[яь]|январ[яь]|апрел[яь]|августа?|ноябр[яь]|сент\.|февр\.|нояб\.|июнь|янв.|июль|дек.|авг.|апр.|марта|мар[.т]|окт.|июн[яь]|июл[яь]|ма[яй])/i,monthsShortRegex:/^(сентябр[яь]|октябр[яь]|декабр[яь]|феврал[яь]|январ[яь]|апрел[яь]|августа?|ноябр[яь]|сент\.|февр\.|нояб\.|июнь|янв.|июль|дек.|авг.|апр.|марта|мар[.т]|окт.|июн[яь]|июл[яь]|ма[яй])/i,monthsStrictRegex:/^(сентябр[яь]|октябр[яь]|декабр[яь]|феврал[яь]|январ[яь]|апрел[яь]|августа?|ноябр[яь]|марта?|июн[яь]|июл[яь]|ма[яй])/i,monthsShortStrictRegex:/^(нояб\.|февр\.|сент\.|июль|янв\.|июн[яь]|мар[.т]|авг\.|апр\.|окт\.|дек\.|ма[яй])/i,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY г.",LLL:"D MMMM YYYY г., HH:mm",LLLL:"dddd, D MMMM YYYY г., HH:mm"}
,calendar:{
sameDay:"[Сегодня в] LT",nextDay:"[Завтра в] LT",lastDay:"[Вчера в] LT",nextWeek:function(n){
if(n.week()!==this.week())switch(this.day()){
case 0:return"[В следующее] dddd [в] LT";
case 1:case 2:case 4:return"[В следующий] dddd [в] LT";
case 3:case 5:case 6:return"[В следующую] dddd [в] LT"}
else return this.day()===2?"[Во] dddd [в] LT":"[В] dddd [в] LT"}
,lastWeek:function(n){
if(n.week()!==this.week())switch(this.day()){
case 0:return"[В прошлое] dddd [в] LT";
case 1:case 2:case 4:return"[В прошлый] dddd [в] LT";
case 3:case 5:case 6:return"[В прошлую] dddd [в] LT"}
else return this.day()===2?"[Во] dddd [в] LT":"[В] dddd [в] LT"}
,sameElse:"L"}
,relativeTime:{
future:"через %s",past:"%s назад",s:"несколько секунд",m:hr,mm:hr,h:"час",hh:hr,d:"день",dd:hr,M:"месяц",MM:hr,y:"год",yy:hr}
,meridiemParse:/ночи|утра|дня|вечера/i,isPM:function(n){
return/^(дня|вечера)$/.test(n)}
,meridiem:function(n){
return n<4?"ночи":n<12?"утра":n<17?"дня":"вечера"}
,ordinalParse:/\d{
1,2}
-(й|го|я)/,ordinal:function(n,t){
switch(t){
case"M":case"d":case"DDD":return n+"-й";
case"D":return n+"-го";
case"w":case"W":return n+"-я";
default:return n}
}
,week:{
dow:1,doy:7}
}
),hrt=n.defineLocale("se",{
months:"ođđajagemánnu_guovvamánnu_njukčamánnu_cuoŋománnu_miessemánnu_geassemánnu_suoidnemánnu_borgemánnu_čakčamánnu_golggotmánnu_skábmamánnu_juovlamánnu".split("_"),monthsShort:"ođđj_guov_njuk_cuo_mies_geas_suoi_borg_čakč_golg_skáb_juov".split("_"),weekdays:"sotnabeaivi_vuossárga_maŋŋebárga_gaskavahkku_duorastat_bearjadat_lávvardat".split("_"),weekdaysShort:"sotn_vuos_maŋ_gask_duor_bear_láv".split("_"),weekdaysMin:"s_v_m_g_d_b_L".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"MMMM D. [b.] YYYY",LLL:"MMMM D. [b.] YYYY [ti.] HH:mm",LLLL:"dddd, MMMM D. [b.] YYYY [ti.] HH:mm"}
,calendar:{
sameDay:"[otne ti] LT",nextDay:"[ihttin ti] LT",nextWeek:"dddd [ti] LT",lastDay:"[ikte ti] LT",lastWeek:"[ovddit] dddd [ti] LT",sameElse:"L"}
,relativeTime:{
future:"%s geažes",past:"maŋit %s",s:"moadde sekunddat",m:"okta minuhta",mm:"%d minuhtat",h:"okta diimmu",hh:"%d diimmut",d:"okta beaivi",dd:"%d beaivvit",M:"okta mánnu",MM:"%d mánut",y:"okta jahki",yy:"%d jagit"}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),crt=n.defineLocale("si",{
months:"ජනවාරි_පෙබරවාරි_මාර්තු_අප්‍රේල්_මැයි_ජූනි_ජූලි_අගෝස්තු_සැප්තැම්බර්_ඔක්තෝබර්_නොවැම්බර්_දෙසැම්බර්".split("_"),monthsShort:"ජන_පෙබ_මාර්_අප්_මැයි_ජූනි_ජූලි_අගෝ_සැප්_ඔක්_නොවැ_දෙසැ".split("_"),weekdays:"ඉරිදා_සඳුදා_අඟහරුවාදා_බදාදා_බ්‍රහස්පතින්දා_සිකුරාදා_සෙනසුරාදා".split("_"),weekdaysShort:"ඉරි_සඳු_අඟ_බදා_බ්‍රහ_සිකු_සෙන".split("_"),weekdaysMin:"ඉ_ස_අ_බ_බ්‍ර_සි_සෙ".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"a h:mm",LTS:"a h:mm:ss",L:"YYYY/MM/DD",LL:"YYYY MMMM D",LLL:"YYYY MMMM D, a h:mm",LLLL:"YYYY MMMM D [වැනි] dddd, a h:mm:ss"}
,calendar:{
sameDay:"[අද] LT[ට]",nextDay:"[හෙට] LT[ට]",nextWeek:"dddd LT[ට]",lastDay:"[ඊයේ] LT[ට]",lastWeek:"[පසුගිය] dddd LT[ට]",sameElse:"L"}
,relativeTime:{
future:"%sකින්",past:"%sකට පෙර",s:"තත්පර කිහිපය",m:"මිනිත්තුව",mm:"මිනිත්තු %d",h:"පැය",hh:"පැය %d",d:"දිනය",dd:"දින %d",M:"මාසය",MM:"මාස %d",y:"වසර",yy:"වසර %d"}
,ordinalParse:/\d{
1,2}
 වැනි/,ordinal:function(n){
return n+" වැනි"}
,meridiemParse:/පෙර වරු|පස් වරු|පෙ.ව|ප.ව./,isPM:function(n){
return n==="ප.ව."||n==="පස් වරු"}
,meridiem:function(n,t,i){
return n>11?i?"ප.ව.":"පස් වරු":i?"පෙ.ව.":"පෙර වරු"}
}
),cg="január_február_marec_apríl_máj_jún_júl_august_september_október_november_december".split("_"),lg="jan_feb_mar_apr_máj_jún_júl_aug_sep_okt_nov_dec".split("_");
ag=n.defineLocale("sk",{
months:cg,monthsShort:lg,weekdays:"nedeľa_pondelok_utorok_streda_štvrtok_piatok_sobota".split("_"),weekdaysShort:"ne_po_ut_st_št_pi_so".split("_"),weekdaysMin:"ne_po_ut_st_št_pi_so".split("_"),longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD.MM.YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[dnes o] LT",nextDay:"[zajtra o] LT",nextWeek:function(){
switch(this.day()){
case 0:return"[v nedeľu o] LT";
case 1:case 2:return"[v] dddd [o] LT";
case 3:return"[v stredu o] LT";
case 4:return"[vo štvrtok o] LT";
case 5:return"[v piatok o] LT";
case 6:return"[v sobotu o] LT"}
}
,lastDay:"[včera o] LT",lastWeek:function(){
switch(this.day()){
case 0:return"[minulú nedeľu o] LT";
case 1:case 2:return"[minulý] dddd [o] LT";
case 3:return"[minulú stredu o] LT";
case 4:case 5:return"[minulý] dddd [o] LT";
case 6:return"[minulú sobotu o] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"za %s",past:"pred %s",s:st,m:st,mm:st,h:st,hh:st,d:st,dd:st,M:st,MM:st,y:st,yy:st}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
);
var lrt=n.defineLocale("sl",{
months:"januar_februar_marec_april_maj_junij_julij_avgust_september_oktober_november_december".split("_"),monthsShort:"jan._feb._mar._apr._maj._jun._jul._avg._sep._okt._nov._dec.".split("_"),monthsParseExact:!0,weekdays:"nedelja_ponedeljek_torek_sreda_četrtek_petek_sobota".split("_"),weekdaysShort:"ned._pon._tor._sre._čet._pet._sob.".split("_"),weekdaysMin:"ne_po_to_sr_če_pe_so".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD. MM. YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd, D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[danes ob] LT",nextDay:"[jutri ob] LT",nextWeek:function(){
switch(this.day()){
case 0:return"[v] [nedeljo] [ob] LT";
case 3:return"[v] [sredo] [ob] LT";
case 6:return"[v] [soboto] [ob] LT";
case 1:case 2:case 4:case 5:return"[v] dddd [ob] LT"}
}
,lastDay:"[včeraj ob] LT",lastWeek:function(){
switch(this.day()){
case 0:return"[prejšnjo] [nedeljo] [ob] LT";
case 3:return"[prejšnjo] [sredo] [ob] LT";
case 6:return"[prejšnjo] [soboto] [ob] LT";
case 1:case 2:case 4:case 5:return"[prejšnji] dddd [ob] LT"}
}
,sameElse:"L"}
,relativeTime:{
future:"čez %s",past:"pred %s",s:ht,m:ht,mm:ht,h:ht,hh:ht,d:ht,dd:ht,M:ht,MM:ht,y:ht,yy:ht}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:7}
}
),art=n.defineLocale("sq",{
months:"Janar_Shkurt_Mars_Prill_Maj_Qershor_Korrik_Gusht_Shtator_Tetor_Nëntor_Dhjetor".split("_"),monthsShort:"Jan_Shk_Mar_Pri_Maj_Qer_Kor_Gus_Sht_Tet_Nën_Dhj".split("_"),weekdays:"E Diel_E Hënë_E Martë_E Mërkurë_E Enjte_E Premte_E Shtunë".split("_"),weekdaysShort:"Die_Hën_Mar_Mër_Enj_Pre_Sht".split("_"),weekdaysMin:"D_H_Ma_Më_E_P_Sh".split("_"),weekdaysParseExact:!0,meridiemParse:/PD|MD/,isPM:function(n){
return n.charAt(0)==="M"}
,meridiem:function(n){
return n<12?"PD":"MD"}
,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[Sot në] LT",nextDay:"[Nesër në] LT",nextWeek:"dddd [në] LT",lastDay:"[Dje në] LT",lastWeek:"dddd [e kaluar në] LT",sameElse:"L"}
,relativeTime:{
future:"në %s",past:"%s më parë",s:"disa sekonda",m:"një minutë",mm:"%d minuta",h:"një orë",hh:"%d orë",d:"një ditë",dd:"%d ditë",M:"një muaj",MM:"%d muaj",y:"një vit",yy:"%d vite"}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),ti={
words:{
m:["један минут","једне минуте"],mm:["минут","минуте","минута"],h:["један сат","једног сата"],hh:["сат","сата","сати"],dd:["дан","дана","дана"],MM:["месец","месеца","месеци"],yy:["година","године","година"]}
,correctGrammaticalCase:function(n,t){
return n===1?t[0]:n>=2&&n<=4?t[1]:t[2]}
,translate:function(n,t,i){
var r=ti.words[i];
return i.length===1?t?r[0]:r[1]:n+" "+ti.correctGrammaticalCase(n,r)}
}
,vrt=n.defineLocale("sr-cyrl",{
months:"јануар_фебруар_март_април_мај_јун_јул_август_септембар_октобар_новембар_децембар".split("_"),monthsShort:"јан._феб._мар._апр._мај_јун_јул_авг._сеп._окт._нов._дец.".split("_"),monthsParseExact:!0,weekdays:"недеља_понедељак_уторак_среда_четвртак_петак_субота".split("_"),weekdaysShort:"нед._пон._уто._сре._чет._пет._суб.".split("_"),weekdaysMin:"не_по_ут_ср_че_пе_су".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD. MM. YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd, D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[данас у] LT",nextDay:"[сутра у] LT",nextWeek:function(){
switch(this.day()){
case 0:return"[у] [недељу] [у] LT";
case 3:return"[у] [среду] [у] LT";
case 6:return"[у] [суботу] [у] LT";
case 1:case 2:case 4:case 5:return"[у] dddd [у] LT"}
}
,lastDay:"[јуче у] LT",lastWeek:function(){
return["[прошле] [недеље] [у] LT","[прошлог] [понедељка] [у] LT","[прошлог] [уторка] [у] LT","[прошле] [среде] [у] LT","[прошлог] [четвртка] [у] LT","[прошлог] [петка] [у] LT","[прошле] [суботе] [у] LT"][this.day()]}
,sameElse:"L"}
,relativeTime:{
future:"за %s",past:"пре %s",s:"неколико секунди",m:ti.translate,mm:ti.translate,h:ti.translate,hh:ti.translate,d:"дан",dd:ti.translate,M:"месец",MM:ti.translate,y:"годину",yy:ti.translate}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:7}
}
),ii={
words:{
m:["jedan minut","jedne minute"],mm:["minut","minute","minuta"],h:["jedan sat","jednog sata"],hh:["sat","sata","sati"],dd:["dan","dana","dana"],MM:["mesec","meseca","meseci"],yy:["godina","godine","godina"]}
,correctGrammaticalCase:function(n,t){
return n===1?t[0]:n>=2&&n<=4?t[1]:t[2]}
,translate:function(n,t,i){
var r=ii.words[i];
return i.length===1?t?r[0]:r[1]:n+" "+ii.correctGrammaticalCase(n,r)}
}
,yrt=n.defineLocale("sr",{
months:"januar_februar_mart_april_maj_jun_jul_avgust_septembar_oktobar_novembar_decembar".split("_"),monthsShort:"jan._feb._mar._apr._maj_jun_jul_avg._sep._okt._nov._dec.".split("_"),monthsParseExact:!0,weekdays:"nedelja_ponedeljak_utorak_sreda_četvrtak_petak_subota".split("_"),weekdaysShort:"ned._pon._uto._sre._čet._pet._sub.".split("_"),weekdaysMin:"ne_po_ut_sr_če_pe_su".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H:mm",LTS:"H:mm:ss",L:"DD. MM. YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY H:mm",LLLL:"dddd, D. MMMM YYYY H:mm"}
,calendar:{
sameDay:"[danas u] LT",nextDay:"[sutra u] LT",nextWeek:function(){
switch(this.day()){
case 0:return"[u] [nedelju] [u] LT";
case 3:return"[u] [sredu] [u] LT";
case 6:return"[u] [subotu] [u] LT";
case 1:case 2:case 4:case 5:return"[u] dddd [u] LT"}
}
,lastDay:"[juče u] LT",lastWeek:function(){
return["[prošle] [nedelje] [u] LT","[prošlog] [ponedeljka] [u] LT","[prošlog] [utorka] [u] LT","[prošle] [srede] [u] LT","[prošlog] [četvrtka] [u] LT","[prošlog] [petka] [u] LT","[prošle] [subote] [u] LT"][this.day()]}
,sameElse:"L"}
,relativeTime:{
future:"za %s",past:"pre %s",s:"nekoliko sekundi",m:ii.translate,mm:ii.translate,h:ii.translate,hh:ii.translate,d:"dan",dd:ii.translate,M:"mesec",MM:ii.translate,y:"godinu",yy:ii.translate}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:7}
}
),prt=n.defineLocale("ss",{
months:"Bhimbidvwane_Indlovana_Indlov'lenkhulu_Mabasa_Inkhwekhweti_Inhlaba_Kholwane_Ingci_Inyoni_Imphala_Lweti_Ingongoni".split("_"),monthsShort:"Bhi_Ina_Inu_Mab_Ink_Inh_Kho_Igc_Iny_Imp_Lwe_Igo".split("_"),weekdays:"Lisontfo_Umsombuluko_Lesibili_Lesitsatfu_Lesine_Lesihlanu_Umgcibelo".split("_"),weekdaysShort:"Lis_Umb_Lsb_Les_Lsi_Lsh_Umg".split("_"),weekdaysMin:"Li_Us_Lb_Lt_Ls_Lh_Ug".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"h:mm A",LTS:"h:mm:ss A",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY h:mm A",LLLL:"dddd, D MMMM YYYY h:mm A"}
,calendar:{
sameDay:"[Namuhla nga] LT",nextDay:"[Kusasa nga] LT",nextWeek:"dddd [nga] LT",lastDay:"[Itolo nga] LT",lastWeek:"dddd [leliphelile] [nga] LT",sameElse:"L"}
,relativeTime:{
future:"nga %s",past:"wenteka nga %s",s:"emizuzwana lomcane",m:"umzuzu",mm:"%d emizuzu",h:"lihora",hh:"%d emahora",d:"lilanga",dd:"%d emalanga",M:"inyanga",MM:"%d tinyanga",y:"umnyaka",yy:"%d iminyaka"}
,meridiemParse:/ekuseni|emini|entsambama|ebusuku/,meridiem:function(n){
return n<11?"ekuseni":n<15?"emini":n<19?"entsambama":"ebusuku"}
,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="ekuseni")?n:t==="emini"?n>=11?n:n+12:t==="entsambama"||t==="ebusuku"?n===0?0:n+12:void 0}
,ordinalParse:/\d{
1,2}
/,ordinal:"%d",week:{
dow:1,doy:4}
}
),wrt=n.defineLocale("sv",{
months:"januari_februari_mars_april_maj_juni_juli_augusti_september_oktober_november_december".split("_"),monthsShort:"jan_feb_mar_apr_maj_jun_jul_aug_sep_okt_nov_dec".split("_"),weekdays:"söndag_måndag_tisdag_onsdag_torsdag_fredag_lördag".split("_"),weekdaysShort:"sön_mån_tis_ons_tor_fre_lör".split("_"),weekdaysMin:"sö_må_ti_on_to_fr_lö".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"YYYY-MM-DD",LL:"D MMMM YYYY",LLL:"D MMMM YYYY [kl.] HH:mm",LLLL:"dddd D MMMM YYYY [kl.] HH:mm",lll:"D MMM YYYY HH:mm",llll:"ddd D MMM YYYY HH:mm"}
,calendar:{
sameDay:"[Idag] LT",nextDay:"[Imorgon] LT",lastDay:"[Igår] LT",nextWeek:"[På] dddd LT",lastWeek:"[I] dddd[s] LT",sameElse:"L"}
,relativeTime:{
future:"om %s",past:"för %s sedan",s:"några sekunder",m:"en minut",mm:"%d minuter",h:"en timme",hh:"%d timmar",d:"en dag",dd:"%d dagar",M:"en månad",MM:"%d månader",y:"ett år",yy:"%d år"}
,ordinalParse:/\d{
1,2}
(e|a)/,ordinal:function(n){
var t=n%10,i=~~(n%100/10)==1?"e":t===1?"a":t===2?"a":t===3?"e":"e";
return n+i}
,week:{
dow:1,doy:4}
}
),brt=n.defineLocale("sw",{
months:"Januari_Februari_Machi_Aprili_Mei_Juni_Julai_Agosti_Septemba_Oktoba_Novemba_Desemba".split("_"),monthsShort:"Jan_Feb_Mac_Apr_Mei_Jun_Jul_Ago_Sep_Okt_Nov_Des".split("_"),weekdays:"Jumapili_Jumatatu_Jumanne_Jumatano_Alhamisi_Ijumaa_Jumamosi".split("_"),weekdaysShort:"Jpl_Jtat_Jnne_Jtan_Alh_Ijm_Jmos".split("_"),weekdaysMin:"J2_J3_J4_J5_Al_Ij_J1".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[leo saa] LT",nextDay:"[kesho saa] LT",nextWeek:"[wiki ijayo] dddd [saat] LT",lastDay:"[jana] LT",lastWeek:"[wiki iliyopita] dddd [saat] LT",sameElse:"L"}
,relativeTime:{
future:"%s baadaye",past:"tokea %s",s:"hivi punde",m:"dakika moja",mm:"dakika %d",h:"saa limoja",hh:"masaa %d",d:"siku moja",dd:"masiku %d",M:"mwezi mmoja",MM:"miezi %d",y:"mwaka mmoja",yy:"miaka %d"}
,week:{
dow:1,doy:7}
}
),vg={
"1":"௧","2":"௨","3":"௩","4":"௪","5":"௫","6":"௬","7":"௭","8":"௮","9":"௯","0":"௦"}
,yg={
"௧":"1","௨":"2","௩":"3","௪":"4","௫":"5","௬":"6","௭":"7","௮":"8","௯":"9","௦":"0"}
,krt=n.defineLocale("ta",{
months:"ஜனவரி_பிப்ரவரி_மார்ச்_ஏப்ரல்_மே_ஜூன்_ஜூலை_ஆகஸ்ட்_செப்டெம்பர்_அக்டோபர்_நவம்பர்_டிசம்பர்".split("_"),monthsShort:"ஜனவரி_பிப்ரவரி_மார்ச்_ஏப்ரல்_மே_ஜூன்_ஜூலை_ஆகஸ்ட்_செப்டெம்பர்_அக்டோபர்_நவம்பர்_டிசம்பர்".split("_"),weekdays:"ஞாயிற்றுக்கிழமை_திங்கட்கிழமை_செவ்வாய்கிழமை_புதன்கிழமை_வியாழக்கிழமை_வெள்ளிக்கிழமை_சனிக்கிழமை".split("_"),weekdaysShort:"ஞாயிறு_திங்கள்_செவ்வாய்_புதன்_வியாழன்_வெள்ளி_சனி".split("_"),weekdaysMin:"ஞா_தி_செ_பு_வி_வெ_ச".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, HH:mm",LLLL:"dddd, D MMMM YYYY, HH:mm"}
,calendar:{
sameDay:"[இன்று] LT",nextDay:"[நாளை] LT",nextWeek:"dddd, LT",lastDay:"[நேற்று] LT",lastWeek:"[கடந்த வாரம்] dddd, LT",sameElse:"L"}
,relativeTime:{
future:"%s இல்",past:"%s முன்",s:"ஒரு சில விநாடிகள்",m:"ஒரு நிமிடம்",mm:"%d நிமிடங்கள்",h:"ஒரு மணி நேரம்",hh:"%d மணி நேரம்",d:"ஒரு நாள்",dd:"%d நாட்கள்",M:"ஒரு மாதம்",MM:"%d மாதங்கள்",y:"ஒரு வருடம்",yy:"%d ஆண்டுகள்"}
,ordinalParse:/\d{
1,2}
வது/,ordinal:function(n){
return n+"வது"}
,preparse:function(n){
return n.replace(/[௧௨௩௪௫௬௭௮௯௦]/g,
function(n){
return yg[n]}
)}
,postformat:function(n){
return n.replace(/\d/g,
function(n){
return vg[n]}
)}
,meridiemParse:/யாமம்|வைகறை|காலை|நண்பகல்|எற்பாடு|மாலை/,meridiem:function(n){
return n<2?" யாமம்":n<6?" வைகறை":n<10?" காலை":n<14?" நண்பகல்":n<18?" எற்பாடு":n<22?" மாலை":" யாமம்"}
,meridiemHour:function(n,t){
return n===12&&(n=0),t==="யாமம்"?n<2?n:n+12:t==="வைகறை"||t==="காலை"?n:t==="நண்பகல்"?n>=10?n:n+12:n+12}
,week:{
dow:0,doy:6}
}
),drt=n.defineLocale("te",{
months:"జనవరి_ఫిబ్రవరి_మార్చి_ఏప్రిల్_మే_జూన్_జూలై_ఆగస్టు_సెప్టెంబర్_అక్టోబర్_నవంబర్_డిసెంబర్".split("_"),monthsShort:"జన._ఫిబ్ర._మార్చి_ఏప్రి._మే_జూన్_జూలై_ఆగ._సెప్._అక్టో._నవ._డిసె.".split("_"),monthsParseExact:!0,weekdays:"ఆదివారం_సోమవారం_మంగళవారం_బుధవారం_గురువారం_శుక్రవారం_శనివారం".split("_"),weekdaysShort:"ఆది_సోమ_మంగళ_బుధ_గురు_శుక్ర_శని".split("_"),weekdaysMin:"ఆ_సో_మం_బు_గు_శు_శ".split("_"),longDateFormat:{
LT:"A h:mm",LTS:"A h:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY, A h:mm",LLLL:"dddd, D MMMM YYYY, A h:mm"}
,calendar:{
sameDay:"[నేడు] LT",nextDay:"[రేపు] LT",nextWeek:"dddd, LT",lastDay:"[నిన్న] LT",lastWeek:"[గత] dddd, LT",sameElse:"L"}
,relativeTime:{
future:"%s లో",past:"%s క్రితం",s:"కొన్ని క్షణాలు",m:"ఒక నిమిషం",mm:"%d నిమిషాలు",h:"ఒక గంట",hh:"%d గంటలు",d:"ఒక రోజు",dd:"%d రోజులు",M:"ఒక నెల",MM:"%d నెలలు",y:"ఒక సంవత్సరం",yy:"%d సంవత్సరాలు"}
,ordinalParse:/\d{
1,2}
వ/,ordinal:"%dవ",meridiemParse:/రాత్రి|ఉదయం|మధ్యాహ్నం|సాయంత్రం/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="రాత్రి")?n<4?n:n+12:t==="ఉదయం"?n:t==="మధ్యాహ్నం"?n>=10?n:n+12:t==="సాయంత్రం"?n+12:void 0}
,meridiem:function(n){
return n<4?"రాత్రి":n<10?"ఉదయం":n<17?"మధ్యాహ్నం":n<20?"సాయంత్రం":"రాత్రి"}
,week:{
dow:0,doy:6}
}
),grt=n.defineLocale("th",{
months:"มกราคม_กุมภาพันธ์_มีนาคม_เมษายน_พฤษภาคม_มิถุนายน_กรกฎาคม_สิงหาคม_กันยายน_ตุลาคม_พฤศจิกายน_ธันวาคม".split("_"),monthsShort:"มกรา_กุมภา_มีนา_เมษา_พฤษภา_มิถุนา_กรกฎา_สิงหา_กันยา_ตุลา_พฤศจิกา_ธันวา".split("_"),monthsParseExact:!0,weekdays:"อาทิตย์_จันทร์_อังคาร_พุธ_พฤหัสบดี_ศุกร์_เสาร์".split("_"),weekdaysShort:"อาทิตย์_จันทร์_อังคาร_พุธ_พฤหัส_ศุกร์_เสาร์".split("_"),weekdaysMin:"อา._จ._อ._พ._พฤ._ศ._ส.".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"H นาฬิกา m นาที",LTS:"H นาฬิกา m นาที s วินาที",L:"YYYY/MM/DD",LL:"D MMMM YYYY",LLL:"D MMMM YYYY เวลา H นาฬิกา m นาที",LLLL:"วันddddที่ D MMMM YYYY เวลา H นาฬิกา m นาที"}
,meridiemParse:/ก่อนเที่ยง|หลังเที่ยง/,isPM:function(n){
return n==="หลังเที่ยง"}
,meridiem:function(n){
return n<12?"ก่อนเที่ยง":"หลังเที่ยง"}
,calendar:{
sameDay:"[วันนี้ เวลา] LT",nextDay:"[พรุ่งนี้ เวลา] LT",nextWeek:"dddd[หน้า เวลา] LT",lastDay:"[เมื่อวานนี้ เวลา] LT",lastWeek:"[วัน]dddd[ที่แล้ว เวลา] LT",sameElse:"L"}
,relativeTime:{
future:"อีก %s",past:"%sที่แล้ว",s:"ไม่กี่วินาที",m:"1 นาที",mm:"%d นาที",h:"1 ชั่วโมง",hh:"%d ชั่วโมง",d:"1 วัน",dd:"%d วัน",M:"1 เดือน",MM:"%d เดือน",y:"1 ปี",yy:"%d ปี"}
}
),nut=n.defineLocale("tl-ph",{
months:"Enero_Pebrero_Marso_Abril_Mayo_Hunyo_Hulyo_Agosto_Setyembre_Oktubre_Nobyembre_Disyembre".split("_"),monthsShort:"Ene_Peb_Mar_Abr_May_Hun_Hul_Ago_Set_Okt_Nob_Dis".split("_"),weekdays:"Linggo_Lunes_Martes_Miyerkules_Huwebes_Biyernes_Sabado".split("_"),weekdaysShort:"Lin_Lun_Mar_Miy_Huw_Biy_Sab".split("_"),weekdaysMin:"Li_Lu_Ma_Mi_Hu_Bi_Sab".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"MM/D/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY HH:mm",LLLL:"dddd, MMMM DD, YYYY HH:mm"}
,calendar:{
sameDay:"[Ngayon sa] LT",nextDay:"[Bukas sa] LT",nextWeek:"dddd [sa] LT",lastDay:"[Kahapon sa] LT",lastWeek:"dddd [huling linggo] LT",sameElse:"L"}
,relativeTime:{
future:"sa loob ng %s",past:"%s ang nakalipas",s:"ilang segundo",m:"isang minuto",mm:"%d minuto",h:"isang oras",hh:"%d oras",d:"isang araw",dd:"%d araw",M:"isang buwan",MM:"%d buwan",y:"isang taon",yy:"%d taon"}
,ordinalParse:/\d{
1,2}
/,ordinal:function(n){
return n}
,week:{
dow:1,doy:4}
}
),ro="pagh_wa’_cha’_wej_loS_vagh_jav_Soch_chorgh_Hut".split("_");
var tut=n.defineLocale("tlh",{
months:"tera’ jar wa’_tera’ jar cha’_tera’ jar wej_tera’ jar loS_tera’ jar vagh_tera’ jar jav_tera’ jar Soch_tera’ jar chorgh_tera’ jar Hut_tera’ jar wa’maH_tera’ jar wa’maH wa’_tera’ jar wa’maH cha’".split("_"),monthsShort:"jar wa’_jar cha’_jar wej_jar loS_jar vagh_jar jav_jar Soch_jar chorgh_jar Hut_jar wa’maH_jar wa’maH wa’_jar wa’maH cha’".split("_"),monthsParseExact:!0,weekdays:"lojmItjaj_DaSjaj_povjaj_ghItlhjaj_loghjaj_buqjaj_ghInjaj".split("_"),weekdaysShort:"lojmItjaj_DaSjaj_povjaj_ghItlhjaj_loghjaj_buqjaj_ghInjaj".split("_"),weekdaysMin:"lojmItjaj_DaSjaj_povjaj_ghItlhjaj_loghjaj_buqjaj_ghInjaj".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[DaHjaj] LT",nextDay:"[wa’leS] LT",nextWeek:"LLL",lastDay:"[wa’Hu’] LT",lastWeek:"LLL",sameElse:"L"}
,relativeTime:{
future:pg,past:wg,s:"puS lup",m:"wa’ tup",mm:uu,h:"wa’ rep",hh:uu,d:"wa’ jaj",dd:uu,M:"wa’ jar",MM:uu,y:"wa’ DIS",yy:uu}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
),uo={
1:"'inci",5:"'inci",8:"'inci",70:"'inci",80:"'inci",2:"'nci",7:"'nci",20:"'nci",50:"'nci",3:"'üncü",4:"'üncü",100:"'üncü",6:"'ncı",9:"'uncu",10:"'uncu",30:"'uncu",60:"'ıncı",90:"'ıncı"}
,iut=n.defineLocale("tr",{
months:"Ocak_Şubat_Mart_Nisan_Mayıs_Haziran_Temmuz_Ağustos_Eylül_Ekim_Kasım_Aralık".split("_"),monthsShort:"Oca_Şub_Mar_Nis_May_Haz_Tem_Ağu_Eyl_Eki_Kas_Ara".split("_"),weekdays:"Pazar_Pazartesi_Salı_Çarşamba_Perşembe_Cuma_Cumartesi".split("_"),weekdaysShort:"Paz_Pts_Sal_Çar_Per_Cum_Cts".split("_"),weekdaysMin:"Pz_Pt_Sa_Ça_Pe_Cu_Ct".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[bugün saat] LT",nextDay:"[yarın saat] LT",nextWeek:"[haftaya] dddd [saat] LT",lastDay:"[dün] LT",lastWeek:"[geçen hafta] dddd [saat] LT",sameElse:"L"}
,relativeTime:{
future:"%s sonra",past:"%s önce",s:"birkaç saniye",m:"bir dakika",mm:"%d dakika",h:"bir saat",hh:"%d saat",d:"bir gün",dd:"%d gün",M:"bir ay",MM:"%d ay",y:"bir yıl",yy:"%d yıl"}
,ordinalParse:/\d{
1,2}
'(inci|nci|üncü|ncı|uncu|ıncı)/,ordinal:function(n){
if(n===0)return n+"'ıncı";
var t=n%10,i=n%100-t,r=n>=100?100:null;
return n+(uo[t]||uo[i]||uo[r])}
,week:{
dow:1,doy:7}
}
),rut=n.defineLocale("tzl",{
months:"Januar_Fevraglh_Març_Avrïu_Mai_Gün_Julia_Guscht_Setemvar_Listopäts_Noemvar_Zecemvar".split("_"),monthsShort:"Jan_Fev_Mar_Avr_Mai_Gün_Jul_Gus_Set_Lis_Noe_Zec".split("_"),weekdays:"Súladi_Lúneçi_Maitzi_Márcuri_Xhúadi_Viénerçi_Sáturi".split("_"),weekdaysShort:"Súl_Lún_Mai_Már_Xhú_Vié_Sát".split("_"),weekdaysMin:"Sú_Lú_Ma_Má_Xh_Vi_Sá".split("_"),longDateFormat:{
LT:"HH.mm",LTS:"HH.mm.ss",L:"DD.MM.YYYY",LL:"D. MMMM [dallas] YYYY",LLL:"D. MMMM [dallas] YYYY HH.mm",LLLL:"dddd, [li] D. MMMM [dallas] YYYY HH.mm"}
,meridiemParse:/d\'o|d\'a/i,isPM:function(n){
return"d'o"===n.toLowerCase()}
,meridiem:function(n,t,i){
return n>11?i?"d'o":"D'O":i?"d'a":"D'A"}
,calendar:{
sameDay:"[oxhi à] LT",nextDay:"[demà à] LT",nextWeek:"dddd [à] LT",lastDay:"[ieiri à] LT",lastWeek:"[sür el] dddd [lasteu à] LT",sameElse:"L"}
,relativeTime:{
future:"osprei %s",past:"ja%s",s:ct,m:ct,mm:ct,h:ct,hh:ct,d:ct,dd:ct,M:ct,MM:ct,y:ct,yy:ct}
,ordinalParse:/\d{
1,2}
\./,ordinal:"%d.",week:{
dow:1,doy:4}
}
);
kg=n.defineLocale("tzm-latn",{
months:"innayr_brˤayrˤ_marˤsˤ_ibrir_mayyw_ywnyw_ywlywz_ɣwšt_šwtanbir_ktˤwbrˤ_nwwanbir_dwjnbir".split("_"),monthsShort:"innayr_brˤayrˤ_marˤsˤ_ibrir_mayyw_ywnyw_ywlywz_ɣwšt_šwtanbir_ktˤwbrˤ_nwwanbir_dwjnbir".split("_"),weekdays:"asamas_aynas_asinas_akras_akwas_asimwas_asiḍyas".split("_"),weekdaysShort:"asamas_aynas_asinas_akras_akwas_asimwas_asiḍyas".split("_"),weekdaysMin:"asamas_aynas_asinas_akras_akwas_asimwas_asiḍyas".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[asdkh g] LT",nextDay:"[aska g] LT",nextWeek:"dddd [g] LT",lastDay:"[assant g] LT",lastWeek:"dddd [g] LT",sameElse:"L"}
,relativeTime:{
future:"dadkh s yan %s",past:"yan %s",s:"imik",m:"minuḍ",mm:"%d minuḍ",h:"saɛa",hh:"%d tassaɛin",d:"ass",dd:"%d ossan",M:"ayowr",MM:"%d iyyirn",y:"asgas",yy:"%d isgasn"}
,week:{
dow:6,doy:12}
}
);
dg=n.defineLocale("tzm",{
months:"ⵉⵏⵏⴰⵢⵔ_ⴱⵕⴰⵢⵕ_ⵎⴰⵕⵚ_ⵉⴱⵔⵉⵔ_ⵎⴰⵢⵢⵓ_ⵢⵓⵏⵢⵓ_ⵢⵓⵍⵢⵓⵣ_ⵖⵓⵛⵜ_ⵛⵓⵜⴰⵏⴱⵉⵔ_ⴽⵟⵓⴱⵕ_ⵏⵓⵡⴰⵏⴱⵉⵔ_ⴷⵓⵊⵏⴱⵉⵔ".split("_"),monthsShort:"ⵉⵏⵏⴰⵢⵔ_ⴱⵕⴰⵢⵕ_ⵎⴰⵕⵚ_ⵉⴱⵔⵉⵔ_ⵎⴰⵢⵢⵓ_ⵢⵓⵏⵢⵓ_ⵢⵓⵍⵢⵓⵣ_ⵖⵓⵛⵜ_ⵛⵓⵜⴰⵏⴱⵉⵔ_ⴽⵟⵓⴱⵕ_ⵏⵓⵡⴰⵏⴱⵉⵔ_ⴷⵓⵊⵏⴱⵉⵔ".split("_"),weekdays:"ⴰⵙⴰⵎⴰⵙ_ⴰⵢⵏⴰⵙ_ⴰⵙⵉⵏⴰⵙ_ⴰⴽⵔⴰⵙ_ⴰⴽⵡⴰⵙ_ⴰⵙⵉⵎⵡⴰⵙ_ⴰⵙⵉⴹⵢⴰⵙ".split("_"),weekdaysShort:"ⴰⵙⴰⵎⴰⵙ_ⴰⵢⵏⴰⵙ_ⴰⵙⵉⵏⴰⵙ_ⴰⴽⵔⴰⵙ_ⴰⴽⵡⴰⵙ_ⴰⵙⵉⵎⵡⴰⵙ_ⴰⵙⵉⴹⵢⴰⵙ".split("_"),weekdaysMin:"ⴰⵙⴰⵎⴰⵙ_ⴰⵢⵏⴰⵙ_ⴰⵙⵉⵏⴰⵙ_ⴰⴽⵔⴰⵙ_ⴰⴽⵡⴰⵙ_ⴰⵙⵉⵎⵡⴰⵙ_ⴰⵙⵉⴹⵢⴰⵙ".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[ⴰⵙⴷⵅ ⴴ] LT",nextDay:"[ⴰⵙⴽⴰ ⴴ] LT",nextWeek:"dddd [ⴴ] LT",lastDay:"[ⴰⵚⴰⵏⵜ ⴴ] LT",lastWeek:"dddd [ⴴ] LT",sameElse:"L"}
,relativeTime:{
future:"ⴷⴰⴷⵅ ⵙ ⵢⴰⵏ %s",past:"ⵢⴰⵏ %s",s:"ⵉⵎⵉⴽ",m:"ⵎⵉⵏⵓⴺ",mm:"%d ⵎⵉⵏⵓⴺ",h:"ⵙⴰⵄⴰ",hh:"%d ⵜⴰⵙⵙⴰⵄⵉⵏ",d:"ⴰⵙⵙ",dd:"%d oⵙⵙⴰⵏ",M:"ⴰⵢoⵓⵔ",MM:"%d ⵉⵢⵢⵉⵔⵏ",y:"ⴰⵙⴳⴰⵙ",yy:"%d ⵉⵙⴳⴰⵙⵏ"}
,week:{
dow:6,doy:12}
}
);
var uut=n.defineLocale("uk",{
months:{
format:"січня_лютого_березня_квітня_травня_червня_липня_серпня_вересня_жовтня_листопада_грудня".split("_"),standalone:"січень_лютий_березень_квітень_травень_червень_липень_серпень_вересень_жовтень_листопад_грудень".split("_")}
,monthsShort:"січ_лют_бер_квіт_трав_черв_лип_серп_вер_жовт_лист_груд".split("_"),weekdays:nn,weekdaysShort:"нд_пн_вт_ср_чт_пт_сб".split("_"),weekdaysMin:"нд_пн_вт_ср_чт_пт_сб".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY р.",LLL:"D MMMM YYYY р., HH:mm",LLLL:"dddd, D MMMM YYYY р., HH:mm"}
,calendar:{
sameDay:lr("[Сьогодні "),nextDay:lr("[Завтра "),lastDay:lr("[Вчора "),nextWeek:lr("[У] dddd ["),lastWeek:function(){
switch(this.day()){
case 0:case 3:case 5:case 6:return lr("[Минулої] dddd [").call(this);
case 1:case 2:case 4:return lr("[Минулого] dddd [").call(this)}
}
,sameElse:"L"}
,relativeTime:{
future:"за %s",past:"%s тому",s:"декілька секунд",m:cr,mm:cr,h:"годину",hh:cr,d:"день",dd:cr,M:"місяць",MM:cr,y:"рік",yy:cr}
,meridiemParse:/ночі|ранку|дня|вечора/,isPM:function(n){
return/^(дня|вечора)$/.test(n)}
,meridiem:function(n){
return n<4?"ночі":n<12?"ранку":n<17?"дня":"вечора"}
,ordinalParse:/\d{
1,2}
-(й|го)/,ordinal:function(n,t){
switch(t){
case"M":case"d":case"DDD":case"w":case"W":return n+"-й";
case"D":return n+"-го";
default:return n}
}
,week:{
dow:1,doy:7}
}
),fut=n.defineLocale("uz",{
months:"январ_феврал_март_апрел_май_июн_июл_август_сентябр_октябр_ноябр_декабр".split("_"),monthsShort:"янв_фев_мар_апр_май_июн_июл_авг_сен_окт_ноя_дек".split("_"),weekdays:"Якшанба_Душанба_Сешанба_Чоршанба_Пайшанба_Жума_Шанба".split("_"),weekdaysShort:"Якш_Душ_Сеш_Чор_Пай_Жум_Шан".split("_"),weekdaysMin:"Як_Ду_Се_Чо_Па_Жу_Ша".split("_"),longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"D MMMM YYYY, dddd HH:mm"}
,calendar:{
sameDay:"[Бугун соат] LT [да]",nextDay:"[Эртага] LT [да]",nextWeek:"dddd [куни соат] LT [да]",lastDay:"[Кеча соат] LT [да]",lastWeek:"[Утган] dddd [куни соат] LT [да]",sameElse:"L"}
,relativeTime:{
future:"Якин %s ичида",past:"Бир неча %s олдин",s:"фурсат",m:"бир дакика",mm:"%d дакика",h:"бир соат",hh:"%d соат",d:"бир кун",dd:"%d кун",M:"бир ой",MM:"%d ой",y:"бир йил",yy:"%d йил"}
,week:{
dow:1,doy:7}
}
),eut=n.defineLocale("vi",{
months:"tháng 1_tháng 2_tháng 3_tháng 4_tháng 5_tháng 6_tháng 7_tháng 8_tháng 9_tháng 10_tháng 11_tháng 12".split("_"),monthsShort:"Th01_Th02_Th03_Th04_Th05_Th06_Th07_Th08_Th09_Th10_Th11_Th12".split("_"),monthsParseExact:!0,weekdays:"chủ nhật_thứ hai_thứ ba_thứ tư_thứ năm_thứ sáu_thứ bảy".split("_"),weekdaysShort:"CN_T2_T3_T4_T5_T6_T7".split("_"),weekdaysMin:"CN_T2_T3_T4_T5_T6_T7".split("_"),weekdaysParseExact:!0,meridiemParse:/sa|ch/i,isPM:function(n){
return/^ch$/i.test(n)}
,meridiem:function(n,t,i){
return n<12?i?"sa":"SA":i?"ch":"CH"}
,longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D MMMM [năm] YYYY",LLL:"D MMMM [năm] YYYY HH:mm",LLLL:"dddd, D MMMM [năm] YYYY HH:mm",l:"DD/M/YYYY",ll:"D MMM YYYY",lll:"D MMM YYYY HH:mm",llll:"ddd, D MMM YYYY HH:mm"}
,calendar:{
sameDay:"[Hôm nay lúc] LT",nextDay:"[Ngày mai lúc] LT",nextWeek:"dddd [tuần tới lúc] LT",lastDay:"[Hôm qua lúc] LT",lastWeek:"dddd [tuần rồi lúc] LT",sameElse:"L"}
,relativeTime:{
future:"%s tới",past:"%s trước",s:"vài giây",m:"một phút",mm:"%d phút",h:"một giờ",hh:"%d giờ",d:"một ngày",dd:"%d ngày",M:"một tháng",MM:"%d tháng",y:"một năm",yy:"%d năm"}
,ordinalParse:/\d{
1,2}
/,ordinal:function(n){
return n}
,week:{
dow:1,doy:4}
}
),out=n.defineLocale("x-pseudo",{
months:"J~áñúá~rý_F~ébrú~árý_~Márc~h_Áp~ríl_~Máý_~Júñé~_Júl~ý_Áú~gúst~_Sép~témb~ér_Ó~ctób~ér_Ñ~óvém~bér_~Décé~mbér".split("_"),monthsShort:"J~áñ_~Féb_~Már_~Ápr_~Máý_~Júñ_~Júl_~Áúg_~Sép_~Óct_~Ñóv_~Déc".split("_"),monthsParseExact:!0,weekdays:"S~úñdá~ý_Mó~ñdáý~_Túé~sdáý~_Wéd~ñésd~áý_T~húrs~dáý_~Fríd~áý_S~átúr~dáý".split("_"),weekdaysShort:"S~úñ_~Móñ_~Túé_~Wéd_~Thú_~Frí_~Sát".split("_"),weekdaysMin:"S~ú_Mó~_Tú_~Wé_T~h_Fr~_Sá".split("_"),weekdaysParseExact:!0,longDateFormat:{
LT:"HH:mm",L:"DD/MM/YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"}
,calendar:{
sameDay:"[T~ódá~ý át] LT",nextDay:"[T~ómó~rró~w át] LT",nextWeek:"dddd [át] LT",lastDay:"[Ý~ést~érdá~ý át] LT",lastWeek:"[L~ást] dddd [át] LT",sameElse:"L"}
,relativeTime:{
future:"í~ñ %s",past:"%s á~gó",s:"á ~féw ~sécó~ñds",m:"á ~míñ~úté",mm:"%d m~íñú~tés",h:"á~ñ hó~úr",hh:"%d h~óúrs",d:"á ~dáý",dd:"%d d~áýs",M:"á ~móñ~th",MM:"%d m~óñt~hs",y:"á ~ýéár",yy:"%d ý~éárs"}
,ordinalParse:/\d{
1,2}
(th|st|nd|rd)/,ordinal:function(n){
var t=n%10,i=~~(n%100/10)==1?"th":t===1?"st":t===2?"nd":t===3?"rd":"th";
return n+i}
,week:{
dow:1,doy:4}
}
),sut=n.defineLocale("zh-cn",{
months:"一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月".split("_"),monthsShort:"1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月".split("_"),weekdays:"星期日_星期一_星期二_星期三_星期四_星期五_星期六".split("_"),weekdaysShort:"周日_周一_周二_周三_周四_周五_周六".split("_"),weekdaysMin:"日_一_二_三_四_五_六".split("_"),longDateFormat:{
LT:"Ah点mm分",LTS:"Ah点m分s秒",L:"YYYY-MM-DD",LL:"YYYY年MMMD日",LLL:"YYYY年MMMD日Ah点mm分",LLLL:"YYYY年MMMD日ddddAh点mm分",l:"YYYY-MM-DD",ll:"YYYY年MMMD日",lll:"YYYY年MMMD日Ah点mm分",llll:"YYYY年MMMD日ddddAh点mm分"}
,meridiemParse:/凌晨|早上|上午|中午|下午|晚上/,meridiemHour:function(n,t){
return n===12&&(n=0),t==="凌晨"||t==="早上"||t==="上午"?n:t==="下午"||t==="晚上"?n+12:n>=11?n:n+12}
,meridiem:function(n,t){
var i=n*100+t;
return i<600?"凌晨":i<900?"早上":i<1130?"上午":i<1230?"中午":i<1800?"下午":"晚上"}
,calendar:{
sameDay:function(){
return this.minutes()===0?"[今天]Ah[点整]":"[今天]LT"}
,nextDay:function(){
return this.minutes()===0?"[明天]Ah[点整]":"[明天]LT"}
,lastDay:function(){
return this.minutes()===0?"[昨天]Ah[点整]":"[昨天]LT"}
,nextWeek:function(){
var i,t;
return i=n().startOf("week"),t=this.diff(i,"days")>=7?"[下]":"[本]",this.minutes()===0?t+"dddAh点整":t+"dddAh点mm"}
,lastWeek:function(){
var i,t;
return i=n().startOf("week"),t=this.unix()<i.unix()?"[上]":"[本]",this.minutes()===0?t+"dddAh点整":t+"dddAh点mm"}
,sameElse:"LL"}
,ordinalParse:/\d{
1,2}
(日|月|周)/,ordinal:function(n,t){
switch(t){
case"d":case"D":case"DDD":return n+"日";
case"M":return n+"月";
case"w":case"W":return n+"周";
default:return n}
}
,relativeTime:{
future:"%s内",past:"%s前",s:"几秒",m:"1 分钟",mm:"%d 分钟",h:"1 小时",hh:"%d 小时",d:"1 天",dd:"%d 天",M:"1 个月",MM:"%d 个月",y:"1 年",yy:"%d 年"}
,week:{
dow:1,doy:4}
}
),hut=n.defineLocale("zh-tw",{
months:"一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月".split("_"),monthsShort:"1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月".split("_"),weekdays:"星期日_星期一_星期二_星期三_星期四_星期五_星期六".split("_"),weekdaysShort:"週日_週一_週二_週三_週四_週五_週六".split("_"),weekdaysMin:"日_一_二_三_四_五_六".split("_"),longDateFormat:{
LT:"Ah點mm分",LTS:"Ah點m分s秒",L:"YYYY年MMMD日",LL:"YYYY年MMMD日",LLL:"YYYY年MMMD日Ah點mm分",LLLL:"YYYY年MMMD日ddddAh點mm分",l:"YYYY年MMMD日",ll:"YYYY年MMMD日",lll:"YYYY年MMMD日Ah點mm分",llll:"YYYY年MMMD日ddddAh點mm分"}
,meridiemParse:/早上|上午|中午|下午|晚上/,meridiemHour:function(n,t){
return(n===12&&(n=0),t==="早上"||t==="上午")?n:t==="中午"?n>=11?n:n+12:t==="下午"||t==="晚上"?n+12:void 0}
,meridiem:function(n,t){
var i=n*100+t;
return i<900?"早上":i<1130?"上午":i<1230?"中午":i<1800?"下午":"晚上"}
,calendar:{
sameDay:"[今天]LT",nextDay:"[明天]LT",nextWeek:"[下]ddddLT",lastDay:"[昨天]LT",lastWeek:"[上]ddddLT",sameElse:"L"}
,ordinalParse:/\d{
1,2}
(日|月|週)/,ordinal:function(n,t){
switch(t){
case"d":case"D":case"DDD":return n+"日";
case"M":return n+"月";
case"w":case"W":return n+"週";
default:return n}
}
,relativeTime:{
future:"%s內",past:"%s前",s:"幾秒",m:"1分鐘",mm:"%d分鐘",h:"1小時",hh:"%d小時",d:"1天",dd:"%d天",M:"1個月",MM:"%d個月",y:"1年",yy:"%d年"}
}
),ol=n;
return ol.locale("en"),ol}
);
moment.updateLocale("de",{
longDateFormat:{
LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY HH:mm",LLLL:"dddd, D. MMMM YYYY HH:mm"}
}
);
!function(n){
"use strict";
if("function"==typeof define&&define.amd)define(["jquery","moment"],n);
else if("object"==typeof exports)n(require("jquery"),require("moment"));
else{
if("undefined"==typeof jQuery)throw"bootstrap-datetimepicker requires jQuery to be loaded first";
if("undefined"==typeof moment)throw"bootstrap-datetimepicker requires Moment.js to be loaded first";
n(jQuery,moment)}
}
(function(n,t){
"use strict";
if(!t)throw new Error("bootstrap-datetimepicker requires Moment.js to be loaded first");
var i=function(i,r){
var s,k,y,tt,b,u={
}
,e=t().startOf("d"),o=e.clone(),d=!0,l=!1,f=!1,g=0,et=[{
clsName:"days",navFnc:"M",navStep:1}
,{
clsName:"months",navFnc:"y",navStep:1}
,{
clsName:"years",navFnc:"y",navStep:10}
,{
clsName:"decades",navFnc:"y",navStep:100}
],at=["days","months","years","decades"],pt=["top","bottom","auto"],wt=["left","right","auto"],bt=["default","top","bottom"],kt={
up:38,38:"up",down:40,40:"down",left:37,37:"left",right:39,39:"right",tab:9,9:"tab",escape:27,27:"escape",enter:13,13:"enter",pageUp:33,33:"pageUp",pageDown:34,34:"pageDown",shift:16,16:"shift",control:17,17:"control",space:32,32:"space",t:84,84:"t","delete":46,46:"delete"}
,ot={
}
,p=function(n){
if("string"!=typeof n||n.length>1)throw new TypeError("isEnabled expects a single character string parameter");
switch(n){
case"y":return-1!==y.indexOf("Y");
case"M":return-1!==y.indexOf("M");
case"d":return-1!==y.toLowerCase().indexOf("d");
case"h":case"H":return-1!==y.toLowerCase().indexOf("h");
case"m":return-1!==y.indexOf("m");
case"s":return-1!==y.indexOf("s");
default:return!1}
}
,st=function(){
return p("h")||p("m")||p("s")}
,ht=function(){
return p("y")||p("M")||p("d")}
,ui=function(){
var t=n("<thead>").append(n("<tr>").append(n("<th>").addClass("prev").attr("data-action","previous").append(n("<span>").addClass(r.icons.previous))).append(n("<th>").addClass("picker-switch").attr("data-action","pickerSwitch").attr("colspan",r.calendarWeeks?"6":"5")).append(n("<th>").addClass("next").attr("data-action","next").append(n("<span>").addClass(r.icons.next)))),i=n("<tbody>").append(n("<tr>").append(n("<td>").attr("colspan",r.calendarWeeks?"8":"7")));
return[n("<div>").addClass("datepicker-days").append(n("<table>").addClass("table-condensed").append(t).append(n("<tbody>"))),n("<div>").addClass("datepicker-months").append(n("<table>").addClass("table-condensed").append(t.clone()).append(i.clone())),n("<div>").addClass("datepicker-years").append(n("<table>").addClass("table-condensed").append(t.clone()).append(i.clone())),n("<div>").addClass("datepicker-decades").append(n("<table>").addClass("table-condensed").append(t.clone()).append(i.clone()))]}
,fi=function(){
var t=n("<tr>"),i=n("<tr>"),u=n("<tr>");
return p("h")&&(t.append(n("<td>").append(n("<a>").attr({
href:"#",tabindex:"-1",title:"Increment Hour"}
).addClass("btn").attr("data-action","incrementHours").append(n("<span>").addClass(r.icons.up)))),i.append(n("<td>").append(n("<span>").addClass("timepicker-hour").attr({
"data-time-component":"hours",title:"Pick Hour"}
).attr("data-action","showHours"))),u.append(n("<td>").append(n("<a>").attr({
href:"#",tabindex:"-1",title:"Decrement Hour"}
).addClass("btn").attr("data-action","decrementHours").append(n("<span>").addClass(r.icons.down))))),p("m")&&(p("h")&&(t.append(n("<td>").addClass("separator")),i.append(n("<td>").addClass("separator").html(":")),u.append(n("<td>").addClass("separator"))),t.append(n("<td>").append(n("<a>").attr({
href:"#",tabindex:"-1",title:"Increment Minute"}
).addClass("btn").attr("data-action","incrementMinutes").append(n("<span>").addClass(r.icons.up)))),i.append(n("<td>").append(n("<span>").addClass("timepicker-minute").attr({
"data-time-component":"minutes",title:"Pick Minute"}
).attr("data-action","showMinutes"))),u.append(n("<td>").append(n("<a>").attr({
href:"#",tabindex:"-1",title:"Decrement Minute"}
).addClass("btn").attr("data-action","decrementMinutes").append(n("<span>").addClass(r.icons.down))))),p("s")&&(p("m")&&(t.append(n("<td>").addClass("separator")),i.append(n("<td>").addClass("separator").html(":")),u.append(n("<td>").addClass("separator"))),t.append(n("<td>").append(n("<a>").attr({
href:"#",tabindex:"-1",title:"Increment Second"}
).addClass("btn").attr("data-action","incrementSeconds").append(n("<span>").addClass(r.icons.up)))),i.append(n("<td>").append(n("<span>").addClass("timepicker-second").attr({
"data-time-component":"seconds",title:"Pick Second"}
).attr("data-action","showSeconds"))),u.append(n("<td>").append(n("<a>").attr({
href:"#",tabindex:"-1",title:"Decrement Second"}
).addClass("btn").attr("data-action","decrementSeconds").append(n("<span>").addClass(r.icons.down))))),k||(t.append(n("<td>").addClass("separator")),i.append(n("<td>").append(n("<button>").addClass("btn btn-primary").attr({
"data-action":"togglePeriod",tabindex:"-1",title:"Toggle Period"}
))),u.append(n("<td>").addClass("separator"))),n("<div>").addClass("timepicker-picker").append(n("<table>").addClass("table-condensed").append([t,i,u]))}
,ei=function(){
var i=n("<div>").addClass("timepicker-hours").append(n("<table>").addClass("table-condensed")),r=n("<div>").addClass("timepicker-minutes").append(n("<table>").addClass("table-condensed")),u=n("<div>").addClass("timepicker-seconds").append(n("<table>").addClass("table-condensed")),t=[fi()];
return p("h")&&t.push(i),p("m")&&t.push(r),p("s")&&t.push(u),t}
,oi=function(){
var t=[];
return r.showTodayButton&&t.push(n("<td>").append(n("<a>").attr({
"data-action":"today",title:r.tooltips.today}
).append(n("<span>").addClass(r.icons.today)))),!r.sideBySide&&ht()&&st()&&t.push(n("<td>").append(n("<a>").attr({
"data-action":"togglePicker",title:"Select Time"}
).append(n("<span>").addClass(r.icons.time)))),r.showClear&&t.push(n("<td>").append(n("<a>").attr({
"data-action":"clear",title:r.tooltips.clear}
).append(n("<span>").addClass(r.icons.clear)))),r.showClose&&t.push(n("<td>").append(n("<a>").attr({
"data-action":"close",title:r.tooltips.close}
).append(n("<span>").addClass(r.icons.close)))),n("<table>").addClass("table-condensed").append(n("<tbody>").append(n("<tr>").append(t)))}
,si=function(){
var t=n("<div>").addClass("bootstrap-datetimepicker-widget dropdown-menu"),f=n("<div>").addClass("datepicker").append(ui()),e=n("<div>").addClass("timepicker").append(ei()),i=n("<ul>").addClass("list-unstyled"),u=n("<li>").addClass("picker-switch"+(r.collapse?" accordion-toggle":"")).append(oi());
return r.inline&&t.removeClass("dropdown-menu"),k&&t.addClass("usetwentyfour"),p("s")&&!k&&t.addClass("wider"),r.sideBySide&&ht()&&st()?(t.addClass("timepicker-sbs"),"top"===r.toolbarPlacement&&t.append(u),t.append(n("<div>").addClass("row").append(f.addClass("col-md-6")).append(e.addClass("col-md-6"))),"bottom"===r.toolbarPlacement&&t.append(u),t):("top"===r.toolbarPlacement&&i.append(u),ht()&&i.append(n("<li>").addClass(r.collapse&&st()?"collapse in":"").append(f)),"default"===r.toolbarPlacement&&i.append(u),st()&&i.append(n("<li>").addClass(r.collapse&&ht()?"collapse":"").append(e)),"bottom"===r.toolbarPlacement&&i.append(u),t.append(i))}
,hi=function(){
var t,u={
}
;
return t=i.is("input")||r.inline?i.data():i.find("input").data(),t.dateOptions&&t.dateOptions instanceof Object&&(u=n.extend(!0,u,t.dateOptions)),n.each(r,
function(n){
var i="date"+n.charAt(0).toUpperCase()+n.slice(1);
void 0!==t[i]&&(u[n]=t[i])}
),u}
,vt=function(){
var t,o=(l||i).position(),s=(l||i).offset(),u=r.widgetPositioning.vertical,e=r.widgetPositioning.horizontal;
if(r.widgetParent)t=r.widgetParent.append(f);
else if(i.is("input"))t=i.after(f).parent();
else{
if(r.inline)return void(t=i.append(f));
t=i;
i.children().first().after(f)}
if("auto"===u&&(u=s.top+1.5*f.height()>=n(window).height()+n(window).scrollTop()&&f.height()+i.outerHeight()<s.top?"top":"bottom"),"auto"===e&&(e=t.width()<s.left+f.outerWidth()/2&&s.left+f.outerWidth()>n(window).width()?"right":"left"),"top"===u?f.addClass("top").removeClass("bottom"):f.addClass("bottom").removeClass("top"),"right"===e?f.addClass("pull-right"):f.removeClass("pull-right"),"relative"!==t.css("position")&&(t=t.parents().filter(function(){
return"relative"===n(this).css("position")}
).first()),0===t.length)throw new Error("datetimepicker component should be placed within a relative positioned container");
f.css({
top:"top"===u?"auto":o.top+i.outerHeight(),bottom:"top"===u?o.top+i.outerHeight():"auto",left:"left"===e?t===i?0:o.left:"auto",right:"left"===e?"auto":t.outerWidth()-i.outerWidth()-(t===i?0:o.left)}
)}
,it=function(n){
"dp.change"===n.type&&(n.date&&n.date.isSame(n.oldDate)||!n.date&&!n.oldDate)||i.trigger(n)}
,rt=function(n){
"y"===n&&(n="YYYY");
it({
type:"dp.update",change:n,viewDate:o.clone()}
)}
,ut=function(n){
f&&(n&&(b=Math.max(g,Math.min(3,b+n))),f.find(".datepicker > div").hide().filter(".datepicker-"+et[b].clsName).show())}
,ci=function(){
var t=n("<tr>"),i=o.clone().startOf("w").startOf("d");
for(r.calendarWeeks===!0&&t.append(n("<th>").addClass("cw").text("#"));
i.isBefore(o.clone().endOf("w"));
)t.append(n("<th>").addClass("dow").text(i.format("dd"))),i.add(1,"d");
f.find(".datepicker-days thead").append(t)}
,li=function(n){
return r.disabledDates[n.format("YYYY-MM-DD")]===!0}
,ai=function(n){
return r.enabledDates[n.format("YYYY-MM-DD")]===!0}
,vi=function(n){
return r.disabledHours[n.format("H")]===!0}
,yi=function(n){
return r.enabledHours[n.format("H")]===!0}
,c=function(t,i){
if(!t.isValid()||r.disabledDates&&"d"===i&&li(t)||r.enabledDates&&"d"===i&&!ai(t)||r.minDate&&t.isBefore(r.minDate,i)||r.maxDate&&t.isAfter(r.maxDate,i)||r.daysOfWeekDisabled&&"d"===i&&-1!==r.daysOfWeekDisabled.indexOf(t.day())||r.disabledHours&&("h"===i||"m"===i||"s"===i)&&vi(t)||r.enabledHours&&("h"===i||"m"===i||"s"===i)&&!yi(t))return!1;
if(r.disabledTimeIntervals&&("h"===i||"m"===i||"s"===i)){
var u=!1;
if(n.each(r.disabledTimeIntervals,
function(){
if(t.isBetween(this[0],this[1]))return(u=!0,!1)}
),u)return!1}
return!0}
,pi=function(){
for(var i=[],t=o.clone().startOf("y").startOf("d");
t.isSame(o,"y");
)i.push(n("<span>").attr("data-action","selectMonth").addClass("month").text(t.format("MMM"))),t.add(1,"M");
f.find(".datepicker-months td").empty().append(i)}
,wi=function(){
var i=f.find(".datepicker-months"),t=i.find("th"),u=i.find("tbody").find("span");
t.eq(0).find("span").attr("title",r.tooltips.prevYear);
t.eq(1).attr("title",r.tooltips.selectYear);
t.eq(2).find("span").attr("title",r.tooltips.nextYear);
i.find(".disabled").removeClass("disabled");
c(o.clone().subtract(1,"y"),"y")||t.eq(0).addClass("disabled");
t.eq(1).text(o.year());
c(o.clone().add(1,"y"),"y")||t.eq(2).addClass("disabled");
u.removeClass("active");
e.isSame(o,"y")&&!d&&u.eq(e.month()).addClass("active");
u.each(function(t){
c(o.clone().month(t),"M")||n(this).addClass("disabled")}
)}
,bi=function(){
var i=f.find(".datepicker-years"),t=i.find("th"),n=o.clone().subtract(5,"y"),u=o.clone().add(6,"y"),s="";
for(t.eq(0).find("span").attr("title",r.tooltips.nextDecade),t.eq(1).attr("title",r.tooltips.selectDecade),t.eq(2).find("span").attr("title",r.tooltips.prevDecade),i.find(".disabled").removeClass("disabled"),r.minDate&&r.minDate.isAfter(n,"y")&&t.eq(0).addClass("disabled"),t.eq(1).text(n.year()+"-"+u.year()),r.maxDate&&r.maxDate.isBefore(u,"y")&&t.eq(2).addClass("disabled");
!n.isAfter(u,"y");
)s+='<span data-action="selectYear" class="year'+(n.isSame(e,"y")&&!d?" active":"")+(c(n,"y")?"":" disabled")+'">'+n.year()+"<\/span>",n.add(1,"y");
i.find("td").html(s)}
,ki=function(){
var u=f.find(".datepicker-decades"),i=u.find("th"),n=t(o.isBefore(t({
y:1999}
))?{
y:1899}
:{
y:1999}
),s=n.clone().add(100,"y"),h="";
for(i.eq(0).find("span").attr("title",r.tooltips.prevCentury),i.eq(2).find("span").attr("title",r.tooltips.nextCentury),u.find(".disabled").removeClass("disabled"),(n.isSame(t({
y:1900}
))||r.minDate&&r.minDate.isAfter(n,"y"))&&i.eq(0).addClass("disabled"),i.eq(1).text(n.year()+"-"+s.year()),(n.isSame(t({
y:2e3}
))||r.maxDate&&r.maxDate.isBefore(s,"y"))&&i.eq(2).addClass("disabled");
!n.isAfter(s,"y");
)h+='<span data-action="selectDecade" class="decade'+(n.isSame(e,"y")?" active":"")+(c(n,"y")?"":" disabled")+'" data-selection="'+(n.year()+6)+'">'+(n.year()+1)+" - "+(n.year()+12)+"<\/span>",n.add(12,"y");
h+="<span><\/span><span><\/span><span><\/span>";
u.find("td").html(h)}
,ft=function(){
var i,h,u,l,a=f.find(".datepicker-days"),s=a.find("th"),v=[];
if(ht()){
for(s.eq(0).find("span").attr("title",r.tooltips.prevMonth),s.eq(1).attr("title",r.tooltips.selectMonth),s.eq(2).find("span").attr("title",r.tooltips.nextMonth),a.find(".disabled").removeClass("disabled"),s.eq(1).text(o.format(r.dayViewHeaderFormat)),c(o.clone().subtract(1,"M"),"M")||s.eq(0).addClass("disabled"),c(o.clone().add(1,"M"),"M")||s.eq(2).addClass("disabled"),i=o.clone().startOf("M").startOf("w").startOf("d"),l=0;
42>l;
l++)0===i.weekday()&&(h=n("<tr>"),r.calendarWeeks&&h.append('<td class="cw">'+i.week()+"<\/td>"),v.push(h)),u="",i.isBefore(o,"M")&&(u+=" old"),i.isAfter(o,"M")&&(u+=" new"),i.isSame(e,"d")&&!d&&(u+=" active"),c(i,"d")||(u+=" disabled"),i.isSame(t(),"d")&&(u+=" today"),(0===i.day()||6===i.day())&&(u+=" weekend"),h.append('<td data-action="selectDay" data-day="'+i.format("L")+'" class="day'+u+'">'+i.date()+"<\/td>"),i.add(1,"d");
a.find("tbody").empty().append(v);
wi();
bi();
ki()}
}
,di=function(){
var u=f.find(".timepicker-hours table"),t=o.clone().startOf("d"),r=[],i=n("<tr>");
for(o.hour()>11&&!k&&t.hour(12);
t.isSame(o,"d")&&(k||o.hour()<12&&t.hour()<12||o.hour()>11);
)t.hour()%4==0&&(i=n("<tr>"),r.push(i)),i.append('<td data-action="selectHour" class="hour'+(c(t,"h")?"":" disabled")+'">'+t.format(k?"HH":"hh")+"<\/td>"),t.add(1,"h");
u.empty().append(r)}
,gi=function(){
for(var s=f.find(".timepicker-minutes table"),t=o.clone().startOf("h"),u=[],i=n("<tr>"),e=1===r.stepping?5:r.stepping;
o.isSame(t,"h");
)t.minute()%(4*e)==0&&(i=n("<tr>"),u.push(i)),i.append('<td data-action="selectMinute" class="minute'+(c(t,"m")?"":" disabled")+'">'+t.format("mm")+"<\/td>"),t.add(e,"m");
s.empty().append(u)}
,nr=function(){
for(var u=f.find(".timepicker-seconds table"),t=o.clone().startOf("m"),r=[],i=n("<tr>");
o.isSame(t,"m");
)t.second()%20==0&&(i=n("<tr>"),r.push(i)),i.append('<td data-action="selectSecond" class="second'+(c(t,"s")?"":" disabled")+'">'+t.format("ss")+"<\/td>"),t.add(5,"s");
u.empty().append(r)}
,tr=function(){
var n,i,t=f.find(".timepicker span[data-time-component]");
k||(n=f.find(".timepicker [data-action=togglePeriod]"),i=e.clone().add(e.hours()>=12?-12:12,"h"),n.text(e.format("A")),c(i,"h")?n.removeClass("disabled"):n.addClass("disabled"));
t.filter("[data-time-component=hours]").text(e.format(k?"HH":"hh"));
t.filter("[data-time-component=minutes]").text(e.format("mm"));
t.filter("[data-time-component=seconds]").text(e.format("ss"));
di();
gi();
nr()}
,a=function(){
f&&(ft(),tr())}
,h=function(n){
var t=d?null:e;
return n?(n=n.clone().locale(r.locale),1!==r.stepping&&n.minutes(Math.round(n.minutes()/r.stepping)*r.stepping%60).seconds(0),void(c(n)?(e=n,o=e.clone(),s.val(e.format(y)),i.data("date",e.format(y)),d=!1,a(),it({
type:"dp.change",date:e.clone(),oldDate:t}
)):(r.keepInvalid||s.val(d?"":e.format(y)),it({
type:"dp.error",date:n}
)))):(d=!0,s.val(""),i.data("date",""),it({
type:"dp.change",date:!1,oldDate:t}
),void a())}
,v=function(){
var t=!1;
return f?(f.find(".collapse").each(function(){
var i=n(this).data("collapse");
return i&&i.transitioning?(t=!0,!1):!0}
),t?u:(l&&l.hasClass("btn")&&l.toggleClass("active"),f.hide(),n(window).off("resize",vt),f.off("click","[data-action]"),f.off("mousedown",!1),f.remove(),f=!1,it({
type:"dp.hide",date:e.clone()}
),s.blur(),u)):u}
,dt=function(){
h(null)}
,ct={
next:function(){
var n=et[b].navFnc;
o.add(et[b].navStep,n);
ft();
rt(n)}
,previous:function(){
var n=et[b].navFnc;
o.subtract(et[b].navStep,n);
ft();
rt(n)}
,pickerSwitch:function(){
ut(1)}
,selectMonth:function(t){
var i=n(t.target).closest("tbody").find("span").index(n(t.target));
o.month(i);
b===g?(h(e.clone().year(o.year()).month(o.month())),r.inline||v()):(ut(-1),ft());
rt("M")}
,selectYear:function(t){
var i=parseInt(n(t.target).text(),10)||0;
o.year(i);
b===g?(h(e.clone().year(o.year())),r.inline||v()):(ut(-1),ft());
rt("YYYY")}
,selectDecade:function(t){
var i=parseInt(n(t.target).data("selection"),10)||0;
o.year(i);
b===g?(h(e.clone().year(o.year())),r.inline||v()):(ut(-1),ft());
rt("YYYY")}
,selectDay:function(t){
var i=o.clone();
n(t.target).is(".old")&&i.subtract(1,"M");
n(t.target).is(".new")&&i.add(1,"M");
h(i.date(parseInt(n(t.target).text(),10)));
st()||r.keepOpen||r.inline||v()}
,incrementHours:function(){
var n=e.clone().add(1,"h");
c(n,"h")&&h(n)}
,incrementMinutes:function(){
var n=e.clone().add(r.stepping,"m");
c(n,"m")&&h(n)}
,incrementSeconds:function(){
var n=e.clone().add(1,"s");
c(n,"s")&&h(n)}
,decrementHours:function(){
var n=e.clone().subtract(1,"h");
c(n,"h")&&h(n)}
,decrementMinutes:function(){
var n=e.clone().subtract(r.stepping,"m");
c(n,"m")&&h(n)}
,decrementSeconds:function(){
var n=e.clone().subtract(1,"s");
c(n,"s")&&h(n)}
,togglePeriod:function(){
h(e.clone().add(e.hours()>=12?-12:12,"h"))}
,togglePicker:function(t){
var f,u=n(t.target),e=u.closest("ul"),i=e.find(".in"),o=e.find(".collapse:not(.in)");
if(i&&i.length){
if(f=i.data("collapse"),f&&f.transitioning)return;
i.collapse?(i.collapse("hide"),o.collapse("show")):(i.removeClass("in"),o.addClass("in"));
u.is("span")?u.toggleClass(r.icons.time+" "+r.icons.date):u.find("span").toggleClass(r.icons.time+" "+r.icons.date)}
}
,showPicker:function(){
f.find(".timepicker > div:not(.timepicker-picker)").hide();
f.find(".timepicker .timepicker-picker").show()}
,showHours:function(){
f.find(".timepicker .timepicker-picker").hide();
f.find(".timepicker .timepicker-hours").show()}
,showMinutes:function(){
f.find(".timepicker .timepicker-picker").hide();
f.find(".timepicker .timepicker-minutes").show()}
,showSeconds:function(){
f.find(".timepicker .timepicker-picker").hide();
f.find(".timepicker .timepicker-seconds").show()}
,selectHour:function(t){
var i=parseInt(n(t.target).text(),10);
k||(e.hours()>=12?12!==i&&(i+=12):12===i&&(i=0));
h(e.clone().hours(i));
ct.showPicker.call(u)}
,selectMinute:function(t){
h(e.clone().minutes(parseInt(n(t.target).text(),10)));
ct.showPicker.call(u)}
,selectSecond:function(t){
h(e.clone().seconds(parseInt(n(t.target).text(),10)));
ct.showPicker.call(u)}
,clear:dt,today:function(){
c(t(),"d")&&h(t())}
,close:v}
,ir=function(t){
return n(t.currentTarget).is(".disabled")?!1:(ct[n(t.currentTarget).data("action")].apply(u,arguments),!1)}
,w=function(){
var i,e={
year:function(n){
return n.month(0).date(1).hours(0).seconds(0).minutes(0)}
,month:function(n){
return n.date(1).hours(0).seconds(0).minutes(0)}
,day:function(n){
return n.hours(0).seconds(0).minutes(0)}
,hour:function(n){
return n.seconds(0).minutes(0)}
,minute:function(n){
return n.seconds(0)}
}
;
return s.prop("disabled")||!r.ignoreReadonly&&s.prop("readonly")||f?u:(void 0!==s.val()&&0!==s.val().trim().length?h(nt(s.val().trim())):r.useCurrent&&d&&(s.is("input")&&0===s.val().trim().length||r.inline)&&(i=t(),"string"==typeof r.useCurrent&&(i=e[r.useCurrent](i)),h(i)),f=si(),ci(),pi(),f.find(".timepicker-hours").hide(),f.find(".timepicker-minutes").hide(),f.find(".timepicker-seconds").hide(),a(),ut(),n(window).on("resize",vt),f.on("click","[data-action]",ir),f.on("mousedown",!1),l&&l.hasClass("btn")&&l.toggleClass("active"),f.show(),vt(),r.focusOnShow&&!s.is(":focus")&&s.focus(),it({
type:"dp.show"}
),u)}
,yt=function(){
return f?v():w()}
,nt=function(n){
return n=void 0===r.parseInputDate?t.isMoment(n)||n instanceof Date?t(n):t(n,tt,r.useStrict):r.parseInputDate(n),n.locale(r.locale),n}
,gt=function(n){
var t,e,i,o,s=null,c=[],l={
}
,h=n.which,a="p";
ot[h]=a;
for(t in ot)ot.hasOwnProperty(t)&&ot[t]===a&&(c.push(t),parseInt(t,10)!==h&&(l[t]=!0));
for(t in r.keyBinds)if(r.keyBinds.hasOwnProperty(t)&&"function"==typeof r.keyBinds[t]&&(i=t.split(" "),i.length===c.length&&kt[h]===i[i.length-1])){
for(o=!0,e=i.length-2;
e>=0;
e--)if(!(kt[i[e]]in l)){
o=!1;
break}
if(o){
s=r.keyBinds[t];
break}
}
s&&(s.call(u,f),n.stopPropagation(),n.preventDefault())}
,ni=function(n){
ot[n.which]="r";
n.stopPropagation();
n.preventDefault()}
,ti=function(t){
var i=n(t.target).val().trim(),r=i?nt(i):null;
return h(r),t.stopImmediatePropagation(),!1}
,rr=function(){
s.on({
change:ti,blur:r.debug?"":v,keydown:gt,keyup:ni,focus:r.allowInputToggle?w:""}
);
i.is("input")?s.on({
focus:w}
):l&&(l.on("click",yt),l.on("mousedown",!1))}
,ur=function(){
s.off({
change:ti,blur:blur,keydown:gt,keyup:ni,focus:r.allowInputToggle?v:""}
);
i.is("input")?s.off({
focus:w}
):l&&(l.off("click",yt),l.off("mousedown",!1))}
,ii=function(t){
var i={
}
;
return n.each(t,
function(){
var n=nt(this);
n.isValid()&&(i[n.format("YYYY-MM-DD")]=!0)}
),Object.keys(i).length?i:!1}
,ri=function(t){
var i={
}
;
return n.each(t,
function(){
i[this]=!0}
),Object.keys(i).length?i:!1}
,lt=function(){
var n=r.format||"L LT";
y=n.replace(/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{
1,4}
)/g,
function(n){
var t=e.localeData().longDateFormat(n)||n;
return t.replace(/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{
1,4}
)/g,
function(n){
return e.localeData().longDateFormat(n)||n}
)}
);
tt=r.extraFormats?r.extraFormats.slice():[];
tt.indexOf(n)<0&&tt.indexOf(y)<0&&tt.push(y);
k=y.toLowerCase().indexOf("a")<1&&y.replace(/\[.*?\]/g,"").indexOf("h")<1;
p("y")&&(g=2);
p("M")&&(g=1);
p("d")&&(g=0);
b=Math.max(g,b);
d||h(e)}
;
if(u.destroy=function(){
v();
ur();
i.removeData("DateTimePicker");
i.removeData("date")}
,u.toggle=yt,u.show=w,u.hide=v,u.disable=function(){
return v(),l&&l.hasClass("btn")&&l.addClass("disabled"),s.prop("disabled",!0),u}
,u.enable=function(){
return l&&l.hasClass("btn")&&l.removeClass("disabled"),s.prop("disabled",!1),u}
,u.ignoreReadonly=function(n){
if(0===arguments.length)return r.ignoreReadonly;
if("boolean"!=typeof n)throw new TypeError("ignoreReadonly () expects a boolean parameter");
return r.ignoreReadonly=n,u}
,u.options=function(t){
if(0===arguments.length)return n.extend(!0,{
}
,r);
if(!(t instanceof Object))throw new TypeError("options() options parameter should be an object");
return n.extend(!0,r,t),n.each(r,
function(n,t){
if(void 0===u[n])throw new TypeError("option "+n+" is not recognized!");
u[n](t)}
),u}
,u.date=function(n){
if(0===arguments.length)return d?null:e.clone();
if(!(null===n||"string"==typeof n||t.isMoment(n)||n instanceof Date))throw new TypeError("date() parameter must be one of [null, string, moment or Date]");
return h(null===n?null:nt(n)),u}
,u.format=function(n){
if(0===arguments.length)return r.format;
if("string"!=typeof n&&("boolean"!=typeof n||n!==!1))throw new TypeError("format() expects a sting or boolean:false parameter "+n);
return r.format=n,y&&lt(),u}
,u.dayViewHeaderFormat=function(n){
if(0===arguments.length)return r.dayViewHeaderFormat;
if("string"!=typeof n)throw new TypeError("dayViewHeaderFormat() expects a string parameter");
return r.dayViewHeaderFormat=n,u}
,u.extraFormats=function(n){
if(0===arguments.length)return r.extraFormats;
if(n!==!1&&!(n instanceof Array))throw new TypeError("extraFormats() expects an array or false parameter");
return r.extraFormats=n,tt&&lt(),u}
,u.disabledDates=function(t){
if(0===arguments.length)return r.disabledDates?n.extend({
}
,r.disabledDates):r.disabledDates;
if(!t)return r.disabledDates=!1,a(),u;
if(!(t instanceof Array))throw new TypeError("disabledDates() expects an array parameter");
return r.disabledDates=ii(t),r.enabledDates=!1,a(),u}
,u.enabledDates=function(t){
if(0===arguments.length)return r.enabledDates?n.extend({
}
,r.enabledDates):r.enabledDates;
if(!t)return r.enabledDates=!1,a(),u;
if(!(t instanceof Array))throw new TypeError("enabledDates() expects an array parameter");
return r.enabledDates=ii(t),r.disabledDates=!1,a(),u}
,u.daysOfWeekDisabled=function(n){
if(0===arguments.length)return r.daysOfWeekDisabled.splice(0);
if("boolean"==typeof n&&!n)return r.daysOfWeekDisabled=!1,a(),u;
if(!(n instanceof Array))throw new TypeError("daysOfWeekDisabled() expects an array parameter");
if(r.daysOfWeekDisabled=n.reduce(function(n,t){
return t=parseInt(t,10),t>6||0>t||isNaN(t)?n:(-1===n.indexOf(t)&&n.push(t),n)}
,[]).sort(),r.useCurrent&&!r.keepInvalid){
for(var t=0;
!c(e,"d");
){
if(e.add(1,"d"),7===t)throw"Tried 7 times to find a valid date";
t++}
h(e)}
return a(),u}
,u.maxDate=function(n){
if(0===arguments.length)return r.maxDate?r.maxDate.clone():r.maxDate;
if("boolean"==typeof n&&n===!1)return r.maxDate=!1,a(),u;
"string"==typeof n&&("now"===n||"moment"===n)&&(n=t());
var i=nt(n);
if(!i.isValid())throw new TypeError("maxDate() Could not parse date parameter: "+n);
if(r.minDate&&i.isBefore(r.minDate))throw new TypeError("maxDate() date parameter is before options.minDate: "+i.format(y));
return r.maxDate=i,r.useCurrent&&!r.keepInvalid&&e.isAfter(n)&&h(r.maxDate),o.isAfter(i)&&(o=i.clone().subtract(r.stepping,"m")),a(),u}
,u.minDate=function(n){
if(0===arguments.length)return r.minDate?r.minDate.clone():r.minDate;
if("boolean"==typeof n&&n===!1)return r.minDate=!1,a(),u;
"string"==typeof n&&("now"===n||"moment"===n)&&(n=t());
var i=nt(n);
if(!i.isValid())throw new TypeError("minDate() Could not parse date parameter: "+n);
if(r.maxDate&&i.isAfter(r.maxDate))throw new TypeError("minDate() date parameter is after options.maxDate: "+i.format(y));
return r.minDate=i,r.useCurrent&&!r.keepInvalid&&e.isBefore(n)&&h(r.minDate),o.isBefore(i)&&(o=i.clone().add(r.stepping,"m")),a(),u}
,u.defaultDate=function(n){
if(0===arguments.length)return r.defaultDate?r.defaultDate.clone():r.defaultDate;
if(!n)return r.defaultDate=!1,u;
"string"==typeof n&&("now"===n||"moment"===n)&&(n=t());
var i=nt(n);
if(!i.isValid())throw new TypeError("defaultDate() Could not parse date parameter: "+n);
if(!c(i))throw new TypeError("defaultDate() date passed is invalid according to component setup validations");
return r.defaultDate=i,(r.defaultDate&&r.inline||""===s.val().trim()&&void 0===s.attr("placeholder"))&&h(r.defaultDate),u}
,u.locale=function(n){
if(POST_FIRSTDAY_WEEK&&t.locale(lang.slice(0,2),{
week:{
dow:POST_FIRSTDAY_WEEK}
}
),0===arguments.length)return r.locale;
if(!t.localeData(n))throw new TypeError("locale() locale "+n+" is not loaded from moment locales!");
return r.locale=n,e.locale(r.locale),o.locale(r.locale),y&&lt(),f&&(v(),w()),u}
,u.stepping=function(n){
return 0===arguments.length?r.stepping:(n=parseInt(n,10),(isNaN(n)||1>n)&&(n=1),r.stepping=n,u)}
,u.useCurrent=function(n){
var t=["year","month","day","hour","minute"];
if(0===arguments.length)return r.useCurrent;
if("boolean"!=typeof n&&"string"!=typeof n)throw new TypeError("useCurrent() expects a boolean or string parameter");
if("string"==typeof n&&-1===t.indexOf(n.toLowerCase()))throw new TypeError("useCurrent() expects a string parameter of "+t.join(", "));
return r.useCurrent=n,u}
,u.collapse=function(n){
if(0===arguments.length)return r.collapse;
if("boolean"!=typeof n)throw new TypeError("collapse() expects a boolean parameter");
return r.collapse===n?u:(r.collapse=n,f&&(v(),w()),u)}
,u.icons=function(t){
if(0===arguments.length)return n.extend({
}
,r.icons);
if(!(t instanceof Object))throw new TypeError("icons() expects parameter to be an Object");
return n.extend(r.icons,t),f&&(v(),w()),u}
,u.tooltips=function(t){
if(0===arguments.length)return n.extend({
}
,r.tooltips);
if(!(t instanceof Object))throw new TypeError("tooltips() expects parameter to be an Object");
return n.extend(r.tooltips,t),f&&(v(),w()),u}
,u.useStrict=function(n){
if(0===arguments.length)return r.useStrict;
if("boolean"!=typeof n)throw new TypeError("useStrict() expects a boolean parameter");
return r.useStrict=n,u}
,u.sideBySide=function(n){
if(0===arguments.length)return r.sideBySide;
if("boolean"!=typeof n)throw new TypeError("sideBySide() expects a boolean parameter");
return r.sideBySide=n,f&&(v(),w()),u}
,u.viewMode=function(n){
if(0===arguments.length)return r.viewMode;
if("string"!=typeof n)throw new TypeError("viewMode() expects a string parameter");
if(-1===at.indexOf(n))throw new TypeError("viewMode() parameter must be one of ("+at.join(", ")+") value");
return r.viewMode=n,b=Math.max(at.indexOf(n),g),ut(),u}
,u.toolbarPlacement=function(n){
if(0===arguments.length)return r.toolbarPlacement;
if("string"!=typeof n)throw new TypeError("toolbarPlacement() expects a string parameter");
if(-1===bt.indexOf(n))throw new TypeError("toolbarPlacement() parameter must be one of ("+bt.join(", ")+") value");
return r.toolbarPlacement=n,f&&(v(),w()),u}
,u.widgetPositioning=function(t){
if(0===arguments.length)return n.extend({
}
,r.widgetPositioning);
if("[object Object]"!=={
}
.toString.call(t))throw new TypeError("widgetPositioning() expects an object variable");
if(t.horizontal){
if("string"!=typeof t.horizontal)throw new TypeError("widgetPositioning() horizontal variable must be a string");
if(t.horizontal=t.horizontal.toLowerCase(),-1===wt.indexOf(t.horizontal))throw new TypeError("widgetPositioning() expects horizontal parameter to be one of ("+wt.join(", ")+")");
r.widgetPositioning.horizontal=t.horizontal}
if(t.vertical){
if("string"!=typeof t.vertical)throw new TypeError("widgetPositioning() vertical variable must be a string");
if(t.vertical=t.vertical.toLowerCase(),-1===pt.indexOf(t.vertical))throw new TypeError("widgetPositioning() expects vertical parameter to be one of ("+pt.join(", ")+")");
r.widgetPositioning.vertical=t.vertical}
return a(),u}
,u.calendarWeeks=function(n){
if(0===arguments.length)return r.calendarWeeks;
if("boolean"!=typeof n)throw new TypeError("calendarWeeks() expects parameter to be a boolean value");
return r.calendarWeeks=n,a(),u}
,u.showTodayButton=function(n){
if(0===arguments.length)return r.showTodayButton;
if("boolean"!=typeof n)throw new TypeError("showTodayButton() expects a boolean parameter");
return r.showTodayButton=n,f&&(v(),w()),u}
,u.showClear=function(n){
if(0===arguments.length)return r.showClear;
if("boolean"!=typeof n)throw new TypeError("showClear() expects a boolean parameter");
return r.showClear=n,f&&(v(),w()),u}
,u.widgetParent=function(t){
if(0===arguments.length)return r.widgetParent;
if("string"==typeof t&&(t=n(t)),null!==t&&"string"!=typeof t&&!(t instanceof n))throw new TypeError("widgetParent() expects a string or a jQuery object parameter");
return r.widgetParent=t,f&&(v(),w()),u}
,u.keepOpen=function(n){
if(0===arguments.length)return r.keepOpen;
if("boolean"!=typeof n)throw new TypeError("keepOpen() expects a boolean parameter");
return r.keepOpen=n,u}
,u.focusOnShow=function(n){
if(0===arguments.length)return r.focusOnShow;
if("boolean"!=typeof n)throw new TypeError("focusOnShow() expects a boolean parameter");
return r.focusOnShow=n,u}
,u.inline=function(n){
if(0===arguments.length)return r.inline;
if("boolean"!=typeof n)throw new TypeError("inline() expects a boolean parameter");
return r.inline=n,u}
,u.clear=function(){
return dt(),u}
,u.keyBinds=function(n){
return r.keyBinds=n,u}
,u.debug=function(n){
if("boolean"!=typeof n)throw new TypeError("debug() expects a boolean parameter");
return r.debug=n,u}
,u.allowInputToggle=function(n){
if(0===arguments.length)return r.allowInputToggle;
if("boolean"!=typeof n)throw new TypeError("allowInputToggle() expects a boolean parameter");
return r.allowInputToggle=n,u}
,u.showClose=function(n){
if(0===arguments.length)return r.showClose;
if("boolean"!=typeof n)throw new TypeError("showClose() expects a boolean parameter");
return r.showClose=n,u}
,u.keepInvalid=function(n){
if(0===arguments.length)return r.keepInvalid;
if("boolean"!=typeof n)throw new TypeError("keepInvalid() expects a boolean parameter");
return r.keepInvalid=n,u}
,u.datepickerInput=function(n){
if(0===arguments.length)return r.datepickerInput;
if("string"!=typeof n)throw new TypeError("datepickerInput() expects a string parameter");
return r.datepickerInput=n,u}
,u.parseInputDate=function(n){
if(0===arguments.length)return r.parseInputDate;
if("function"!=typeof n)throw new TypeError("parseInputDate() sholud be as function");
return r.parseInputDate=n,u}
,u.disabledTimeIntervals=function(t){
if(0===arguments.length)return r.disabledTimeIntervals?n.extend({
}
,r.disabledTimeIntervals):r.disabledTimeIntervals;
if(!t)return r.disabledTimeIntervals=!1,a(),u;
if(!(t instanceof Array))throw new TypeError("disabledTimeIntervals() expects an array parameter");
return r.disabledTimeIntervals=t,a(),u}
,u.disabledHours=function(t){
if(0===arguments.length)return r.disabledHours?n.extend({
}
,r.disabledHours):r.disabledHours;
if(!t)return r.disabledHours=!1,a(),u;
if(!(t instanceof Array))throw new TypeError("disabledHours() expects an array parameter");
if(r.disabledHours=ri(t),r.enabledHours=!1,r.useCurrent&&!r.keepInvalid){
for(var i=0;
!c(e,"h");
){
if(e.add(1,"h"),24===i)throw"Tried 24 times to find a valid date";
i++}
h(e)}
return a(),u}
,u.enabledHours=function(t){
if(0===arguments.length)return r.enabledHours?n.extend({
}
,r.enabledHours):r.enabledHours;
if(!t)return r.enabledHours=!1,a(),u;
if(!(t instanceof Array))throw new TypeError("enabledHours() expects an array parameter");
if(r.enabledHours=ri(t),r.disabledHours=!1,r.useCurrent&&!r.keepInvalid){
for(var i=0;
!c(e,"h");
){
if(e.add(1,"h"),24===i)throw"Tried 24 times to find a valid date";
i++}
h(e)}
return a(),u}
,u.viewDate=function(n){
if(0===arguments.length)return o.clone();
if(!n)return o=e.clone(),u;
if(!("string"==typeof n||t.isMoment(n)||n instanceof Date))throw new TypeError("viewDate() parameter must be one of [string, moment or Date]");
return o=nt(n),rt(),u}
,i.is("input"))s=i;
else if(s=i.find(r.datepickerInput),0===s.size())s=i.find("input");
else if(!s.is("input"))throw new Error('CSS class "'+r.datepickerInput+'" cannot be applied to non input element');
if(i.hasClass("input-group")&&(l=0===i.find(".datepickerbutton").size()?i.find(".input-group-addon"):i.find(".datepickerbutton")),!r.inline&&!s.is("input"))throw new Error("Could not initialize DateTimePicker without an input element");
return n.extend(!0,r,hi()),u.options(r),lt(),rr(),s.prop("disabled")&&u.disable(),s.is("input")&&0!==s.val().trim().length?h(nt(s.val().trim())):r.defaultDate&&void 0===s.attr("placeholder")&&h(r.defaultDate),r.inline&&w(),u}
;
n.fn.datetimepicker=function(t){
return this.each(function(){
var r=n(this);
r.data("DateTimePicker")||(t=n.extend(!0,{
}
,n.fn.datetimepicker.defaults,t),r.data("DateTimePicker",i(r,t)))}
)}
;
n.fn.datetimepicker.defaults={
format:!1,dayViewHeaderFormat:"MMMM YYYY",extraFormats:!1,stepping:1,minDate:!1,maxDate:!1,useCurrent:!0,collapse:!0,locale:t.locale(),defaultDate:!1,disabledDates:!1,enabledDates:!1,icons:{
time:"glyphicon glyphicon-time",date:"glyphicon glyphicon-calendar",up:"glyphicon glyphicon-chevron-up",down:"glyphicon glyphicon-chevron-down",previous:"glyphicon glyphicon-chevron-left",next:"glyphicon glyphicon-chevron-right",today:"glyphicon glyphicon-screenshot",clear:"glyphicon glyphicon-trash",close:"glyphicon glyphicon-remove"}
,tooltips:{
today:"Go to today",clear:"Clear selection",close:"Close the picker",selectMonth:"Select Month",prevMonth:"Previous Month",nextMonth:"Next Month",selectYear:"Select Year",prevYear:"Previous Year",nextYear:"Next Year",selectDecade:"Select Decade",prevDecade:"Previous Decade",nextDecade:"Next Decade",prevCentury:"Previous Century",nextCentury:"Next Century"}
,useStrict:!1,sideBySide:!1,daysOfWeekDisabled:!1,calendarWeeks:!1,viewMode:"days",toolbarPlacement:"default",showTodayButton:!1,showClear:!1,showClose:!1,widgetPositioning:{
horizontal:"auto",vertical:"auto"}
,widgetParent:null,ignoreReadonly:!1,keepOpen:!1,focusOnShow:!0,inline:!1,keepInvalid:!1,datepickerInput:".datepickerinput",keyBinds:{
up:function(n){
if(n){
var i=this.date()||t();
n.find(".datepicker").is(":visible")?this.date(i.clone().subtract(7,"d")):this.date(i.clone().add(this.stepping(),"m"))}
}
,down:function(n){
if(!n)return void this.show();
var i=this.date()||t();
n.find(".datepicker").is(":visible")?this.date(i.clone().add(7,"d")):this.date(i.clone().subtract(this.stepping(),"m"))}
,"control up":function(n){
if(n){
var i=this.date()||t();
n.find(".datepicker").is(":visible")?this.date(i.clone().subtract(1,"y")):this.date(i.clone().add(1,"h"))}
}
,"control down":function(n){
if(n){
var i=this.date()||t();
n.find(".datepicker").is(":visible")?this.date(i.clone().add(1,"y")):this.date(i.clone().subtract(1,"h"))}
}
,left:function(n){
if(n){
var i=this.date()||t();
n.find(".datepicker").is(":visible")&&this.date(i.clone().subtract(1,"d"))}
}
,right:function(n){
if(n){
var i=this.date()||t();
n.find(".datepicker").is(":visible")&&this.date(i.clone().add(1,"d"))}
}
,pageUp:function(n){
if(n){
var i=this.date()||t();
n.find(".datepicker").is(":visible")&&this.date(i.clone().subtract(1,"M"))}
}
,pageDown:function(n){
if(n){
var i=this.date()||t();
n.find(".datepicker").is(":visible")&&this.date(i.clone().add(1,"M"))}
}
,enter:function(){
this.hide()}
,escape:function(){
this.hide()}
,"control space":function(n){
n.find(".timepicker").is(":visible")&&n.find('.btn[data-action="togglePeriod"]').click()}
,t:function(){
this.date(t())}
,"delete":function(){
this.clear()}
}
,debug:!1,allowInputToggle:!1,disabledTimeIntervals:!1,disabledHours:!1,enabledHours:!1,viewDate:!1}
}
);
ValidationConfiguration=function(){
function n(n,t,i,r,u,f,e){
this.step=n;
this.inputSelector=t;
this.regexSelector=i;
this.labelSelector=r;
this.fieldAlertSelector=u;
this.pageAlertSelector=f;
this.errorMessage=e}
return n}
();
SharedAjaxService=function(){
function t(n,t,i,r){
return r=r||function(n){
console.error(n)}
,$.ajax({
url:n,type:"GET",cache:!1,traditional:!0,data:t,success:i,error:r}
)}
function n(n,t,i,r){
return r=r||function(n){
console.error(n)}
,$.ajax({
url:n,type:"POST",cache:!1,traditional:!0,data:t,success:i,error:r}
)}
var i="Captcha/SetCaptchaToken",r="Shared/DoCancelRequestAppointment",u=function(t,r,u,f){
return n(t+i,r,u,f)}
,f=function(t,i,u,f){
return n(t+r,i,u,f)}
;
return{
ajaxGet:t,ajaxPost:n,setCaptchaToken:u,appointmentCancelRequest:f}
}
();
JQueryHelper=function(){
var n=function(n){
return $('[name="'+n+'"]')}
;
return{
selectByName:n}
}
();
StringHelper=function(){
var n=function(n){
return n?n!==null&&(n.toLowerCase()==="true"||n==="1")?!0:!1:!1}
,t=function(n){
var t=n.match(/\d/g);
return t.join("")}
;
return{
isExpressionTrue:n,getNumber:t}
}
();
String.prototype.format=function(){
var n=arguments;
return this.replace(/\{
\{
|\}
\}
|\{
(\d+)\}
/g,
function(t,i){
return t==="{
{
"?"{
":t==="}
}
"?"}
":n[i]}
)}
